# -*- coding: utf-8 -*-
"""
وارد کردن فایل‌های CSV چارتیکس (ارزش بازار بورس / فرابورس / دلاری).

    python3 import_chartix.py --tse "arzsh riali bors.csv" \
                              --ifb "arzsh riali frabors.csv" \
                              --usd "arzsh dlari kl bors.csv"

هر سه اختیاری‌اند؛ هرکدام را که دادید وارد می‌شود.

قالب فایل: <DTYYYYMMDD>,<TIME>,<OPEN>,<HIGH>,<LOW>,<CLOSE>,<VOL>
تاریخ میلادی است و به شمسی تبدیل می‌شود؛ ستون CLOSE خوانده می‌شود.

واحدها: ارزش ریالی به **همت** تبدیل می‌شود (۱ همت = ۱۰ هزار میلیارد ریال)،
ارزش دلاری به **میلیارد دلار**. بعد از وارد کردن بورس و فرابورس، «ارزش بازار»
هم دوباره از جمعشان ساخته می‌شود — فقط برای روزهایی که هر دو را داریم.
"""
import argparse
import csv
import datetime

import jdatetime

from store import connect, upsert

RIAL_PER_HEMAT = 1e13          # ۱ همت = ۱۰۰۰ میلیارد تومان = ۱۰^۱۳ ریال
USD_PER_BILLION = 1e9


def read_csv(path):
    """{تاریخ شمسی: مقدار پایانی}"""
    out = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        next(reader, None)                       # سرستون
        for row in reader:
            if len(row) < 6 or not row[0].strip().isdigit():
                continue
            g = row[0].strip()
            try:
                greg = datetime.date(int(g[:4]), int(g[4:6]), int(g[6:8]))
                value = float(row[5])
            except ValueError:
                continue
            jd = jdatetime.date.fromgregorian(date=greg)
            out[jd.strftime("%Y%m%d")] = value
    return out


def load(con, path, series, divisor, label):
    rows = read_csv(path)
    stats = {}
    for date_j, raw in rows.items():
        res = upsert(con, date_j, series, raw / divisor, "chartix", label)
        k = res.split(":")[0]
        stats[k] = stats.get(k, 0) + 1
    span = f"{min(rows)} → {max(rows)}" if rows else "—"
    print(f"{label:22s} {len(rows):5d} روز · {span} · " +
          " ".join(f"{k}={v}" for k, v in sorted(stats.items())))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tse", help="ارزش ریالی بورس")
    ap.add_argument("--ifb", help="ارزش ریالی فرابورس")
    ap.add_argument("--usd", help="ارزش دلاری کل بازار")
    ap.add_argument("--keep-old", action="store_true",
                    help="ردیف‌های قدیمی «ارزش بازار» از منابع ضعیف‌تر را پاک نکن")
    a = ap.parse_args()
    if not any((a.tse, a.ifb, a.usd)):
        ap.error("دست‌کم یکی از --tse / --ifb / --usd را بدهید.")

    con = connect()
    if not a.keep_old and a.tse and a.ifb:
        # ستون اکسل و دادهٔ چارتیکس حدود ۸٪ اختلاف سطح دارند. اگر کنار هم
        # بمانند، سری یک پله می‌خورد و میانگین‌های متحرک دروغ می‌گویند.
        # پس اول ردیف‌های ضعیف‌تر پاک می‌شوند و بعد سری تمیز نوشته می‌شود.
        n = con.execute("DELETE FROM observations WHERE series='mv' "
                        "AND source IN ('xlsx_seed','json_restore','unknown')").rowcount
        con.commit()
        if n:
            print(f"{n} ردیف «ارزش بازار» از منبع قدیمی پاک شد.")
    tse = load(con, a.tse, "mv_tse", RIAL_PER_HEMAT, "ارزش بازار بورس") if a.tse else {}
    ifb = load(con, a.ifb, "mv_ifb", RIAL_PER_HEMAT, "ارزش بازار فرابورس") if a.ifb else {}
    if a.usd:
        load(con, a.usd, "mv_usd", USD_PER_BILLION, "ارزش دلاری بازار")

    if tse and ifb:
        both = sorted(set(tse) & set(ifb))
        stats = {}
        for date_j in both:
            res = upsert(con, date_j, "mv",
                         (tse[date_j] + ifb[date_j]) / RIAL_PER_HEMAT,
                         "chartix", "بورس + فرابورس")
            k = res.split(":")[0]
            stats[k] = stats.get(k, 0) + 1
        print(f"{'ارزش بازار (جمع)':22s} {len(both):5d} روز · "
              f"{both[0]} → {both[-1]} · " +
              " ".join(f"{k}={v}" for k, v in sorted(stats.items())))

        # «نسبت ارزش بازار به نقدینگی» از روی ارزش بازار ساخته می‌شود، پس حالا
        # که ارزش بازار عوض شده باید دوباره حساب شود، وگرنه نسبتِ کهنه می‌ماند.
        m2 = dict(con.execute("SELECT date_j, value FROM observations WHERE series='m2'"))
        mv = dict(con.execute("SELECT date_j, value FROM observations WHERE series='mv'"))
        shared = sorted(set(m2) & set(mv))
        if shared:
            con.execute("DELETE FROM observations WHERE series='ratio'")
            con.commit()
            for date_j in shared:
                if m2[date_j]:
                    upsert(con, date_j, "ratio", mv[date_j] / m2[date_j],
                           "chartix", "ارزش بازار ÷ M2")
            print(f"{'نسبت (بازسازی)':22s} {len(shared):5d} روز · "
                  f"{shared[0]} → {shared[-1]}")
    con.close()


if __name__ == "__main__":
    main()
