# -*- coding: utf-8 -*-
"""
مهاجرت‌های خودکار — چیزهایی که باید یک بار روی دیتابیسِ موجود اجرا شوند.

هر بار که ربات بالا می‌آید صدا زده می‌شود و اگر کاری لازم نباشد ساکت است.
دلیل وجودش: دیتابیس شما بیرون از پوشهٔ پروژه است (تا با به‌روزرسانی کد پاک
نشود)، پس دیتابیسِ اولیهٔ همراه نسخهٔ تازه به دستتان نمی‌رسد. هر سری تازه‌ای
که بعداً اضافه شود، از این مسیر وارد دیتابیسِ خودتان می‌شود.
"""
from config import BASE

CHARTIX_DIR = BASE / "data" / "chartix"
FILES = {"mv_tse": "mv_tse.csv", "mv_ifb": "mv_ifb.csv", "mv_usd": "mv_usd.csv"}


def ensure_market_value(con, log=print):
    """اگر سری‌های ارزش بازار هنوز در دیتابیس نیستند، از CSVهای همراه پروژه بریز."""
    have = con.execute(
        "SELECT COUNT(*) FROM observations WHERE series='mv_tse'").fetchone()[0]
    if have:
        return False
    missing = [f for f in FILES.values() if not (CHARTIX_DIR / f).exists()]
    if missing:
        return False

    import import_chartix as ix
    log("سری‌های ارزش بازار در دیتابیس نبود — از فایل‌های همراه پروژه اضافه می‌شود…")
    # «نسبت» از ارزش بازار ساخته می‌شود، پس ردیف‌های قدیمیِ هر دو با هم می‌روند
    # تا سری ترکیبی از دو منبع با ۸٪ اختلاف سطح باقی نماند.
    con.execute("DELETE FROM observations WHERE series IN ('mv','ratio') "
                "AND source IN ('xlsx_seed','json_restore','unknown')")
    con.commit()
    tse = ix.load(con, CHARTIX_DIR / FILES["mv_tse"], "mv_tse",
                  ix.RIAL_PER_HEMAT, "ارزش بازار بورس")
    ifb = ix.load(con, CHARTIX_DIR / FILES["mv_ifb"], "mv_ifb",
                  ix.RIAL_PER_HEMAT, "ارزش بازار فرابورس")
    ix.load(con, CHARTIX_DIR / FILES["mv_usd"], "mv_usd",
            ix.USD_PER_BILLION, "ارزش دلاری بازار")

    from store import derive_totals
    derive_totals(con, set(tse) & set(ifb))
    log("انجام شد.")
    return True


def run_all(con, log=print):
    return ensure_market_value(con, log)
