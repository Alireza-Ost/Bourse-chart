# -*- coding: utf-8 -*-
"""
چارتیکس — قیمت لحظه‌ای هر نماد از روی خود صفحه.

مقدار داخل HTMLِ سروری است (Nuxt با رندر سمت سرور)، نه پشت یک API
جاوااسکریپتی. پس یک `requests.get` ساده کافی است — نه مرورگر لازم است
نه سلنیوم.

⚠ واحدی که صفحه نشان می‌دهد قابل اعتماد نیست. شاخص کل را «IRR» برچسب
می‌زند (در حالی که واحد است نه ریال) و ارزش دلاری بورس را هم «IRR»
(در حالی که دلار است). پس واحد هر نماد اینجا دستی تعریف شده و برچسب
صفحه فقط برای هشدار خوانده می‌شود.

⚠ عدد صفحه «آخرین قیمت» است نه «قیمت پایانی». روز تعطیل همان عدد دیروز
را نشان می‌دهد. برای همین `fetch()` فهرست روزهای معاملاتی را می‌گیرد و
سری‌های بورسی را فقط برای روز معاملاتی می‌نویسد.
"""
import re

from .common import get, num, today_j, is_weekend

BASE = "https://chartix.ir/market/"

RIAL_PER_HEMAT = 1e13          # ۱ همت = ۱۰٬۰۰۰ میلیارد تومان = ۱۰^۱۳ ریال

# نماد -> (مسیر، سری یا None، ضریب تبدیل به واحد دیتابیس، بورسی؟)
SYMBOLS = {
    "mv_tse":  ("saham/BRS00IRMCAP",       "mv_tse", 1 / RIAL_PER_HEMAT, True),
    "mv_ifb":  ("saham/BRS00IRFCAP",       "mv_ifb", 1 / RIAL_PER_HEMAT, True),
    "gold18":  ("tala/Gold18_Etehadiye",   "gold18", 1.0,                False),
    # این دو فقط برای ساختن نرخ دلار خوانده می‌شوند، خودشان ذخیره نمی‌شوند:
    # ارزش ریالی کل ÷ ارزش دلاری کل = ریال به ازای هر دلار. چون صورت و مخرج
    # هر دو «کل بورس»اند، تعریف دامنه از وسط حذف می‌شود و نرخ خالص می‌ماند.
    "_all_irr": ("saham/BRS00IRALLCAP",    None, 1.0, True),
    "_all_usd": ("saham/BRS00IRALLUSDCAP", None, 1.0, True),
}

# چارتیکس آبان ۱۴۰۵ قالب صفحه را عوض کرد و هر پنج نماد ساکت از کار
# افتادند — «عدد قیمت در صفحه پیدا نشد». قالب قدیمی:
#
#     <... font-bold text-typePrimary">۱۲۳,۴۵۶<span ...>IRR</span>
#
# و قالب تازه، عدد و واحد هر کدام در span خودشان:
#
#     <div class="... text-heading-xs lg:text-heading-xl text-primary roboto" dir="ltr">
#       <span>274,303,193,274,824,160</span>
#       <span class="text-label-s lg:text-label-m text-tertiary pb-2">IRR</span>
#     </div>
#
# ⚠ نمی‌شود فقط «یک عدد که بعدش IRR بیاید» را گرفت: پایین هر صفحه فهرست
#   نمادهای مرتبط است و ده‌ها عدد دیگر با همان واحد دارد. لنگر، کلاس
#   `text-heading-*` است که فقط روی خودِ تیتر قیمت می‌نشیند.
#
# هر دو الگو نگه داشته می‌شوند و اولی که جواب بدهد برنده است، تا اگر
# سایت به قالب قبلی برگشت دوباره نشکند.
PRICE_RES = (
    re.compile(
        r'text-heading-[a-z0-9]+\s+lg:text-heading-[a-z0-9]+[^>]*>\s*'
        r'<span[^>]*>\s*([\d,\.]+)\s*</span>\s*<span[^>]*>\s*(IRR|IRT|USD)\b',
        re.S),
    re.compile(
        r'font-bold\s+text-typePrimary"[^>]*>\s*([\d,\.]+)\s*<span[^>]*>\s*(IRR|IRT|USD)',
        re.S),
)
TITLE_RE = re.compile(r"<title>([^<]*)</title>")


def price_of(html: str):
    """(مقدار، واحدِ برچسب‌خورده) — یا (None, None) اگر پیدا نشد."""
    for rx in PRICE_RES:
        m = rx.search(html)
        if m:
            return num(m.group(1)), m.group(2)
    return None, None


def fetch(trading=True, session=None, date_j=None):
    """
    trading: امروز روز معاملاتی بوده یا نه (از تریدرزآرنا).
             اگر False باشد فقط طلا خوانده می‌شود.
    """
    date_j = date_j or today_j()
    rows, notes = [], []
    raw = {}

    for key, (path, series, factor, is_bourse) in SYMBOLS.items():
        if is_bourse and not trading:
            continue
        if not is_bourse and is_weekend(date_j):
            continue                       # جمعه بازار طلا هم بسته است
        try:
            html = get(BASE + path, session)
        except Exception as e:             # noqa: BLE001
            notes.append(f"چارتیکس {path}: {e}")
            continue
        v, unit = price_of(html)
        if v is None:
            notes.append(f"چارتیکس {path}: عدد قیمت در صفحه پیدا نشد — ساختار عوض شده؟")
            continue
        raw[key] = v
        if series:
            rows.append((date_j, series, v * factor, "chartix/" + path))

    # نرخ دلار: ریال ÷ دلار ÷ ۱۰ = تومان به ازای هر دلار
    if raw.get("_all_irr") and raw.get("_all_usd"):
        rows.append((date_j, "usd_rate", raw["_all_irr"] / raw["_all_usd"] / 10,
                     "chartix/ارزش ریالی کل ÷ ارزش دلاری کل"))

    if not rows and not notes:
        notes.append("امروز روز معاملاتی نبود — چیزی از چارتیکس برداشته نشد.")
    return rows, notes
