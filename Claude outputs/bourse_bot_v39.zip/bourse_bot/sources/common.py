# -*- coding: utf-8 -*-
"""ابزارهای مشترک منابع خودکار."""
import re

import jdatetime

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

TIMEOUT = 20


def get(url: str, session=None) -> str:
    """یک GET ساده با هدر مرورگر. استثنا را بالا می‌دهد تا صدازننده تصمیم بگیرد."""
    import requests
    s = session or requests
    r = s.get(url, headers={"User-Agent": UA, "Accept-Language": "fa,en;q=0.8"},
              timeout=TIMEOUT)
    r.raise_for_status()
    return r.text


FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
AR_DIGITS = "٠١٢٣٤٥٦٧٨٩"

# ⚠ درسی که گران تمام شد: علامت منفی همیشه خط‌تیرهٔ اَسکی نیست.
#
# تریدرزآرنا ستون «ورود پول» را با رقم فارسی می‌نویسد و علامتش را
# U+2212 (MINUS SIGN) می‌گذارد، با یک U+200E (نشانهٔ چپ‌به‌راست) جلویش:
#
#     <td class="boldie minus">‎−۲,۱۹۴.۴</td>
#
# در همان ردیف ستون «قدرت خرید» که رقم لاتین دارد علامتش اَسکی است
# (-1.4). پس الگوی `-?\d+` علامتِ ستون فارسی را بی‌صدا می‌انداخت و عدد
# مثبت می‌شد: ۱۴۰۵/۰۷/۲۹ و ۰۸/۰۲ و ۰۸/۰۳ خروج پول داشتند ولی در
# دیتابیس ورود پول ثبت شده بودند. مقدار درست بود، فقط علامت رفته بود —
# برای همین با چشم هم توی جدول دیده نمی‌شد.
#
# این‌جا هر سه چیز پاک می‌شود: نشانه‌های دوطرفه، گونه‌های یونیکدی منفی،
# و جداکنندهٔ هزارگان (فارسی و لاتین و عربی).
MINUS_CHARS = "−–—―﹣－˗"      # − – — ― ﹣ －
BIDI_CHARS = ("‎‏؜​‌‍"
              "⁦⁧⁨⁩‪‫‬‭‮﻿")
SEP_CHARS = "٬،,٬  "                             # جداکنندهٔ هزارگان
DEC_CHARS = "٫"                                            # ٫ ممیز فارسی

_TRANS = {ord(c): None for c in BIDI_CHARS + SEP_CHARS}
_TRANS.update({ord(c): "." for c in DEC_CHARS})
_TRANS.update({ord(c): "-" for c in MINUS_CHARS})
_TRANS.update({ord(c): str(i) for i, c in enumerate(FA_DIGITS)})
_TRANS.update({ord(c): str(i) for i, c in enumerate(AR_DIGITS)})

NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")
LONE_MINUS_RE = re.compile(r"^\s*-\s*$")


def num(s):
    """
    '۱٬۲۳۴.۵' یا '418.87 K' یا '-846.4' یا '‎−۲,۱۹۴.۴' → float.
    نشد → None.
    """
    if s is None:
        return None
    t = str(s).translate(_TRANS).strip()
    mult = 1.0
    if t.endswith(("K", "k")):
        mult, t = 1e3, t[:-1].strip()
    elif t.endswith(("M", "m")):
        mult, t = 1e6, t[:-1].strip()
    m = NUM_RE.search(t)
    if not m:
        return None
    val = float(m.group(0))
    # اگر علامت با یک مرز تگ از عدد جدا افتاده باشد (strip_tags جای تگ
    # فاصله می‌گذارد: «<td>-<span>۴,۱۰۸</span>») هم گرفته شود. شرط
    # سخت‌گیرانه است: پیش از عدد باید *فقط* یک منفی و فاصله باشد، تا
    # رشته‌ای مثل «۱۲۳ - ۴۵۶» اشتباهی منفی نشود.
    if val >= 0 and LONE_MINUS_RE.match(t[:m.start()]):
        val = -val
    return val * mult


def strip_tags(html: str) -> str:
    return re.sub(r"<[^>]+>", " ", html)


def today_j() -> str:
    return jdatetime.date.today().strftime("%Y%m%d")


def is_weekend(date_j: str) -> bool:
    """پنجشنبه و جمعه — بازار بورس تعطیل است."""
    jd = jdatetime.date(int(date_j[:4]), int(date_j[4:6]), int(date_j[6:]))
    return jd.weekday() in (5, 6)        # 0=شنبه … 5=پنجشنبه، 6=جمعه
