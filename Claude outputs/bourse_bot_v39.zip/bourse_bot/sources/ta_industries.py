# -*- coding: utf-8 -*-
"""
تریدرزآرنا — دیده‌بان صنایع از API صفحهٔ اول.

    https://tradersarena.ir/data/industries-csv

همان داستان `ta_home`: جدول «خلاصه معاملات صنایع بورس» در صفحهٔ اول با
جاوااسکریپت پر می‌شود و HTML خام سرور ردیفی ندارد. منبع واقعی این آدرس
است — بدون لاگین، با دقت کامل (ریال)، و با curl ساده هم جواب می‌دهد.

── شکل پاسخ
   آرایه‌ای از آرایه‌ها، یک ردیف برای هر صنعت:

     ["01", "زراعت", حجم, ارزش, خرید‌حقیقی, فروش‌حقیقی, سفارش‌خرید,
      سفارش‌فروش, برآیند, بازدهی, سرانه‌خرید, سرانه‌فروش, قدرت,
      درصد‌خرید, درصد‌فروش, ورودپول, …, تعداد‌نماد]

   ستون اول کد است: برای صنعت عدد («44») و برای سبد صندوق نامک
   («gold-funds»). هر دو برداشته می‌شوند — سبدها هم در تب صنایع زیرتب
   خودشان را دارند — ولی فقط آن‌هایی که در `config.INDUSTRIES` اسم
   دارند.

⚠ پاسخ **تاریخ ندارد**. تاریخ از `ta_home` (کلید `j` در `market0`)
  گرفته می‌شود — همان روزی که خود سایت می‌گوید. اگر آن در دسترس نباشد،
  چیزی نوشته نمی‌شود؛ حدس‌زدن تاریخ از ساعت کامپیوتر یعنی عدد دیروز با
  تاریخ امروز ذخیره شود، و این بدترین نوع خرابی است چون بی‌صدا است.

⚠ یک روز می‌دهد. جبران چند روز خاموشی با `backfill_industries.py` است
  که صفحهٔ سوابق هر صنعت را می‌خواند (۱۰ روز آخر، رایگان).
"""
import json

from .common import get

URL = "https://tradersarena.ir/data/industries-csv"

RIAL_PER_BILLION_TOMAN = 1e10
RIAL_PER_MILLION_TOMAN = 1e7

# کلید سری -> (جای عدد در ردیف، مقسوم‌علیه)
# ترتیب ستون‌ها همان ترتیب جدول صفحه است. اگر فردا ستونی وسط اضافه شود
# این نگاشت می‌شکند — برای همین `sane()` پایین هست: چند رابطهٔ قطعی را
# می‌سنجد و اگر نخواند، چیزی نمی‌نویسد.
COLUMNS = {
    "value":       (3,  RIAL_PER_BILLION_TOMAN),
    "buy_real":    (4,  RIAL_PER_BILLION_TOMAN),
    "sell_real":   (5,  RIAL_PER_BILLION_TOMAN),
    "sarane_buy":  (10, RIAL_PER_MILLION_TOMAN),
    "sarane_sell": (11, RIAL_PER_MILLION_TOMAN),
    "power":       (12, 1.0),
    "flow":        (15, RIAL_PER_BILLION_TOMAN),
}

MIN_COLS = max(i for i, _ in COLUMNS.values()) + 1


def sane(vals):
    """
    چند رابطه که در دادهٔ درست همیشه برقرارند. اگر فردا ستونی وسط جدول
    اضافه یا جابه‌جا شود، این‌ها می‌شکنند و ردیف کنار گذاشته می‌شود —
    بهتر از نوشتن عدد غلط با برچسب درست.

      • ارزش معاملات نامنفی
      • خرید و فروش حقیقی هر دو نامنفی و کوچک‌تر از ارزش کل معاملات
      • |ورود پول| از ارزش کل معاملات بیشتر نمی‌شود
      • سرانه‌ها نامنفی، و |قدرت خرید| زیر ۲۰۰

    ⚠ یک رابطهٔ به‌ظاهر بدیهی اینجا *نیست*: «ورود پول = خرید حقیقی −
      فروش حقیقی». اولش گذاشتمش و سه صنعت از چهار صنعتِ نمونه را رد کرد.
      دلیلش تعریف است، نه خرابی داده: «ورود پول» تریدرزآرنا فقط معاملات
      *خرد* را می‌شمارد، ولی «ارزش خرید/فروش حقیقی» کل معاملات حقیقی را
      شامل بلوک‌های بزرگ. در بانک‌ها تصادفاً یکی بود و همین گمراه‌کننده
      بود.
    """
    value = vals.get("value")
    if value is not None:
        if value < 0:
            return "ارزش معاملات منفی"
        if value > 0:
            for k in ("buy_real", "sell_real"):
                v = vals.get(k)
                if v is not None and not (0 <= v <= value * 1.01):
                    return f"{k} بیرون از بازهٔ صفر تا ارزش کل معاملات"
            f = vals.get("flow")
            if f is not None and abs(f) > value * 1.01:
                return "ورود پول از ارزش کل معاملات بزرگ‌تر"
    for k in ("sarane_buy", "sarane_sell"):
        v = vals.get(k)
        if v is not None and v < 0:
            return f"{k} منفی"
    pw = vals.get("power")
    if pw is not None and abs(pw) > 200:
        return "قدرت خرید بیرون از بازهٔ معقول"
    return None


def parse(text, date_j, keep=None):
    """
    خروجی: (rows, notes) — rows = [(date_j, ind, metric, value, src_ref), …]

    keep: مجموعهٔ کدهای صنعتی که می‌خواهیم. None یعنی همه.
    """
    try:
        data = json.loads(text)
    except Exception:
        return [], ["API صنایع تریدرزآرنا: پاسخ JSON نبود."]
    if not isinstance(data, list):
        return [], ["API صنایع تریدرزآرنا: شکل پاسخ عوض شده."]

    rows, notes, seen = [], [], 0
    for r in data:
        if not isinstance(r, list) or len(r) < MIN_COLS:
            continue
        code = str(r[0]).strip()
        # کد هم عددی است (صنعت: "44") و هم نامکی (سبد صندوق:
        # "gold-funds"). هر دو پذیرفته می‌شوند، ولی فقط آن‌هایی که
        # می‌شناسیم: `keep` همان config.INDUSTRIES است. این‌طور سبد یا
        # صنعتِ تازه‌ای که سایت اضافه کند بی‌سر‌و‌صدا وارد دیتابیس
        # نمی‌شود — اول باید نامش را بدانیم.
        if not code or (keep is not None and code not in keep):
            continue
        vals = {}
        for metric, (i, div) in COLUMNS.items():
            v = r[i]
            if isinstance(v, (int, float)):
                vals[metric] = v / div
        bad = sane(vals)
        if bad:
            notes.append(f"صنعت {code} رد شد — {bad}")
            continue
        seen += 1
        for metric, v in vals.items():
            rows.append((date_j, code, metric, v, "tradersarena/data/industries-csv"))

    if not seen:
        notes.append("API صنایع تریدرزآرنا: هیچ صنعتی خوانده نشد.")
    return rows, notes


def fetch(date_j, keep=None, session=None):
    if not date_j:
        return [], ["صنایع: تاریخ روز معلوم نبود، چیزی نوشته نشد."]
    try:
        return parse(get(URL, session), date_j, keep)
    except Exception as e:
        return [], [f"API صنایع تریدرزآرنا در دسترس نبود: {type(e).__name__}"]
