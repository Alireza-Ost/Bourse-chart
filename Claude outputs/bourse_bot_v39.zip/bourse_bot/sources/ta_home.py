# -*- coding: utf-8 -*-
"""
تریدرزآرنا — سبدهای بازار از API صفحهٔ اول.

    https://tradersarena.ir/data/market0

── چرا API و نه صفحه
   جدول «خلاصه معاملات خرد سهام و صندوق ها» در صفحهٔ اول با جاوااسکریپت
   پر می‌شود: HTML خامی که سرور می‌دهد فقط *قالب خالی* جدول را دارد
   (`id="marketDetails"` هست، ولی `value_leveraged` نیست). پس پارس‌کردن
   HTML با requests هیچ‌وقت کار نمی‌کرد — اولین نسخهٔ این فایل همین کار
   را می‌کرد و اشتباه بود. منبع واقعی همین آدرس است که خود صفحه صدا
   می‌زند: JSON تمیز، بدون لاگین، و با **دقت کامل** (ریال، نه عدد رُند
   جدول). با curl ساده هم جواب می‌دهد.

── شکل پاسخ
   {"j":"1405/07/22", "d":1859,
    "afl":[حجم, ارزش, سرانه‌خرید, سرانه‌فروش, قدرت, ورود‌پول, …],
    "st":[…], "sf":[…], "nsf":[…], "lf":[…], "cf":[…], …}

   هر سبد یک آرایه با همین ترتیب. ارزش و ورود پول به **ریال**، سرانه‌ها
   به **ریال**، قدرت خرید بدون واحد.

── سبدها (مهر ۱۴۰۵)
   afl  سهام + حق تقدم + ص.سهامی      ۵۳٬۴۸۲   ← همان value_retail ما
   st   سهام و حق تقدم                 ۴۳٬۷۳۸
   sf   صندوق سهامی و مختلط             ۹٬۷۴۴
   nsf  صندوق درآمد ثابت               ۴۱٬۷۵۷   ← همان value_fixed ما
   lf   صندوق اهرمی                     ۴٬۸۷۳
   cf   صندوق طلا                      ۱۸٬۰۷۳
   scf  صندوق نقره                      ۱٬۱۳۱
   b    پنجاه شرکت بزرگ                ۲۰٬۴۴۳
   m/um بازار (جمع afl و nsf)          ۹۵٬۲۳۹
   iw   شاخص کل  · ia  شاخص هم‌وزن      [مقدار، تغییر]

   از این‌ها فقط اهرمی و طلا نوشته می‌شود. بقیه از منابع موجود می‌آیند و
   اضافه‌کردنشان فقط دو سطر است: یکی در BASKETS و یکی در config.SERIES.

⚠ شاخص کل و هم‌وزن عمداً از اینجا نوشته نمی‌شوند: این عدد «آخرین» است و
  اگر برداشت ساعت ۱۴:۳۰ (بازار باز) اجرا شود، عدد میانِ‌روز به‌جای پایانی
  ذخیره می‌شود. شاخص از جدول سوابق می‌آید که فقط پایانیِ روزهای تمام‌شده
  را دارد.

⚠ یک روز می‌دهد، نه بیشتر (همان روزی که خودش در `j` نوشته — تاریخ
  کامپیوتر خوانده نمی‌شود). اگر چند روز خاموش بمانید جبران نمی‌کند؛
  تاریخچه از اکسل اشتراک می‌آید.
"""
import json

from .common import get

URL = "https://tradersarena.ir/data/market0"

RIAL_PER_BILLION_TOMAN = 1e10      # ۱ میلیارد تومان = ۱۰^۱۰ ریال
RIAL_PER_MILLION_TOMAN = 1e7       # ۱ میلیون تومان  = ۱۰^۷ ریال

# جای هر عدد در آرایهٔ هر سبد، و مقسوم‌علیهش
FIELDS = {
    "volume":      (0, 1.0),
    "value":       (1, RIAL_PER_BILLION_TOMAN),
    "sarane_buy":  (2, RIAL_PER_MILLION_TOMAN),
    "sarane_sell": (3, RIAL_PER_MILLION_TOMAN),
    "power":       (4, 1.0),
    "flow":        (5, RIAL_PER_BILLION_TOMAN),
}

# کلید سبد در JSON -> {نام میدان: سری دیتابیس}
BASKETS = {
    "lf": {"value": "value_lev",      "flow": "flow_lev"},
    "cf": {"value": "value_goldfund", "flow": "flow_goldfund"},
}


def field(arr, name):
    i, div = FIELDS[name]
    if not isinstance(arr, list) or len(arr) <= i:
        return None
    v = arr[i]
    return v / div if isinstance(v, (int, float)) else None


def day_of(text):
    """تاریخ شمسی روزی که این پاسخ مال آن است ('14050722')، یا None."""
    try:
        j = str(json.loads(text).get("j", ""))
    except Exception:
        return None
    parts = j.replace("-", "/").split("/")
    if len(parts) != 3 or not parts[0].isdigit():
        return None
    return f"{int(parts[0]):04d}{int(parts[1]):02d}{int(parts[2]):02d}"


def parse(text):
    """خروجی: (rows, notes) — rows = [(date_j, series, value, src_ref), …]"""
    try:
        data = json.loads(text)
    except Exception:
        return [], ["API صفحهٔ اول تریدرزآرنا: پاسخ JSON نبود."]

    date_j = day_of(text)
    if not date_j:
        return [], ["API صفحهٔ اول تریدرزآرنا: تاریخ نامفهوم."]

    rows, notes = [], []
    for key, fields in BASKETS.items():
        arr = data.get(key)
        if arr is None:
            notes.append(f"API صفحهٔ اول تریدرزآرنا: سبد «{key}» نبود.")
            continue
        for name, series in fields.items():
            v = field(arr, name)
            if v is not None:
                rows.append((date_j, series, v, f"tradersarena/data/market0#{key}"))
    return rows, notes


def fetch(session=None):
    try:
        return parse(get(URL, session))
    except Exception as e:
        return [], [f"API صفحهٔ اول تریدرزآرنا در دسترس نبود: {type(e).__name__}"]


def fetch_day(session=None):
    """
    (date_j, rows, notes) — یک درخواست، هم سبدها و هم تاریخ روز.

    تاریخ لازم است چون API صنایع تاریخ ندارد و نباید از ساعت کامپیوتر
    حدس زده شود.
    """
    try:
        text = get(URL, session)
    except Exception as e:
        return None, [], [f"API صفحهٔ اول تریدرزآرنا در دسترس نبود: {type(e).__name__}"]
    rows, notes = parse(text)
    return day_of(text), rows, notes
