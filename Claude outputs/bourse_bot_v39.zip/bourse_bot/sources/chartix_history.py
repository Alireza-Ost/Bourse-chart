# -*- coding: utf-8 -*-
"""
چارتیکس — تاریخچهٔ روزانه، نه فقط قیمت امروز.

    https://market.chartix.ir/symbol/history?ticker=<نماد>&tf=1D

── چرا این فایل هست در حالی که chartix_live هست
   `chartix_live` عددِ *روی صفحه* را می‌خواند، یعنی یک روز. اگر کامپیوتر
   چند روز خاموش بماند — یا مثل آبان ۱۴۰۵ قالب سایت عوض شود و برداشت
   ساکت بیفتد — آن روزها برای همیشه خالی می‌مانند و هیچ‌چیز خودش
   جبرانشان نمی‌کند. این آدرس حدود **۱۳۰ روز** کندل روزانه می‌دهد، پس
   عقب‌افتادگی تا چند ماه را یک‌جا پر می‌کند.

   تریدرزآرنا همین نقش را برای ارزش معاملات و ورود پول دارد (۱۰ روز) و
   صفحهٔ سوابق صنایع برای دیده‌بان. این قطعهٔ گمشدهٔ سمت ارزش بازار بود.

── شکل پاسخ
   [{"time":1793059200,"open":…,"high":…,"low":…,"close":…,"volume":0}, …]

   `time` ثانیهٔ یونیکس و نیمه‌شبِ UTC است؛ همان روز میلادی، و از آن‌جا
   روز شمسی. `close` همان «پایانی» است — برخلاف عدد صفحه که «آخرین» است
   و روز تعطیل، عدد دیروز را تکرار می‌کند. پس این منبع از آن یکی تمیزتر
   است و گاردِ «روز معاملاتی» لازم ندارد.

── اعتبارسنجی
   روی روزهای مشترک با دیتابیس، ارزش بورس و فرابورس **دقیقاً** با
   مقدارهای قبلی یکی درآمد (نسبت ۱٫۰۰۰۰۰) — یعنی همان سری است، نه یک
   تعریف دیگر. نرخ دلارِ ساخته‌شده از تقسیم هم روی ۱۴۰۵/۰۷/۲۲ عدد
   ۲۶۳٬۶۰۰ داد، همان که از قبل داشتیم.

⚠ «ارزش دلاری بازار» از این‌جا نوشته نمی‌شود. نماد دلاریِ چارتیکس
  «کل بورس» است و سری ما «بورس + فرابورس»؛ سه درصد فرق دارند. آن سری
  در store.derive_totals از ارزش بازار ÷ نرخ دلار ساخته می‌شود و باید
  همان‌جا بماند، وگرنه یک پلهٔ سه‌درصدی در نمودار می‌افتد.
"""
import datetime
import json

import jdatetime

from .common import get

URL = "https://market.chartix.ir/symbol/history"
TF = "1D"

RIAL_PER_HEMAT = 1e13          # ۱ همت = ۱۰^۱۳ ریال

# نماد چارتیکس -> (سری دیتابیس یا None، ضریب تبدیل)
# نمادهای None فقط برای ساختن نرخ دلار خوانده می‌شوند.
SYMBOLS = {
    "BRS00IRMCAP":      ("mv_tse", 1 / RIAL_PER_HEMAT),
    "BRS00IRFCAP":      ("mv_ifb", 1 / RIAL_PER_HEMAT),
    "Gold18_Etehadiye": ("gold18", 1.0),
    "BRS00IRALLCAP":    (None, 1.0),
    "BRS00IRALLUSDCAP": (None, 1.0),
}

# حداکثر فاصلهٔ معقول دو سرِ یک کندل؛ بیرونش یعنی پاسخ آن چیزی نیست که
# فکر می‌کنیم (مثلاً پیام خطای JSON به‌جای آرایه).
MIN_ROWS = 2


def day_of(ts):
    """ثانیهٔ یونیکس (نیمه‌شب UTC) → تاریخ شمسی هشت‌رقمی."""
    g = datetime.datetime.fromtimestamp(int(ts), datetime.timezone.utc).date()
    return jdatetime.date.fromgregorian(date=g).strftime("%Y%m%d")


def parse(payload):
    """متن یا آبجکت پاسخ → {date_j: close}. پاسخ نامفهوم → {}."""
    data = json.loads(payload) if isinstance(payload, (str, bytes)) else payload
    if not isinstance(data, list):
        return {}
    out = {}
    for c in data:
        if not isinstance(c, dict):
            continue
        ts, close = c.get("time"), c.get("close")
        if ts is None or close is None:
            continue
        try:
            out[day_of(ts)] = float(close)
        except (ValueError, OSError, OverflowError):
            continue
    return out


def fetch(session=None, since=None, symbols=None):
    """
    خروجی: (rows, notes) — rows = [(date_j, series, value, src_ref), …]

    since: اگر بدهید فقط روزهای بعد از آن برگردانده می‌شوند (رشتهٔ شمسی
    هشت‌رقمی). برای پرکردن جای خالی، همین کافی است و بار شبکه را کم
    نمی‌کند ولی حجم نوشتن را کم می‌کند.
    """
    rows, notes, raw = [], [], {}
    for ticker, (series, factor) in (symbols or SYMBOLS).items():
        try:
            body = get(f"{URL}?ticker={ticker}&tf={TF}", session)
        except Exception as e:                      # noqa: BLE001
            notes.append(f"تاریخچهٔ چارتیکس {ticker}: {e}")
            continue
        days = parse(body)
        if len(days) < MIN_ROWS:
            notes.append(f"تاریخچهٔ چارتیکس {ticker}: پاسخ خالی یا ناشناخته "
                         f"— ساختار عوض شده؟")
            continue
        raw[ticker] = days
        if not series:
            continue
        for date_j, close in days.items():
            if since and date_j <= since:
                continue
            rows.append((date_j, series, close * factor,
                         f"chartix/history {ticker}"))

    # نرخ دلار: ارزش ریالی کل ÷ ارزش دلاری کل ÷ ۱۰ = تومان بر دلار.
    # صورت و مخرج هر دو «کل بورس»اند، پس تعریف دامنه از وسط حذف می‌شود.
    irr = raw.get("BRS00IRALLCAP") or {}
    usd = raw.get("BRS00IRALLUSDCAP") or {}
    for date_j, a in irr.items():
        b = usd.get(date_j)
        if not b:
            continue
        if since and date_j <= since:
            continue
        rows.append((date_j, "usd_rate", a / b / 10,
                     "chartix/history ارزش ریالی کل ÷ ارزش دلاری کل"))

    if not rows and not notes:
        notes.append("تاریخچهٔ چارتیکس چیزی تازه‌تر از دیتابیس نداشت.")
    return rows, notes
