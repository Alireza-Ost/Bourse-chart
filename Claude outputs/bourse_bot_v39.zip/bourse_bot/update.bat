@echo off
REM ===================================================================
REM  Daily update: rebuild the page+data from the bot database,
REM  copy both into the GitHub repo, commit and push.
REM  Messages are ASCII on purpose - the console mangles Persian.
REM ===================================================================
setlocal
cd /d "%~dp0"

set "REPO=C:\Users\%USERNAME%\bourse-chart"

where python >nul 2>nul && (set "PY=python") || (set "PY=py")

if not exist "%REPO%\.git" (
  echo.
  echo [X] Repo not found at: %REPO%
  echo     Edit the REPO line at the top of this file.
  echo.
  pause & exit /b 1
)

echo.
echo === 1/3  Migrations, then building page and data from the database
%PY% make_chart.py --web
if errorlevel 1 (
  echo.
  echo [X] Build failed. Is Python installed, and did you run:
  echo     pip install -r requirements.txt
  echo.
  pause & exit /b 1
)

echo.
echo === 2/3  Copying into %REPO%
copy /Y "web\index.html" "%REPO%\index.html" >nul || (echo [X] copy failed & pause & exit /b 1)
copy /Y "web\data.json"  "%REPO%\data.json"  >nul || (echo [X] copy failed & pause & exit /b 1)
REM  Industries tab: one JSON per industry, fetched next to the page.
REM  If this folder is empty the industries tabs render empty on the site,
REM  so say it out loud rather than pushing a half-built page.
if exist "web\ind\*.json" (
  if not exist "%REPO%\ind" mkdir "%REPO%\ind"
  copy /Y "web\ind\*.json" "%REPO%\ind\" >nul || (echo [X] copy failed & pause & exit /b 1)
) else (
  echo.
  echo [!] No industry files were built - the industries tabs will be empty.
  echo     The database has no industry rows. Check that data\industries.csv.gz
  echo     shipped with this version and run:  %PY% make_chart.py --web
  echo.
)

echo.
echo === 3/3  Pushing to GitHub
pushd "%REPO%"
git add -A
git commit -m "update %date%"
git push
echo.
echo --- files tracked by git ---
git ls-files
popd

echo.
echo Done. Wait about a minute, then open with Ctrl+Shift+R:
echo     https://alireza-ost.github.io/Bourse-chart/
echo.
pause
