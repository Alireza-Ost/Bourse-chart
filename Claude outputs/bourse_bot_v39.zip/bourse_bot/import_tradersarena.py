# -*- coding: utf-8 -*-
"""
وارد کردن خروجی «سوابق بازار» تریدرزآرنا (اکسل یا CSV).

    python3 import_tradersarena.py market.xlsx                 # فقط جای خالی را پر کن
    python3 import_tradersarena.py market.xlsx --dry           # فقط گزارش بده
    python3 import_tradersarena.py market.xlsx --overwrite     # روزهای موجود را هم بازنویسی کن
    python3 import_tradersarena.py type1.xlsx --fixed type0.xlsx

── چرا پیش‌فرض «فقط جای خالی»؟
   اولویت tradersarena (۴) از xlsx_seed و json_restore (۳) بالاتر است، پس
   یک واردکردنِ بی‌قید روزهای موجود را *بازنویسی* می‌کند. روی شاخص کل و
   هم‌وزن مشکلی نیست (در ۱٬۴۳۷ روز مشترک، صفر درصد اختلاف داشتند) ولی روی
   ارزش معاملات و ورود پول تعریف‌ها یکی نیست: نسبت میانهٔ مشترک‌ها ۱٬۰۰۵
   است اما چارک‌ها ۰٬۹۶ تا ۱٬۰۹ و هرچه عقب‌تر می‌رویم فاصله بیشتر — مثلاً
   ۱۳۹۹/۰۳/۱۰: قدیمی ۹٬۴۰۰ مقابل ۸٬۴۷۸. یعنی اگر نیمی از روزها از این
   منبع و نیمی از آن منبع باشد، سری حدود ۱۳۹۹ یک پلهٔ دیدنی پیدا می‌کند.
   پس پیش‌فرض این است که چیزی از دیتابیس فعلی عوض نشود و فقط روزهای خالی
   پر شوند. اگر خواستید یک سری *کاملاً* یکدست شود:

       python3 import_tradersarena.py market.xlsx --overwrite value_retail

── واحدها
   همهٔ ستون‌های ریالی فایل بر حسب «تومان» است و دیتابیس بر حسب میلیارد
   تومان (ارزش و ورود پول) و میلیون تومان (سرانه). مقسوم‌علیه در همین
   نگاشت است، نه جای دیگر.
"""
import argparse
import re
import sys
import unicodedata

from sources.common import num
from store import connect, upsert, derive_totals

SOURCE = "tradersarena"

# عنوان ستون (نرمال‌شده) -> (سری، مقسوم‌علیه)
# نگاشت از روی *عنوان* است نه شمارهٔ ستون؛ اگر فردا ستونی اضافه یا جابه‌جا
# شود چیزی نمی‌شکند. چند املای محتمل برای هر کدام نوشته شده چون عنوان فایل
# اکسل با عنوان جدول وب کمی فرق دارد.
HEADERS = {
    "تاریخ": ("_date", 1),

    "ارزش معاملات (تومان)": ("value_retail", 1e9),
    "ارزش معاملات": ("value_retail", 1e9),
    "ارزش معاملات میلیارد تومان": ("value_retail", 1),

    "ورود پول (تومان)": ("flow_retail", 1e9),
    "ورود پول": ("flow_retail", 1e9),
    "خالص ورود پول": ("flow_retail", 1e9),
    "ورود پول میلیارد تومان": ("flow_retail", 1),

    "سرانه خرید (تومان)": ("sarane_buy", 1e6),
    "سرانه خرید": ("sarane_buy", 1e6),
    "سرانه خرید میلیون تومان": ("sarane_buy", 1),

    "سرانه فروش (تومان)": ("sarane_sell", 1e6),
    "سرانه فروش": ("sarane_sell", 1e6),
    "سرانه فروش میلیون تومان": ("sarane_sell", 1),

    "شاخص کل": ("index_total", 1),
    "شاخص هم وزن": ("index_ew", 1),
    "شاخص هموزن": ("index_ew", 1),
}

# ستون‌های تجمعی (۵/۲۰/۶۰ روزه) عنوانشان شبیه ستون‌های روزانه است؛
# اگر این را نداشته باشیم «میانگین ارزش معاملات 5 روزه» هم به
# value_retail بخورد. هر عنوانی که این‌ها را داشته باشد کنار گذاشته می‌شود.
SKIP_RE = re.compile(r"(روزه|میانگین|جمع )")

# ستون‌هایی که اگر فایل type=0 هم بدهید، تفاضلشان سری تازه می‌سازد
DERIVED = {"value_retail": "value_fixed", "flow_retail": "flow_fixed"}

# `--as <سبد>`: خروجی جداگانهٔ یک سبد صندوق (شیت‌هایی با نام خودشان:
# «صندوق های درآمد»، «صندوق های اهرمی»، «صندوق های طلا…»).
# ستون‌های همهٔ این فایل‌ها هم‌نام جدول اصلی است ولی معنایشان آن سبد است،
# پس نگاشت عوض می‌شود. سرانهٔ خرید/فروشِ سبدها سری ندارد و کنار گذاشته
# می‌شود — بی این کار، سرانهٔ صندوق جای سرانهٔ حقیقیِ کل بازار را می‌گرفت.
AS_BASKET = {
    "fixed":    {"value_retail": "value_fixed",     "flow_retail": "flow_fixed"},
    "lev":      {"value_retail": "value_lev",       "flow_retail": "flow_lev"},
    "goldfund": {"value_retail": "value_goldfund",  "flow_retail": "flow_goldfund"},
}
AS_FIXED = AS_BASKET["fixed"]      # نام قدیمی، برای سازگاری

FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
AR_DIGITS = "٠١٢٣٤٥٦٧٨٩"


def norm(s):
    """یکدست‌کردن عنوان: ارقام انگلیسی، بی‌نیم‌فاصله، بدون فاصلهٔ اضافه."""
    if s is None:
        return ""
    t = unicodedata.normalize("NFKC", str(s))
    out = []
    for ch in t:
        if ch in FA_DIGITS:
            out.append(str(FA_DIGITS.index(ch)))
        elif ch in AR_DIGITS:
            out.append(str(AR_DIGITS.index(ch)))
        elif ch in "‌‏‎":
            out.append(" ")
        else:
            out.append(ch)
    t = "".join(out).replace("ي", "ی").replace("ك", "ک")
    return re.sub(r"\s+", " ", t).strip()


def number(v):
    """
    عدد از هر شکلی که در اکسل یا جدول سایت می‌آید.

    ⚠ این تابع یک بار دقیقاً همان باگی را داشت که `sources.common.num`:
    الگوی `-?\\d+` فقط خط‌تیرهٔ اَسکی را می‌شناخت، و ستون فارسی‌رقم
    «ورود پول» تریدرزآرنا علامتش U+2212 است. نتیجه این بود که در
    `backfill_industries` ورود پولِ بیست‌وپنج صنعت در روز ۱۴۰۵/۰۷/۲۲
    مثبت خوانده شد در حالی که منفی بود. پس حالا از همان پاک‌سازیِ
    مشترک رد می‌شود و دو پارسر عدد، یک قاعده دارند.

    ٫ ممیز فارسی است و ٬ جداکنندهٔ هزارگان؛ هر دو آن‌جا رسیدگی می‌شوند.
    """
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return float(v)
    return num(norm(v))


DATE_RE = re.compile(r"(1[34]\d{2})\D(\d{1,2})\D(\d{1,2})")


def date_j(v):
    """'1405/07/12' یا '۱۴۰۵-۷-۱۲' → '14050712'. نشد → None."""
    m = DATE_RE.search(norm(v))
    if not m:
        return None
    return f"{m.group(1)}{int(m.group(2)):02d}{int(m.group(3)):02d}"


def read_table(path):
    """[(dict ستون→مقدار), …] — از xlsx یا csv."""
    p = str(path)
    if p.lower().endswith((".xlsx", ".xlsm", ".xls")):
        import warnings
        from openpyxl import load_workbook
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            wb = load_workbook(p, read_only=True, data_only=True)
            ws = wb[wb.sheetnames[0]]
            rows = [list(r) for r in ws.iter_rows(values_only=True)]
    else:
        import csv
        with open(p, encoding="utf-8-sig", newline="") as f:
            rows = list(csv.reader(f))
    if not rows:
        return []

    # سطر عنوان لزوماً سطر اول نیست — اولی را می‌گیریم که «تاریخ» دارد
    head_i = 0
    for i, r in enumerate(rows[:12]):
        if any(norm(c) == "تاریخ" for c in r):
            head_i = i
            break
    head = [norm(c) for c in rows[head_i]]
    return [dict(zip(head, r)) for r in rows[head_i + 1:]]


def extract(path, log=print):
    """{date_j: {series: value}} — با واحد دیتابیس."""
    table = read_table(path)
    if not table:
        log(f"  {path}: خالی بود.")
        return {}

    cols = {}
    for h in table[0]:
        if not h or SKIP_RE.search(h):
            continue
        if h in HEADERS:
            cols[h] = HEADERS[h]
    found = {s for s, _ in cols.values()} - {"_date"}
    unknown = [h for h in table[0] if h and h not in cols]
    log(f"  ستون‌های شناخته‌شده: {'، '.join(sorted(found)) or '—'}")
    if unknown:
        log(f"  ستون‌های نادیده‌گرفته‌شده: {len(unknown)}")
    if not any(s == "_date" for s, _ in cols.values()):
        log("  ⚠ ستون «تاریخ» پیدا نشد — فایل درست است؟")
        return {}

    out = {}
    for row in table:
        d = None
        for h, (series, _) in cols.items():
            if series == "_date":
                d = date_j(row.get(h))
                break
        if not d:
            continue
        for h, (series, div) in cols.items():
            if series == "_date":
                continue
            v = number(row.get(h))
            if v is not None:
                out.setdefault(d, {})[series] = v / div
    return out


def existing(con, series):
    return {r[0] for r in con.execute(
        "SELECT date_j FROM observations WHERE series=?", (series,))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file", help="خروجی سوابق بازار (type=1)")
    ap.add_argument("--fixed", help="خروجی type=0، برای ساختن سری صندوق درآمد ثابت")
    ap.add_argument("--as-fixed", action="store_true",
                    help="خودِ فایل، خروجی «صندوق‌های درآمد ثابت» است")
    ap.add_argument("--as", dest="as_basket", choices=sorted(AS_BASKET),
                    help="خودِ فایل، خروجی یک سبد صندوق است: fixed / lev / goldfund")
    ap.add_argument("--dry", action="store_true", help="فقط گزارش بده، چیزی ننویس")
    ap.add_argument("--overwrite", nargs="*", metavar="SERIES",
                    help="روزهای موجود را هم بازنویسی کن؛ بدون نام سری یعنی همه")
    a = ap.parse_args()

    print(f"خواندن {a.file}")
    data = extract(a.file)
    if not data:
        sys.exit("چیزی خوانده نشد.")

    basket = a.as_basket or ("fixed" if a.as_fixed else None)
    if basket:
        m = AS_BASKET[basket]
        data = {d: {m[k]: v for k, v in vals.items() if k in m}
                for d, vals in data.items()}
        data = {d: v for d, v in data.items() if v}
        print(f"  حالت سبد «{basket}»: "
              + "، ".join(f"{k} → {v}" for k, v in m.items())
              + "؛ بقیهٔ ستون‌ها کنار گذاشته شد.")

    if a.fixed:
        if basket:
            sys.exit("--fixed با --as/--as-fixed با هم معنی ندارند.")
        print(f"\nخواندن {a.fixed} (برای صندوق درآمد ثابت)")
        wide = extract(a.fixed)
        n = 0
        for d, vals in wide.items():
            base = data.get(d)
            if not base:
                continue
            for src, dst in DERIVED.items():
                if src in vals and src in base:
                    data[d][dst] = vals[src] - base[src]
                    n += 1
        print(f"  {n} مقدار صندوق درآمد ثابت از تفاضل ساخته شد.")

    days = sorted(data)
    print(f"\n{len(days)} روز — {days[0]} تا {days[-1]}")

    con = connect()

    all_series = sorted({s for v in data.values() for s in v})
    if a.overwrite is None:
        over = set()
    elif a.overwrite:
        over = set(a.overwrite)
        bad = over - set(all_series)
        if bad:
            sys.exit(f"سری ناشناخته در --overwrite: {'، '.join(bad)}")
    else:
        over = set(all_series)
    print("بازنویسی: " + ("—" if not over else "، ".join(sorted(over))))

    have = {s: existing(con, s) for s in all_series}

    stats, touched = {}, set()
    for d in days:
        for series, value in data[d].items():
            if d in have[series] and series not in over:
                stats[(series, "skipped")] = stats.get((series, "skipped"), 0) + 1
                continue
            res = upsert(con, d, series, value, SOURCE, a.file, dry=a.dry)
            k = res.split(":")[0]
            stats[(series, k)] = stats.get((series, k), 0) + 1
            if k in ("inserted", "updated"):
                touched.add(d)
    if touched and not a.dry:
        derive_totals(con, touched)

    print("\nنتیجه:")
    for series in all_series:
        parts = [f"{k} {n}" for (s, k), n in sorted(stats.items()) if s == series]
        print(f"  {series:14s} " + "، ".join(parts))
    if a.dry:
        print("\n(آزمایشی بود — چیزی نوشته نشد.)")
    else:
        print("\nحالا /publish بزنید تا صفحه دوباره ساخته شود.")
    con.close()


if __name__ == "__main__":
    main()
