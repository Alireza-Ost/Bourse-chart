# -*- coding: utf-8 -*-
"""
خروجی گرفتن از داده‌هایی که فقط «اینجا» وجود دارند، برای بسته‌بندی با کد.

مسئله‌ای که این فایل حل می‌کند: اکسل‌ها را شما در گفت‌وگو می‌فرستید و من
همان‌جا وارد دیتابیسِ خودم می‌کنم. آن دیتابیس روی کامپیوتر شما نیست و با
زیپِ کد هم نمی‌آید — پس هر چه از اکسل آمده بود، روی سایت شما غایب بود.
بقیهٔ داده‌ها این مشکل را نداشتند چون فایل خامشان (`data/tradersarena*.csv`،
`data/chartix/*.csv`، `data/pe_mofid.csv`) در زیپ هست و مهاجرت‌ها از روی
همان‌ها دیتابیس شما را پر می‌کنند.

پس دو فایل تازه ساخته می‌شود تا همان نقش را برای بقیه بازی کنند:

    data/industries.csv.gz   جدول صنایع — پیوت‌شده، یک ردیف برای هر (روز، صنعت)
    data/market_extra.csv    سری‌های بازاری که فایل خام ندارند
                             (نقدینگی تا ۱۴۰۱ از اکسل، و چند ورودی دستی)

خواندنشان در `migrate.py` است و همیشه **فقط جای خالی** را پر می‌کند.

    python export_bundle.py          ساخت هر دو فایل
    python export_bundle.py --stat   فقط گزارش، بی‌نوشتن
"""
import csv
import gzip
import sys

from config import BASE, IND_METRICS
from store import connect

IND_FILE = BASE / "data" / "industries.csv.gz"
EXTRA_FILE = BASE / "data" / "market_extra.csv"

# این منبع‌ها فایل خام ندارند، پس باید همراه کد سفر کنند.
# بقیه (chartix، tradersarena، mofid، xlsx_seed) فایل خودشان را دارند و
# دوباره فرستادنشان فقط حجم زیپ را بالا می‌برد.
EXTRA_SOURCES = ["m2_file", "manual", "json_restore"]

IND_COLS = list(IND_METRICS)


def export_industries(con, write=True):
    """
    `industry_obs` پیوت‌شده: یک ردیف برای هر (تاریخ، صنعت) و هشت ستون سری.

    چرا پیوت: خامش ۵۸۸ هزار ردیف است و تاریخ و کد صنعت در هر ردیف تکرار
    می‌شود. پیوت‌شده ۸۶ هزار ردیف می‌شود — همان داده، یک‌ششم حجم.

    ستون `source` هم می‌آید، چون نردبان اولویت منبع بدون آن معنی ندارد و
    ردیفی که از API روزانه آمده نباید جای ردیف اکسل را بگیرد یا برعکس.
    عملاً الان همه‌شان `tradersarena`اند، ولی ستونش می‌ماند تا اگر روزی
    منبع دیگری اضافه شد این فایل دوباره نویسی نخواهد.
    """
    rows = {}
    srcs = {}
    for date_j, ind, metric, value, source in con.execute(
            "SELECT date_j, ind, metric, value, source FROM industry_obs"):
        if metric not in IND_METRICS:
            continue
        rows.setdefault((date_j, ind), {})[metric] = value
        srcs.setdefault((date_j, ind), {})[metric] = source

    def one_source(d):
        """منبع غالب همان (روز، صنعت) — تقریباً همیشه یکی است."""
        vals = list(d.values())
        return max(set(vals), key=vals.count) if vals else "tradersarena"

    keys = sorted(rows)
    if write:
        with gzip.open(IND_FILE, "wt", encoding="utf-8", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["date_j", "ind", "source"] + IND_COLS)
            for k in keys:
                r = rows[k]
                w.writerow([k[0], k[1], one_source(srcs[k])]
                           + ["" if r.get(m) is None else round(r[m], 4)
                              for m in IND_COLS])
    cells = sum(len(r) for r in rows.values())
    return len(keys), cells


def clean_ref(ref):
    """
    ارجاع را از مسیر کامپیوترِ من پاک می‌کند.

    اکسل‌ها در گفت‌وگو آپلود می‌شوند و مسیرشان چیزی شبیه
    `/root/.claude/uploads/<شناسهٔ بلند>/<هش>_Book1.xlsx` است — روی
    کامپیوتر شما نه وجود دارد و نه معنی. فقط نام فایل می‌ماند، و پیشوند
    هشی هم که آپلودر جلوی نامش می‌گذارد برداشته می‌شود.
    """
    ref = (ref or "").strip()
    if "/" not in ref and "\\" not in ref:
        return ref
    name = ref.replace("\\", "/").rsplit("/", 1)[-1]
    if "_" in name and name.split("_", 1)[0].replace("-", "").isalnum() \
            and any(ch.isdigit() for ch in name.split("_", 1)[0]):
        name = name.split("_", 1)[1]
    return name


def export_extra(con, write=True):
    """سری‌های بازاری که فایل خام ندارند — با منبع و ارجاعشان."""
    rows = [(d, s, v, src, clean_ref(ref)) for d, s, v, src, ref in con.execute(
        "SELECT date_j, series, value, source, src_ref FROM observations "
        "WHERE source IN (%s) ORDER BY date_j, series"
        % ",".join("?" * len(EXTRA_SOURCES)), EXTRA_SOURCES)]
    if write:
        with open(EXTRA_FILE, "w", encoding="utf-8", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["date_j", "series", "value", "source", "src_ref"])
            w.writerows(rows)
    return len(rows)


def main(argv):
    write = "--stat" not in argv
    con = connect()
    days, cells = export_industries(con, write)
    n = export_extra(con, write)
    con.close()
    print(f"صنایع: {days:,} ردیف (روز×صنعت)، {cells:,} مقدار"
          + (f" → {IND_FILE.name} ({IND_FILE.stat().st_size:,} بایت)" if write else ""))
    print(f"سری‌های بی‌فایل: {n:,} مقدار"
          + (f" → {EXTRA_FILE.name} ({EXTRA_FILE.stat().st_size:,} بایت)" if write else ""))


if __name__ == "__main__":
    main(sys.argv[1:])
