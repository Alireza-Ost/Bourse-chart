# -*- coding: utf-8 -*-
"""
پرکردن چند روز اخیر دیده‌بان صنایع از صفحهٔ سوابق هر صنعت.

    python3 backfill_industries.py              همهٔ صنایع config
    python3 backfill_industries.py 44 27 57     فقط همین‌ها
    python3 backfill_industries.py --dry

── چرا لازم است
   برداشت روزانه از `data/industries-csv` می‌آید که **فقط امروز** را
   می‌دهد. اگر کامپیوتر چند روز خاموش باشد، آن روزها برای همیشه خالی
   می‌مانند. صفحهٔ `/industries/<کد>/history` اما ده روز آخر را دارد،
   جدولش را سرور می‌سازد (نه جاوااسکریپت) و برای مهمان هم باز است —
   پس همین اسکریپت عقب‌افتادگی تا ده روز را جبران می‌کند.

   بیشتر از ده روز با اشتراک و خروجی اکسل می‌آید:
   `import_industries.py`.

── ستون‌ها
   جدول سوابق زیرمجموعه‌ای از سیزده سری ما را دارد: ارزش معاملات، خرید و
   فروش حقیقی، سرانهٔ خرید و فروش، قدرت خرید، ورود پول. سفارش‌ها و
   بازدهی و درصدها در آن نیستند و فقط از برداشت روزانه می‌آیند — یعنی
   روزهای جبران‌شده این چهار سری را ندارند. این عمدی است و بهتر از
   حدس‌زدنشان.

   «شاخص گروه» هم در جدول هست ولی سری‌اش را نداریم؛ اگر خواستید یک سطر
   در `config.IND_METRICS` و یک سطر در `HEADERS` همین فایل بس است.
"""
import argparse
import re
import sys
import time

from config import INDUSTRIES
from import_industries import HEADERS, split_unit, divisor, SKIP_RE
from import_tradersarena import norm, number, date_j
from sources.common import get, strip_tags
from store import connect, upsert_ind

URL = "https://tradersarena.ir/industries/{code}/history"
SOURCE = "tradersarena"
PAUSE = 0.6                       # مهربانی با سرور

TABLE_RE = re.compile(r'<table[^>]*id="histo"[^>]*>(.*?)</table>', re.S)
ROW_RE = re.compile(r"<tr\b[^>]*>(.*?)</tr>", re.S)
CELL_RE = re.compile(r"<t[dh]\b[^>]*>(.*?)</t[dh]>", re.S)


def _text(html):
    return re.sub(r"\s+", " ", strip_tags(html)).strip()


def parse(html):
    """{date_j: {metric: value}} — از جدول سوابق یک صنعت."""
    m = TABLE_RE.search(html)
    if not m:
        return {}, ["جدول سوابق پیدا نشد (صفحه عوض شده؟)"]
    rows = [[_text(c) for c in CELL_RE.findall(r)] for r in ROW_RE.findall(m.group(1))]
    rows = [r for r in rows if r]
    if not rows:
        return {}, ["جدول سوابق خالی بود"]

    head = rows[0]
    cols, notes = {}, []
    for i, h in enumerate(head):
        if not h or SKIP_RE.search(norm(h)):
            continue
        base, unit = split_unit(h)
        metric = HEADERS.get(base)
        if metric is None:
            continue
        if metric == "_date":
            cols[i] = ("_date", 1.0)
            continue
        d = divisor(metric, unit)
        if d is None:
            notes.append(f"واحد نامفهوم: {base} ({unit})")
            continue
        cols[i] = (metric, d)

    if not any(m0 == "_date" for m0, _ in cols.values()):
        return {}, ["ستون تاریخ در جدول سوابق نبود"]

    out = {}
    for r in rows[1:]:
        d = None
        for i, (metric, _) in cols.items():
            if metric == "_date" and i < len(r):
                d = date_j(r[i])
        if not d:
            continue
        for i, (metric, div) in cols.items():
            if metric == "_date" or i >= len(r):
                continue
            v = number(r[i])
            if v is not None:
                out.setdefault(d, {})[metric] = v / div
    return out, notes


def run(codes=None, dry=False, log=print, session=None, con=None):
    codes = [c.zfill(2) for c in (codes or INDUSTRIES)]
    bad = [c for c in codes if c not in INDUSTRIES]
    if bad:
        log(f"⚠ کد ناشناخته، رد شد: {'، '.join(bad)}")
        codes = [c for c in codes if c in INDUSTRIES]

    own = con is None
    con = con or connect()
    total, days_seen = 0, set()
    for n, code in enumerate(codes, 1):
        try:
            html = get(URL.format(code=code), session)
        except Exception as e:
            log(f"  {INDUSTRIES[code]}: در دسترس نبود ({type(e).__name__})")
            continue
        data, notes = parse(html)
        for note in notes:
            log(f"  {INDUSTRIES[code]}: ⚠ {note}")
        added = 0
        for d in sorted(data):
            days_seen.add(d)
            for metric, value in data[d].items():
                if upsert_ind(con, d, code, metric, value, SOURCE,
                              f"industries/{code}/history",
                              dry=dry, only_new=True) == "inserted":
                    added += 1
        total += added
        log(f"  {INDUSTRIES[code]:24s} {len(data):2d} روز خوانده شد، {added:3d} مقدار تازه")
        if not dry:
            con.commit()
        if n < len(codes):
            time.sleep(PAUSE)
    if own:
        con.close()

    span = f"{min(days_seen)} تا {max(days_seen)}" if days_seen else "—"
    return total, span


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("codes", nargs="*", help="کد صنعت؛ خالی یعنی همه")
    ap.add_argument("--dry", action="store_true")
    a = ap.parse_args()
    print(f"پرکردن ده روز اخیر برای "
          f"{len(a.codes) or len(INDUSTRIES)} صنعت…\n")
    total, span = run(a.codes or None, dry=a.dry)
    print(f"\n{total} مقدار تازه ({span}).")
    if a.dry:
        print("(آزمایشی بود — چیزی نوشته نشد.)")
    else:
        print("حالا /publish بزنید.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
