@echo off
REM ===================================================================
REM  Fill in the missing days from the Telegram channel archives.
REM  Run this ONCE, and leave it. It takes roughly 30-60 minutes to
REM  walk back to 1399, and it resumes where it stopped if interrupted,
REM  so you can close it and run it again later.
REM
REM      backfill.bat                 everything back to 1399/03
REM      backfill.bat --since 14040101
REM      backfill.bat --dry           show what WOULD be filled
REM
REM  Uses t.me, which must open on this machine.
REM  Messages are ASCII on purpose - the console mangles Persian.
REM ===================================================================
setlocal
cd /d "%~dp0"

where python >nul 2>nul && (set "PY=python") || (set "PY=py")

echo.
echo === Walking the channel archives. This takes a while - leave it running.
echo === Ctrl+C is safe: it saves its place and resumes next time.
echo.
%PY% backfill.py %*
if errorlevel 1 (
  echo.
  echo [X] Backfill failed. If t.me does not open on this machine, this
  echo     step cannot work - everything else still does.
  echo.
  pause & exit /b 1
)

echo.
echo Done. Run update.bat to rebuild and publish the page.
echo.
pause
