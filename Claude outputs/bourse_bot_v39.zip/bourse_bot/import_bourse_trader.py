# -*- coding: utf-8 -*-
"""
وارد کردن تاریخچهٔ صنایع از bourse-trader.ir.

    python import_bourse_trader.py history.xlsx
    python import_bourse_trader.py history.xlsx --dry
    python import_bourse_trader.py history.xlsx --all      همهٔ شانزده سری

چرا این منبع: **P/E صنعت** هیچ جای دیگری که به آن می‌رسیم نیست. نه اکسل
صنعتی تریدرزآرنا ستونش را دارد، نه صفحهٔ سوابقش، نه API صفحهٔ اول.
bourse-trader.ir هم P/E گروه را می‌دهد و هم شاخص گروه، آن هم با تاریخچه.

قالب ورودی: اکسلی که هر شیتش یک صنعت است و ستون‌هایش همان شانزده سری
استاندارد. ردیف اول نام ستون، ردیف دوم واحد، از ردیف سوم داده.

⚠ پیش‌فرض فقط `pe` و `gindex` را می‌آورد. بقیهٔ سری‌ها (ارزش معاملات،
  ورود پول، سرانه‌ها) را از تریدرزآرنا داریم و روی ۸۴۴ روز مشترک نسبت
  میانه‌شان ۱٫۰۰۱ بود — یعنی یک عددند. دوباره‌کاری است، و بدتر: اگر یکی
  از دو منبع روزی تعریفش را عوض کند، وسط سری پله می‌افتد. با `--all`
  می‌شود همه را آورد.

⚠ مثل بقیهٔ واردکردن‌ها فقط **جای خالی** پر می‌شود.
"""
import sys

from config import INDUSTRIES, IND_METRICS
from store import connect, upsert_ind

# نام شیت (۳۱ نویسهٔ اول، همان‌طور که اکسل کوتاهش می‌کند) -> کد صنعت نزد ما.
# کد خودِ سایت برای صنایع واقعی همان کد رسمی بورس است؛ سبدهای صندوق کد
# داخلی دارند و دستی نگاشت شده‌اند.
SITE_GROUPS = [
    ("6824", "صندوق‌های سرمایه‌گذاری زعفران", "saffron-funds"),
    ("6823", "صندوق‌های سرمایه‌گذاری نقره", "silver-funds"),
    ("6822", "صندوق‌های سرمایه‌گذاری طلا", "gold-funds"),
    ("6821", "صندوق‌های سرمایه‌گذاری اهرمی", "leveraged-funds"),
    ("6820", "صندوق‌های سرمایه‌گذاری انرژی", "energy-funds"),
    ("6819", "صندوق‌های سرمایه‌گذاری بخشی", "sector-funds"),
    ("6818", "صندوق‌های سرمایه‌گذاری املاک و مستغلات", "real-state-funds"),
    ("6817", "صندوق‌های سرمایه‌گذاری در صندوق", "fund-in-funds"),
    ("6816", "صندوق‌های سرمایه‌گذاری خصوصی", None),
    ("6815", "صندوق‌های سرمایه‌گذاری جسورانه", None),
    ("6814", "صندوق‌های سرمایه‌گذاری پروژه", None),
    ("6812", "صندوق‌های سرمایه‌گذاری درآمد ثابت", "fixed-income-funds"),
    ("6811", "صندوق‌های سرمایه‌گذاری سهامی", "stock-funds"),
    ("6810", "صندوق‌های سرمایه‌گذاری مختلط", "mixed-funds"),
    ("68", "صندوق سرمايه گذاري قابل معامله", None),
]
# بقیه: کد سایت = کد بورس، فقط صفر ابتدایی را اضافه می‌کنیم
SITE_NAMES = """44 محصولات شيميايي|27 فلزات اساسي|23 فراورده هاي نفتي، كك و سوخت هسته اي
|13 استخراج کانه هاي فلزي|34 خودرو و ساخت قطعات|57 بانكها و موسسات اعتباري
|39 شرکتهاي چند رشته اي صنعتي|43 مواد و محصولات دارويي|56 سرمايه گذاريها
|42 محصولات غذايي و آشاميدني به جز قند و شكر|53 سيمان، آهك و گچ
|70 انبوه سازي، املاك و مستغلات|1 زراعت و خدمات وابسته|54 ساير محصولات كاني غيرفلزي
|66 بيمه وصندوق بازنشستگي به جزتامين اجتماعي|72 رايانه و فعاليت‌هاي وابسته به آن
|38 قند و شكر|60 حمل ونقل، انبارداري و ارتباطات|29 ماشين آلات و تجهيزات
|67 فعاليتهاي كمكي به نهادهاي مالي واسط|28 ساخت محصولات فلزي|25 لاستيك و پلاستيك
|58 ساير واسطه گريهاي مالي|40 عرضه برق، گاز، بخاروآب گرم|31 ماشين آلات و دستگاه‌هاي برقي
|49 كاشي و سراميك|10 استخراج زغال سنگ|74 خدمات فني و مهندسي
|26 توليد محصولات كامپيوتري الكترونيكي ونوري|19 دباغي، پرداخت چرم و ساخت انواع پاپوش
|46 تجارت عمده فروشي به جز وسايل نقليه موتور|11 استخراج نفت گاز و خدمات جنبي جز اکتشاف
|14 استخراج ساير معادن|17 منسوجات|20 محصولات چوبي|21 محصولات كاغذي
|22 انتشار، چاپ و تکثير|55 هتل و رستوران|71 فعاليت مهندسي، تجزيه، تحليل و آزمايش فني
|45 پيمانكاري صنعتي|61 حمل و نقل آبي|64 مخابرات|32 ساخت دستگاه‌ها و وسايل ارتباطي
|84 سلامت انسان و مددکاری اجتماعی|93 فعالیتهای فرهنگی و ورزشی
|90 فعاليت هاي هنري، سرگرمي و خلاقانه|47 خرده فروشي،باستثناي وسايل نقليه موتوري
|73 اطلاعات و ارتباطات"""

# ستون اکسل -> سری ما
COLUMNS = {
    "P/E گروه": "pe",
    "شاخص گروه": "gindex",
    "ارزش معاملات": "value",
    "ورود پول حقیقی": "flow",
    "سرانه خرید حقیقی": "sarane_buy",
    "سرانه فروش حقیقی": "sarane_sell",
    "ارزش خرید حقیقی": "buy_real",
    "ارزش فروش حقیقی": "sell_real",
}
DEFAULT_METRICS = ("pe", "gindex")


def sheet_map():
    """نام شیت (کوتاه‌شده به ۳۱ نویسه) -> کد صنعت نزد ما."""
    out = {}
    for _, name, ours in SITE_GROUPS:
        out[name[:31]] = ours
    for item in SITE_NAMES.replace("\n", "").split("|"):
        cid, name = item.strip().split(" ", 1)
        out[name.strip()[:31]] = cid.zfill(2)
    return out


def num(v):
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).replace(",", "").strip())
    except ValueError:
        return None


def run(path, metrics, dry=False, log=print):
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    smap = sheet_map()
    con = connect()
    added, per_metric, unknown, no_code = 0, {}, [], []

    for sheet in wb.sheetnames:
        if sheet in ("فهرست", "راهنما", "همه داده‌ها"):
            continue
        code = smap.get(sheet)
        if code is None:
            (no_code if sheet in smap else unknown).append(sheet)
            continue
        if code not in INDUSTRIES:
            no_code.append(f"{sheet} ({code})")
            continue

        ws = wb[sheet]
        it = ws.iter_rows(values_only=True)
        head = next(it, None)
        next(it, None)                      # ردیف واحدها
        if not head:
            continue
        cols = {}
        for i, h in enumerate(head):
            key = COLUMNS.get(str(h or "").strip())
            if key and key in metrics and key in IND_METRICS:
                cols[key] = i

        for row in it:
            date_j = str(row[0] or "").replace("/", "").strip()
            if len(date_j) != 8 or not date_j.isdigit():
                continue
            for key, i in cols.items():
                v = num(row[i]) if i < len(row) else None
                if v is None:
                    continue
                res = upsert_ind(con, date_j, code, key, v, "bourse_trader",
                                 "bourse-trader.ir · گزارش سابقه صنایع",
                                 dry=dry, only_new=True)
                if res == "inserted":
                    added += 1
                    per_metric[key] = per_metric.get(key, 0) + 1

    if not dry:
        con.commit()
    con.close()

    log(f"{added:,} مقدار تازه" + (" (آزمایشی — چیزی نوشته نشد)" if dry else ""))
    for k, n in sorted(per_metric.items(), key=lambda x: -x[1]):
        log(f"  {IND_METRICS[k][0]}: {n:,}")
    if no_code:
        log(f"  رد شد (در config نیست): {len(no_code)} — " + "، ".join(no_code[:4]))
    if unknown:
        log(f"  ⚠ شیت ناشناخته: {len(unknown)} — " + "، ".join(unknown[:4]))
    return added


def main(argv):
    paths = [a for a in argv if not a.startswith("--")]
    if not paths:
        sys.exit(__doc__)
    metrics = tuple(COLUMNS.values()) if "--all" in argv else DEFAULT_METRICS
    run(paths[0], metrics, dry="--dry" in argv)


if __name__ == "__main__":
    main(sys.argv[1:])
