#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
پرکردن روزهای جامانده از آرشیو وبِ کانال‌ها.

    python3 backfill.py                      همه‌چیز تا ۱۳۹۹/۰۳
    python3 backfill.py --since 14040101     فقط از این تاریخ به بعد
    python3 backfill.py --channel Bourseiness
    python3 backfill.py --pages 100          یک تکه؛ دفعهٔ بعد از همان‌جا ادامه
    python3 backfill.py --dry                فقط بگو چه چیزی پر می‌شد

چرا لازم است: ربات فقط پست‌های تازه را می‌گیرد. هر روزی که کامپیوتر خاموش
بوده یا پستی فوروارد نشده، یک سوراخ در سری ساخته — در دادهٔ شما حدود ۳۰۰
روز از این دست هست، بیشترشان تک‌روز، به‌علاوهٔ یک تکهٔ ۷ روزه در دههٔ آخر
دی ۱۴۰۴.

تلگرام برای هر کانال عمومی یک نسخهٔ وب دارد که با `?before=<id>` ورق
می‌خورد و تا ابتدای کانال عقب می‌رود:

    parsistahlil  تا مهر ۱۳۹۸
    Bourseiness   تا دی ۱۳۹۴

همان پارسرهایی که برای پست‌های فورواردشده نوشته شده‌اند روی این متن‌ها هم
کار می‌کنند، پس چیز تازه‌ای یاد نمی‌گیریم — فقط متن از جای دیگری می‌آید.

کار را تکه‌تکه می‌کند و جایش را در دیتابیس نگه می‌دارد، پس اگر وسطش قطع
شد دفعهٔ بعد از همان‌جا ادامه می‌دهد.
"""
import argparse
import re
import sys
import time

import jdatetime

from sources.common import get
from sources.parsis_web import posts, POST_RE
from store import connect, upsert, derive_totals, get_setting, set_setting

# کانال -> (نام پارسر، نام منبع برای اولویت)
CHANNELS = {
    "parsistahlil": "parsis",
    "Bourseiness": "bourseiness",
}

URL = "https://t.me/s/{ch}"
PAUSE = 0.5          # مؤدب باشیم؛ آرشیو تلگرام رایگان است، سوءاستفاده نکنیم
DEFAULT_SINCE = "13990301"


def page(ch, before=None, tries=4):
    u = URL.format(ch=ch) + (f"?before={before}" if before else "")
    for i in range(tries):
        try:
            return get(u)
        except Exception:                                  # noqa: BLE001
            if i == tries - 1:
                raise
            time.sleep(1.5 * (i + 1))


def jalali(d):
    return jdatetime.date.fromgregorian(date=d).strftime("%Y%m%d")


def run(con, channel, since=DEFAULT_SINCE, max_pages=0, dry=False, log=print,
        resume=True):
    """
    خروجی: dict با آمار کار.

    since: تا این تاریخ شمسی عقب می‌رود و می‌ایستد.
    max_pages: ۰ یعنی بی‌نهایت (تا رسیدن به since یا ته کانال).
    """
    import parsers
    fn = parsers.PARSERS[CHANNELS[channel]]
    key = f"backfill_{channel}"
    before = int(get_setting(con, key, "0") or 0) if resume else 0

    seen_days, wrote, pages, oldest = set(), {}, 0, None
    touched = set()
    try:
        while True:
            html = page(channel, before or None)
            ids = [int(x) for x in POST_RE.findall(html)]
            if not ids:
                log("  ته کانال.")
                break
            for text, when in posts(html):
                for date_j, series, value, _wd in fn(text, when):
                    if date_j < since:
                        continue
                    seen_days.add(date_j)
                    res = upsert(con, date_j, series, value, channel,
                                 f"t.me/s/{channel} (آرشیو)", dry=dry)
                    if res.split(":")[0] in ("inserted", "updated"):
                        wrote[series] = wrote.get(series, 0) + 1
                        touched.add(date_j)
            before = min(ids)
            pages += 1
            if seen_days:
                oldest = min(seen_days)
            if not dry:
                set_setting(con, key, before)
            if pages % 25 == 0:
                log(f"  {pages} صفحه · قدیمی‌ترین روزِ دیده‌شده {oldest or '—'}"
                    f" · {sum(wrote.values())} مقدار")
            if oldest and oldest < since:
                log(f"  به {since} رسیدیم.")
                break
            if max_pages and pages >= max_pages:
                log(f"  {max_pages} صفحه تمام شد — دفعهٔ بعد از همین‌جا ادامه.")
                break
            time.sleep(PAUSE)
    except KeyboardInterrupt:
        log("  متوقف شد (جا ذخیره شد).")
    except Exception as e:                                  # noqa: BLE001
        log(f"  خطا: {e} — تا همین‌جا ذخیره شد.")

    if touched and not dry:
        derive_totals(con, touched)
    return {"pages": pages, "days": len(seen_days), "oldest": oldest,
            "wrote": wrote, "before": before}


def report(stats, channel):
    n = sum(stats["wrote"].values())
    head = (f"<b>{channel}</b> — {stats['pages']} صفحه، "
            f"{stats['days']} روز دیده شد، {n} مقدار نوشته شد")
    if not stats["wrote"]:
        return head + "\nچیز تازه‌ای نبود."
    lines = [head, ""]
    for k, v in sorted(stats["wrote"].items(), key=lambda x: -x[1]):
        lines.append(f"  {k:14s} {v}")
    if stats["oldest"]:
        lines.append(f"\nتا {stats['oldest']} عقب رفت.")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--channel", choices=list(CHANNELS), action="append")
    ap.add_argument("--since", default=DEFAULT_SINCE)
    ap.add_argument("--pages", type=int, default=0)
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--restart", action="store_true",
                    help="از نو شروع کن، نه از جایی که دفعهٔ قبل ماند")
    a = ap.parse_args()

    con = connect()
    for ch in (a.channel or list(CHANNELS)):
        print(f"\n=== {ch} ===")
        st = run(con, ch, a.since, a.pages, a.dry, resume=not a.restart)
        print(re.sub(r"</?b>", "", report(st, ch)))
    con.close()


if __name__ == "__main__":
    sys.exit(main())
