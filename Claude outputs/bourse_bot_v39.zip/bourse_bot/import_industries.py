# -*- coding: utf-8 -*-
"""
وارد کردن خروجی «سوابق» یک صنعت از تریدرزآرنا.

    python3 import_industries.py 44.xlsx --ind 44
    python3 import_industries.py *.xlsx                  (کد از نام فایل)
    python3 import_industries.py 44.xlsx --ind 44 --dry
    python3 import_industries.py 44.xlsx --ind 44 --overwrite

هر صنعت یک فایل. کد صنعت همان عددی است که در آدرس صفحه‌اش می‌آید
(`/industries/44`) و در `config.INDUSTRIES` فهرست شده. اگر `--ind` را
ندهید، از نام فایل درمی‌آید — هر عددی دو تا سه‌رقمی که در نام باشد و در
`INDUSTRIES` شناخته شود.

── واحدها
   خودِ عنوان ستون واحد را می‌گوید و همان خوانده می‌شود:

       «ارزش معاملات (تومان)»          ÷ ۱۰^۹  → میلیارد تومان
       «ارزش معاملات (میلیارد تومان)»  همان‌طور
       «سرانه خرید (تومان)»            ÷ ۱۰^۶  → میلیون تومان
       «سرانه خرید (میلیون تومان)»     همان‌طور

   حدس زده نمی‌شود: ستونی که واحدش در عنوان نباشد و پیش‌فرضی هم نداشته
   باشد، کنار گذاشته می‌شود و در گزارش می‌آید. خروجی بازار تریدرزآرنا
   ستون‌هایش تومان بود؛ اگر صنایع میلیارد تومان بدهد، همین نگاشت خودش
   درستش می‌کند.

── ستون‌های تجمعی
   «ارزش معاملات ۵ روزه»، «سرانه خرید ۲۰ روزه» و مانندشان عمداً نوشته
   نمی‌شوند: از همین سری‌های روزانه درمی‌آیند، نمودار خودش EMA دارد، و
   اگر یک روز جا بیفتد میانگینِ منبع با سری روزانه ناهمخوان می‌شود.

── «فقط جای خالی»
   مثل بقیهٔ واردکردن‌ها، پیش‌فرض این است که روزی که از قبل عدد دارد
   دست نخورد. `--overwrite` این را برمی‌دارد.
"""
import argparse
import pathlib
import re
import sys

from config import INDUSTRIES, IND_METRICS
from import_tradersarena import norm, number, date_j, read_table
from store import connect, upsert_ind

SOURCE = "tradersarena"

# عنوان ستون (نرمال‌شده، بی‌واحد) -> کلید سری در IND_METRICS
HEADERS = {
    "تاریخ": "_date",
    "ارزش معاملات": "value",
    "ارزش خرید حقیقی": "buy_real",
    "ارزش فروش حقیقی": "sell_real",
    "شاخص گروه": "gindex",
    "ارزش سفارش های خرید": "bid",
    "ارزش سفارش های فروش": "ask",
    "برایند سفارش ها": "book",
    "برآیند سفارش ها": "book",
    "بازدهی گروه": "ret",
    "بازدهی گروه (هموزن)": "ret",
    "بازدهی": "ret",
    "سرانه خرید": "sarane_buy",
    "سرانه فروش": "sarane_sell",
    "قدرت خرید": "power",
    "درصد خرید حقیقی": "buy_share",
    "درصد فروش حقیقی": "sell_share",
    "ورود پول": "flow",
}

# واحد پیش‌فرض هر سری، برای وقتی عنوان واحد ندارد
BILLION = ("value", "buy_real", "sell_real", "flow")
MILLION = ("sarane_buy", "sarane_sell")
# تعداد کد و شاخص گروه عددِ خالص‌اند — تقسیم نمی‌شوند
UNITLESS = ("power", "gindex")

# ستون‌هایی که اگر در عنوان باشند، ستون تجمعی است و رد می‌شود
SKIP_RE = re.compile(r"(روزه|میانگین|جمع )")

UNIT_RE = re.compile(r"\(([^)]*)\)")

# واحد همیشه داخل پرانتز نیست. در خروجی اکسلِ بازار بود («ارزش معاملات
# (تومان)») ولی در جدول سوابق صنعت، واحد یک <span> جداست و پرانتز ندارد،
# پس متنِ سرستون می‌شود «ارزش معاملاتمیلیارد تومان». هر دو حالت باید
# خوانده شود. ترتیب از بلند به کوتاه است، وگرنه «میلیارد تومان» به
# «تومان» تقسیم می‌شود و عدد هزار برابر غلط می‌شود.
UNITS = ("میلیارد تومان", "میلیون تومان", "هزار تومان", "تومان", "ریال", "درصد")


def split_unit(head):
    """
    'ارزش معاملات (تومان)'        → ('ارزش معاملات', 'تومان')
    'ارزش معاملاتمیلیارد تومان'   → ('ارزش معاملات', 'میلیارد تومان')
    'قدرت خرید'                   → ('قدرت خرید', '')
    """
    m = UNIT_RE.search(head)
    if m:
        return norm(UNIT_RE.sub(" ", head)), norm(m.group(1))
    t = norm(head)
    for u in UNITS:
        if t.endswith(u) and len(t) > len(u):
            return t[: -len(u)].strip(), u
    return t, ""


def divisor(metric, unit):
    """مقسوم‌علیهی که مقدار را به واحد دیتابیس می‌برد، یا None اگر نشد."""
    if metric in UNITLESS:
        return 1.0
    if unit == "تومان":
        return 1e9 if metric in BILLION else 1e6
    if unit in ("میلیارد تومان",):
        return 1.0 if metric in BILLION else None
    if unit in ("میلیون تومان",):
        return 1.0 if metric in MILLION else None
    if not unit:                        # عنوان واحد نداشت — پیش‌فرض
        return 1.0
    return None


def sheet_title(path):
    """نام شیت اول فایل، یا ''. برای csv بی‌معنی است."""
    if not str(path).lower().endswith((".xlsx", ".xlsm", ".xls")):
        return ""
    import warnings
    from openpyxl import load_workbook
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        wb = load_workbook(str(path), read_only=True, data_only=True)
        return wb.sheetnames[0] if wb.sheetnames else ""


SHEET_PREFIX = "tradersarena.ir-"


def candidates(path):
    """
    کدهای صنعتی که با نام شیت می‌خوانند.

    ⚠ از نام *فایل* استفاده نمی‌شود: مرورگر و پیام‌رسان حروف فارسی را از
      نام فایل می‌اندازند و آنچه می‌ماند پر از عدد است (تاریخ، شناسه) که
      تصادفاً کد صنعت هم می‌شود. نام شیت اما داخل خود فایل است و سالم
      می‌ماند: «tradersArena.ir-استخراج کانه ها».

    اکسل نام شیت را به ۳۱ نویسه می‌برد، پس نام صنعت بریده است و تطبیق
      «سرآغازی» است نه برابری. همین گاهی مبهم می‌شود — «ساخت دستگاههای »
      هم سرآغاز «برقی» است و هم «ارتباطی». آن را `resolve` با خود داده
      حل می‌کند.
    """
    title = norm(sheet_title(path))
    low = title.lower()
    if low.startswith(SHEET_PREFIX):
        title = title[len(SHEET_PREFIX):].strip()
    if not title:
        return []
    # نام‌ها را هم نرمال می‌کنیم: «بانکها» در شیت و «بانک‌ها» در config
    # با نیم‌فاصله فرق دارند، و norm نیم‌فاصله را فاصله می‌کند.
    def flat(s):
        return norm(s).replace(" ", "")
    key = flat(title)
    out = [c for c, n in INDUSTRIES.items() if flat(n).startswith(key)]
    if len(out) > 1:
        exact = [c for c in out if flat(INDUSTRIES[c]) == key]
        if exact:
            return exact
    return out


def resolve(con, path, data, log=print):
    """
    کد صنعت این فایل. اگر نام شیت مبهم بود، با خودِ داده تصمیم می‌گیرد:
    روزی که هم در فایل است و هم در دیتابیس، ارزش معاملاتش را مقایسه
    می‌کند و هر کدام خواند همان است. اگر دیتابیس هنوز دادهٔ صنایع نداشته
    باشد، None برمی‌گردد و باید `--ind` بدهید.
    """
    cands = candidates(path)
    if len(cands) == 1:
        return cands[0]
    if not cands:
        log("  ⚠ نام شیت با هیچ صنعتی نخواند.")
        return None
    log(f"  نام شیت مبهم است ({'، '.join(INDUSTRIES[c] for c in cands)}) "
        f"— از روی داده تصمیم می‌گیرم…")
    for c in cands:
        have = dict(con.execute(
            "SELECT date_j, value FROM industry_obs WHERE ind=? AND metric='value'",
            (c,)))
        for d, vals in data.items():
            mine, theirs = vals.get("value"), have.get(d)
            if mine is None or not theirs:
                continue
            if abs(mine - theirs) <= 0.01 * abs(theirs):
                log(f"  → {INDUSTRIES[c]} (ارزش {d} خواند: "
                    f"{mine:,.1f} ≈ {theirs:,.1f})")
                return c
    log("  ⚠ با داده هم حل نشد — با --ind کد را بدهید.")
    return None


def extract(path, log=print):
    """{date_j: {metric: value}} با واحد دیتابیس"""
    table = read_table(path)
    if not table:
        log("  خالی بود.")
        return {}

    cols, skipped = {}, []
    for h in table[0]:
        if not h:
            continue
        if SKIP_RE.search(h):
            continue
        base, unit = split_unit(h)
        metric = HEADERS.get(base)
        if metric is None:
            continue
        # گاردِ آخر: سری‌ای که در config نیست ذخیره نمی‌شود، وگرنه ستونی
        # که از جدول برداشته‌ایم بی‌صدا در دیتابیس جمع می‌شود.
        if metric != "_date" and metric not in IND_METRICS:
            continue
        if metric == "_date":
            cols[h] = ("_date", 1.0)
            continue
        d = divisor(metric, unit)
        if d is None:
            skipped.append(f"{base} ({unit})")
            continue
        cols[h] = (metric, d)

    found = sorted({m for m, _ in cols.values()} - {"_date"})
    log(f"  ستون‌ها: {'، '.join(found) or '—'}")
    if skipped:
        log(f"  ⚠ واحد نامفهوم، رد شد: {'، '.join(skipped)}")
    if not any(m == "_date" for m, _ in cols.values()):
        log("  ⚠ ستون «تاریخ» پیدا نشد.")
        return {}

    out = {}
    for row in table:
        d = None
        for h, (m, _) in cols.items():
            if m == "_date":
                d = date_j(row.get(h))
                break
        if not d:
            continue
        for h, (m, div) in cols.items():
            if m == "_date":
                continue
            v = number(row.get(h))
            if v is not None:
                out.setdefault(d, {})[m] = v / div
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+", help="خروجی سوابق صنعت (xlsx یا csv)")
    ap.add_argument("--ind", help="کد صنعت؛ نداده باشید از نام فایل درمی‌آید")
    ap.add_argument("--dry", action="store_true", help="فقط گزارش بده")
    ap.add_argument("--overwrite", action="store_true",
                    help="روزهای موجود را هم بازنویسی کن")
    a = ap.parse_args()
    if a.ind and len(a.files) > 1:
        sys.exit("--ind با چند فایل معنی ندارد؛ کد را از نام فایل می‌خوانم.")

    con = connect()
    total = 0
    for path in a.files:
        print(f"\n{pathlib.Path(path).name}")
        data = extract(path)
        if not data:
            continue
        code = a.ind.zfill(2) if a.ind else resolve(con, path, data)
        if not code or code not in INDUSTRIES:
            print("  رد شد.")
            continue
        print(f"  صنعت: {INDUSTRIES[code]} ({code})")
        days = sorted(data)
        print(f"  {len(days)} روز — {days[0]} تا {days[-1]}")

        stats = {}
        for d in days:
            for metric, value in data[d].items():
                res = upsert_ind(con, d, code, metric, value, SOURCE, path,
                                 dry=a.dry, only_new=not a.overwrite)
                stats[(metric, res)] = stats.get((metric, res), 0) + 1
                if res in ("inserted", "updated"):
                    total += 1
        if not a.dry:
            con.commit()
        for metric in sorted({m for m, _ in stats}):
            parts = [f"{r} {n}" for (m, r), n in sorted(stats.items()) if m == metric]
            print(f"    {metric:12s} " + "، ".join(parts))

    print(f"\nجمع: {total} مقدار {'می‌شد نوشت' if a.dry else 'نوشته شد'}.")
    if a.dry:
        print("(آزمایشی بود — چیزی نوشته نشد.)")
    else:
        print("حالا /publish بزنید تا صفحه دوباره ساخته شود.")
    con.close()


if __name__ == "__main__":
    main()
