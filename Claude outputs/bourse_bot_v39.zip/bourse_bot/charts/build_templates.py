#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ساخت دو قالب صفحهٔ نمودار از روی head.html + app.js.

    python3 charts/build_templates.py

    template.html      داده به جای __DATA__ می‌نشیند (برای دیدن روی کامپیوتر)
    template_web.html  داده را از data.json کناری می‌خواند (برای اینترنت)

صفحه در دو جا استفاده می‌شود، پس منبعش یکی است: هر تغییری در ظاهر یا رفتار
نمودار فقط در head.html و app.js نوشته می‌شود و این اسکریپت هر دو قالب را
دوباره می‌سازد. دست‌کاری مستقیم قالب‌ها یعنی دفعهٔ بعد بازنویسی می‌شود.
"""
import pathlib

HERE = pathlib.Path(__file__).parent
head = (HERE / "head.html").read_text(encoding="utf-8")
app = (HERE / "app.js").read_text(encoding="utf-8")

DOC_OPEN = ("<!doctype html><html lang='fa' dir='rtl'><head><meta charset='utf-8'>"
            "<meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'>"
            "<style>html,body{margin:0}[hidden]{display:none!important}</style></head><body>")
DOC_CLOSE = "</body></html>"

(HERE / "template.html").write_text(
    DOC_OPEN + head + "\n<script>\nconst DATA=__DATA__;\n" + app + "\n</script>\n" + DOC_CLOSE,
    encoding="utf-8")

# ---- کادر کد ورود -------------------------------------------------------
# فقط در نسخهٔ وب. __GATE__ هنگام ساخت صفحه با هش SHA-256 کد جایگزین
# می‌شود؛ خالی که باشد کادر اصلاً نشان داده نمی‌شود.
#
# ⚠ این یک «در» است، نه قفل. صفحه روی GitHub Pages ایستاست و data.json
#   کنارش عمومی می‌ماند: هر کسی آدرس داده را مستقیم باز کند، بدون کد
#   همه‌چیز را دارد. کادر جلوی رهگذر را می‌گیرد، نه کسی را که بلد است.
#   خودِ کد در سورس نیست (فقط هشش هست)، ولی داده هست.
GATE = (
    "<div id='gate' hidden style=\"position:fixed;inset:0;z-index:99;display:flex;"
    "align-items:center;justify-content:center;background:var(--bg,#faf9f5);"
    "font-family:Vazirmatn,system-ui,sans-serif\">"
    "<form id='gateForm' style=\"display:flex;flex-direction:column;gap:14px;width:min(320px,86vw);"
    "text-align:center\">"
    "<div style=\"font-size:17px;font-weight:700;color:var(--ink,#201f1c)\">بورس تهران</div>"
    "<div id='gateMsg' style=\"font-size:13px;color:var(--muted,#82857a)\">کد ورود را وارد کنید</div>"
    "<input id='gateIn' type='password' inputmode='numeric' autocomplete='off' "
    "style=\"padding:11px 14px;border:1px solid var(--line,#e5e3dc);border-radius:9px;"
    "background:var(--surface,#fff);color:var(--ink,#201f1c);font:inherit;font-size:16px;"
    "text-align:center;letter-spacing:3px\">"
    "<button type='submit' style=\"padding:11px;border:0;border-radius:9px;"
    "background:var(--ink,#201f1c);color:var(--bg,#faf9f5);font:inherit;font-weight:600;"
    "cursor:pointer\">ورود</button>"
    "</form></div>\n"
    "<script>\n"
    "var GATE=\"__GATE__\";\n"
    "/* SHA-256 خالص، چون crypto.subtle روی file:// در دسترس نیست */\n"
    "function sha256(a){function b(x,n){return x>>>n|x<<32-n}var k=[],h=[],p=2,i,j,r;\n"
    "for(i=0;i<64;){for(j=2,r=1;j*j<=p;j++)if(p%j==0){r=0;break}\n"
    "if(r){if(i<8)h[i]=(Math.pow(p,.5)%1*4294967296)|0;k[i]=(Math.pow(p,1/3)%1*4294967296)|0;i++}p++}\n"
    "var m=[],u=unescape(encodeURIComponent(a)),L=u.length;\n"
    "for(i=0;i<L;i++)m[i>>2]|=(u.charCodeAt(i)&255)<<24-(i%4)*8;\n"
    "m[L>>2]|=128<<24-(L%4)*8;m[((L+8>>6)+1<<4)-1]=L*8;\n"
    "var w=[],s,t1,t2,A,B,C,D,E,F,G,H;\n"
    "for(i=0;i<m.length;i+=16){A=h[0];B=h[1];C=h[2];D=h[3];E=h[4];F=h[5];G=h[6];H=h[7];\n"
    "for(j=0;j<64;j++){if(j<16)w[j]=m[i+j]|0;else{var g0=b(w[j-15],7)^b(w[j-15],18)^w[j-15]>>>3,\n"
    "g1=b(w[j-2],17)^b(w[j-2],19)^w[j-2]>>>10;w[j]=w[j-16]+g0+w[j-7]+g1|0}\n"
    "t1=H+(b(E,6)^b(E,11)^b(E,25))+(E&F^~E&G)+k[j]+w[j]|0;\n"
    "t2=(b(A,2)^b(A,13)^b(A,22))+(A&B^A&C^B&C)|0;\n"
    "H=G;G=F;F=E;E=D+t1|0;D=C;C=B;B=A;A=t1+t2|0}\n"
    "h[0]=h[0]+A|0;h[1]=h[1]+B|0;h[2]=h[2]+C|0;h[3]=h[3]+D|0;\n"
    "h[4]=h[4]+E|0;h[5]=h[5]+F|0;h[6]=h[6]+G|0;h[7]=h[7]+H|0}\n"
    "for(s='',i=0;i<8;i++)s+=('00000000'+(h[i]>>>0).toString(16)).slice(-8);return s}\n"
    "var gate=document.getElementById('gate');\n"
    "function remember(v){try{localStorage.setItem('gate',v)}catch(e){}}\n"
    "function remembered(){try{return localStorage.getItem('gate')}catch(e){return null}}\n"
    "function unlock(){gate.remove();load()}\n"
    "if(!GATE||GATE.indexOf('_')===0){ load(); }\n"
    "else if(remembered()===GATE){ unlock(); }\n"
    "else{ gate.hidden=false; document.getElementById('gateIn').focus();\n"
    "  document.getElementById('gateForm').addEventListener('submit',function(e){\n"
    "    e.preventDefault();\n"
    "    var el=document.getElementById('gateIn');\n"
    "    if(sha256(el.value.trim())===GATE){ remember(GATE); unlock(); }\n"
    "    else{ document.getElementById('gateMsg').textContent='کد درست نیست.';\n"
    "          document.getElementById('gateMsg').style.color='#d4443a';\n"
    "          el.value=''; el.focus(); }\n"
    "  });\n"
    "}\n"
    "</script>\n")

boot = (
    "<div id='boot' hidden style=\"padding:24px;font-family:Vazirmatn,system-ui,sans-serif;"
    "color:#82857a\">در حال بارگذاری داده…</div>\n"
    "<script>\nwindow.__boot=function(DATA){\n" + app + "\n};\n"
    "function load(){\n"
    "document.getElementById('boot').hidden=false;\n"
    "fetch('data.json?v='+Date.now())\n"
    "  .then(function(r){ if(!r.ok) throw new Error('HTTP '+r.status); return r.json(); })\n"
    "  .then(function(d){ document.getElementById('boot').remove();"
    " document.getElementById('appwrap').hidden=false; window.__boot(d); })\n"
    "  .catch(function(e){ document.getElementById('boot').textContent="
    "'داده بارگذاری نشد ('+e.message+'). مطمئن شوید data.json کنار همین صفحه است.'; });\n"
    "}\n"
    "</script>\n")

# ترتیب مهم است: تابع load باید قبل از اسکریپت کادر تعریف شده باشد.
web = DOC_OPEN + head + "\n" + boot + GATE + DOC_CLOSE
web = web.replace('<div class="app">', '<div class="app" hidden id="appwrap">', 1)
(HERE / "template_web.html").write_text(web, encoding="utf-8")

for f in ("template.html", "template_web.html"):
    print(f"  charts/{f}: {(HERE/f).stat().st_size:,} bytes")
