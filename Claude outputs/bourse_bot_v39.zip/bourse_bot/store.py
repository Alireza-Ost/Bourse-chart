# -*- coding: utf-8 -*-
"""
انبار داده (SQLite).

سه جدول:
  raw_messages — متن خام هر پیام فورواردشده. مهم‌ترین جدول:
                 اگر بعداً پارسر را اصلاح کنید، بدون فوروارد دوباره
                 می‌توانید کل تاریخچه را دوباره پارس کنید.
  observations — یک مقدار به ازای (تاریخ، سری). منبع ضعیف‌تر مقدار
                 منبع قوی‌تر را بازنویسی نمی‌کند.
  rejected     — هر مقداری که اعتبارسنجی ردش کرده، با دلیل.
"""
import shutil
import sqlite3
import datetime
from config import (DB_PATH, DATA_HOME, SEED_DB, LEGACY_DB,
                    SOURCE_PRIORITY, MAX_DAILY_MOVE, EW_RATIO_RANGE)

SCHEMA = """
CREATE TABLE IF NOT EXISTS raw_messages (
    msg_uid     TEXT PRIMARY KEY,     -- chat_id:message_id
    src_channel TEXT,
    src_msg_id  INTEGER,
    orig_date   TEXT,                 -- تاریخ اصلی پیام (میلادی) از forward_origin
    text        TEXT,
    received_at TEXT
);
CREATE TABLE IF NOT EXISTS observations (
    date_j      TEXT NOT NULL,
    series      TEXT NOT NULL,
    value       REAL NOT NULL,
    source      TEXT NOT NULL,
    src_ref     TEXT,
    ingested_at TEXT,
    PRIMARY KEY (date_j, series)
);
CREATE TABLE IF NOT EXISTS rejected (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    date_j      TEXT, series TEXT, value REAL,
    source      TEXT, reason TEXT, logged_at TEXT
);
CREATE TABLE IF NOT EXISTS settings (
    key         TEXT PRIMARY KEY,
    value       TEXT
);
CREATE INDEX IF NOT EXISTS ix_obs_series ON observations(series, date_j);

-- دیده‌بان صنایع. عمداً جدول جداست و با observations قاطی نمی‌شود:
-- بیست صنعت × سیزده سری = ۲۶۰ سری روزانه. اگر همه را به observations
-- می‌ریختیم، /missing و coverage و جدولِ صفحه زیرشان گم می‌شدند و هر
-- پرس‌وجوی ساده‌ای باید اول صنایع را فیلتر می‌کرد.
CREATE TABLE IF NOT EXISTS industry_obs (
    date_j      TEXT NOT NULL,
    ind         TEXT NOT NULL,        -- کد صنعت، مثل '44'
    metric      TEXT NOT NULL,        -- کلید در config.IND_METRICS
    value       REAL NOT NULL,
    source      TEXT NOT NULL,
    src_ref     TEXT,
    ingested_at TEXT,
    PRIMARY KEY (date_j, ind, metric)
);
CREATE INDEX IF NOT EXISTS ix_ind ON industry_obs(ind, metric, date_j);
"""


def get_setting(con, key, default=None):
    r = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return r[0] if r else default


def set_setting(con, key, value):
    con.execute("INSERT INTO settings VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, str(value)))
    con.commit()


def _ensure_db():
    """
    دیتابیس را سر جایش می‌آورد، بدون اینکه چیزی را خراب کند:

      ۱. اگر همان‌جا هست — دست نمی‌زنیم. (حالت عادی)
      ۲. اگر نیست ولی دیتابیس قدیمی داخل پوشهٔ پروژه هست — منتقلش می‌کنیم.
         این همان چیزی است که موقع به‌روزرسانی کد گم می‌شد.
      ۳. اگر هیچ‌کدام نبود — نسخهٔ اولیهٔ همراه پروژه کپی می‌شود.

    هیچ مسیری داده را بازنویسی نمی‌کند؛ فقط خلأ را پر می‌کند.
    """
    DATA_HOME.mkdir(parents=True, exist_ok=True)
    if DB_PATH.exists():
        return
    if LEGACY_DB.exists():
        shutil.copyfile(LEGACY_DB, DB_PATH)
        print(f"دیتابیس از محل قدیمی منتقل شد → {DB_PATH}")
        return
    if SEED_DB.exists():
        shutil.copyfile(SEED_DB, DB_PATH)
        print(f"دیتابیس اولیه نصب شد → {DB_PATH}")


def connect():
    _ensure_db()
    con = sqlite3.connect(DB_PATH)
    con.executescript(SCHEMA)
    return con


def save_raw(con, msg_uid, src_channel, src_msg_id, orig_date, text):
    con.execute(
        "INSERT OR IGNORE INTO raw_messages VALUES (?,?,?,?,?,?)",
        (msg_uid, src_channel, src_msg_id, orig_date, text,
         datetime.datetime.now().isoformat(timespec="seconds")))
    con.commit()


def _reject(con, date_j, series, value, source, reason):
    con.execute("INSERT INTO rejected (date_j,series,value,source,reason,logged_at)"
                " VALUES (?,?,?,?,?,?)",
                (date_j, series, value, source, reason,
                 datetime.datetime.now().isoformat(timespec="seconds")))


def _neighbour(con, series, date_j, before=True):
    op, order = ("<", "DESC") if before else (">", "ASC")
    r = con.execute(f"SELECT date_j, value FROM observations "
                    f"WHERE series=? AND date_j {op} ? ORDER BY date_j {order} LIMIT 1",
                    (series, date_j)).fetchone()
    return r


def validate(con, date_j, series, value):
    """None یعنی قبول؛ رشته یعنی دلیل رد."""
    limit = MAX_DAILY_MOVE.get(series)
    if limit:
        for before in (True, False):
            n = _neighbour(con, series, date_j, before)
            if n and n[1]:
                # فقط وقتی معنی دارد که همسایه واقعاً روز چسبیده باشد
                gap = abs(int(date_j) - int(n[0]))
                if gap <= 3 and abs(value - n[1]) / abs(n[1]) > limit:
                    return f"جهش روزانهٔ غیرعادی نسبت به {n[0]} ({n[1]:g})"
    if series == "index_ew":
        r = con.execute("SELECT value FROM observations WHERE series='index_total' AND date_j=?",
                        (date_j,)).fetchone()
        if r and r[0] and not (EW_RATIO_RANGE[0] <= value / r[0] <= EW_RATIO_RANGE[1]):
            return "نسبت هم‌وزن به شاخص کل خارج از بازهٔ معقول"
    return None


def upsert(con, date_j, series, value, source, src_ref="", dry=False):
    """
    خروجی: 'inserted' | 'updated' | 'kept' | 'rejected: …'

    dry=True یعنی فقط بگو چه اتفاقی *می‌افتاد* — چیزی ننویس. برای
    «اول نشانم بده بعد بنویس» لازم است؛ همان مسیر تصمیم‌گیری طی می‌شود
    تا پیش‌نمایش با عمل واقعی یکی باشد، نه یک کپیِ جداگانه که با هم
    در می‌روند.
    """
    reason = validate(con, date_j, series, value)
    if reason:
        if not dry:
            _reject(con, date_j, series, value, source, reason)
            con.commit()
        return "rejected: " + reason

    cur = con.execute("SELECT value, source FROM observations WHERE date_j=? AND series=?",
                      (date_j, series)).fetchone()
    now = datetime.datetime.now().isoformat(timespec="seconds")
    if cur is None:
        if not dry:
            con.execute("INSERT INTO observations VALUES (?,?,?,?,?,?)",
                        (date_j, series, value, source, src_ref, now))
            con.commit()
        return "inserted"

    old_v, old_src = cur
    if SOURCE_PRIORITY.get(source, 1) < SOURCE_PRIORITY.get(old_src, 1):
        return "kept"                     # منبع ضعیف‌تر، دست نمی‌زنیم
    if abs(old_v - value) < 1e-9 and old_src == source:
        return "kept"
    if not dry:
        con.execute("UPDATE observations SET value=?, source=?, src_ref=?, ingested_at=? "
                    "WHERE date_j=? AND series=?",
                    (value, source, src_ref, now, date_j, series))
        con.commit()
    return "updated"


def upsert_ind(con, date_j, ind, metric, value, source, src_ref="",
               dry=False, only_new=False):
    """
    همتای upsert برای صنایع. خروجی: 'inserted' | 'updated' | 'kept'

    نردبان اولویت منبع همان SOURCE_PRIORITY است، پس منبع ضعیف‌تر رقم
    قوی‌تر را بازنویسی نمی‌کند. اعتبارسنجی MAX_DAILY_MOVE اینجا اعمال
    نمی‌شود: ارزش معاملات یک صنعت روزبه‌روز سه‌برابر هم می‌شود و آن گارد
    که برای شاخص کل نوشته شده بود، ردیف‌های سالم را رد می‌کرد.

    only_new=True یعنی «فقط جای خالی» — همان قاعدهٔ بقیهٔ واردکردن‌ها.
    """
    cur = con.execute("SELECT value, source FROM industry_obs "
                      "WHERE date_j=? AND ind=? AND metric=?",
                      (date_j, ind, metric)).fetchone()
    now = datetime.datetime.now().isoformat(timespec="seconds")
    if cur is None:
        if not dry:
            con.execute("INSERT INTO industry_obs VALUES (?,?,?,?,?,?,?)",
                        (date_j, ind, metric, value, source, src_ref, now))
        return "inserted"
    if only_new:
        return "kept"
    old_v, old_src = cur
    if SOURCE_PRIORITY.get(source, 1) < SOURCE_PRIORITY.get(old_src, 1):
        return "kept"
    if abs(old_v - value) < 1e-9 and old_src == source:
        return "kept"
    if not dry:
        con.execute("UPDATE industry_obs SET value=?, source=?, src_ref=?, "
                    "ingested_at=? WHERE date_j=? AND ind=? AND metric=?",
                    (value, source, src_ref, now, date_j, ind, metric))
    return "updated"


def industry_coverage(con):
    """[(ind, تعداد روز، اولین، آخرین)] — برای گزارش."""
    return con.execute(
        "SELECT ind, COUNT(DISTINCT date_j), MIN(date_j), MAX(date_j) "
        "FROM industry_obs GROUP BY ind ORDER BY ind").fetchall()


def load_series(con, series):
    """[(date_j, value), …] مرتب‌شده."""
    return con.execute("SELECT date_j, value FROM observations WHERE series=? ORDER BY date_j",
                       (series,)).fetchall()


def coverage(con):
    rows = con.execute(
        "SELECT series, COUNT(*), MIN(date_j), MAX(date_j) FROM observations "
        "GROUP BY series ORDER BY series").fetchall()
    return rows


def derive_totals(con, dates):
    """
    سری‌های مشتق را برای این تاریخ‌ها دوباره می‌سازد:

        ارزش کل بازار = ارزش بورس + ارزش فرابورس
        نسبت          = ارزش کل بازار ÷ نقدینگی M2

    فقط وقتی می‌نویسد که هر دو جزء برای همان روز موجود باشند. پس اگر امروز فقط
    «ارزش بورس» را فرستادید، جمع دست‌نخورده می‌ماند تا فرابورس هم برسد.
    خروجی: فهرست متن‌های کوتاه برای گزارش.
    """
    out = []
    for date_j in sorted(set(dates)):
        row = dict(con.execute(
            "SELECT series, value FROM observations WHERE date_j=? "
            "AND series IN ('mv_tse','mv_ifb','m2','mv','gold18','usd_rate','mv_usd')",
            (date_j,)).fetchall())
        tse, ifb = row.get("mv_tse"), row.get("mv_ifb")
        total = tse + ifb if (tse is not None and ifb is not None) else row.get("mv")

        # ارزش بازار بر حسب طلا، به تن:
        #   ارزش بازار (همت) × ۱۰^۱۲ تومان ÷ (تومان بر گرم) ÷ ۱۰^۶ گرم در تن
        gold = row.get("gold18")
        if total is not None and gold:
            upsert(con, date_j, "mv_gold", total * 1e6 / gold,
                   "chartix", "ارزش بازار ÷ طلای ۱۸ عیار")

        # ارزش دلاری بازار از نرخ دلار: همت × ۱۰^۱۲ تومان ÷ نرخ ÷ ۱۰^۹
        rate = row.get("usd_rate")
        if total is not None and rate:
            upsert(con, date_j, "mv_usd", total * 1e3 / rate,
                   "manual", "ارزش بازار ÷ نرخ دلار")
        # و برعکس: اگر ارزش دلاری هست ولی نرخ دلار نه، نرخ ضمنی را بساز
        elif total is not None and row.get("mv_usd"):
            upsert(con, date_j, "usd_rate", total * 1e3 / row["mv_usd"],
                   "chartix", "ارزش بازار ÷ ارزش دلاری")

        # نسبت به نقدینگی از «ارزش کل بازار» می‌آید، از هر جا که آمده
        # باشد — جمع بورس و فرابورس، یا ورودی دستی، یا بازیابی از صفحه.
        # پیش از این فقط وقتی حساب می‌شد که هر دو جزء موجود باشند، و
        # روزهایی که ارزش بازار از جای دیگری آمده بود بی‌صدا بی‌نسبت
        # می‌ماندند.
        m2 = row.get("m2")
        if total is not None and m2:
            upsert(con, date_j, "ratio", total / m2, "chartix", "ارزش بازار ÷ M2")

        if tse is None or ifb is None:
            continue
        res = upsert(con, date_j, "mv", total, "chartix", "بورس + فرابورس")
        if res.split(":")[0] in ("inserted", "updated"):
            out.append(f"Σ {date_j} · ارزش کل بازار = {total:,.0f}")
    return out


INTERP_SOURCE = "m2_interp"


def interpolate_m2(con):
    """
    نقدینگی ماهانه منتشر می‌شود، ولی نمودار روزانه است. این تابع روزهای *بین*
    دو رقم واقعی را خطی پر می‌کند.

    عمداً از آخرین رقم واقعی به بعد چیزی نمی‌سازد: آن دیگر درون‌یابی نیست،
    برون‌یابی است — یعنی حدس. نمودار تا رسیدن رقم بعدی همان‌جا تمام می‌شود.

    مقادیر ساخته‌شده با منبع «m2_interp» ذخیره می‌شوند که اولویتش از همه
    پایین‌تر است، پس هر رقم واقعی که بعداً برسد جایشان را می‌گیرد.
    خروجی: تعداد روزهایی که پر شد.
    """
    real = [(d, v) for d, v in con.execute(
        "SELECT date_j, value FROM observations WHERE series='m2' AND source<>? "
        "ORDER BY date_j", (INTERP_SOURCE,))]
    if len(real) < 2:
        return 0

    # روزهایی که روی محور نمودار هستند (هر روزی که دست‌کم یک سری بورسی دارد)
    axis = [r[0] for r in con.execute(
        "SELECT DISTINCT date_j FROM observations WHERE series<>'gold18' ORDER BY date_j")]

    filled = 0
    for (d0, v0), (d1, v1) in zip(real, real[1:]):
        span = [d for d in axis if d0 < d < d1]
        if not span or v0 is None or v1 is None:
            continue
        # موقعیت هر روز بین دو سر بازه، بر مبنای شمارهٔ ردیف نه فاصلهٔ تقویمی
        n = len(span) + 1
        for k, d in enumerate(span, start=1):
            val = v0 + (v1 - v0) * k / n
            res = upsert(con, d, "m2", val, INTERP_SOURCE, f"بین {d0} و {d1}")
            if res.split(":")[0] in ("inserted", "updated"):
                filled += 1
    return filled


EXTRAP_SOURCE = "m2_extrap"


def extend_m2(con, monthly_pct=None):
    """
    نقدینگی را از آخرین رقم موجود تا آخرین روز محور ادامه می‌دهد.

    نرخ رشد از دو لنگر آخرِ خود داده درمی‌آید، مگر اینکه monthly_pct بدهید.
    این **برون‌یابی** است — حدس، نه اندازه‌گیری. با منبع «m2_extrap» ذخیره
    می‌شود که پایین‌ترین اولویت را دارد، پس هر رقم واقعی جایش را می‌گیرد.
    خروجی: (تعداد روز، درصد رشد ماهانهٔ استفاده‌شده، اولین روز، آخرین روز).
    """
    anchors = [(d, v) for d, v in con.execute(
        "SELECT date_j, value FROM observations WHERE series='m2' AND source<>? "
        "ORDER BY date_j", (EXTRAP_SOURCE,))]
    if not anchors:
        return 0, None, None, None
    d_last, v_last = anchors[-1]

    if monthly_pct is None:
        reals = [(d, v) for d, v in con.execute(
            "SELECT date_j, value FROM observations WHERE series='m2' "
            "AND source NOT IN (?, ?) ORDER BY date_j",
            (EXTRAP_SOURCE, INTERP_SOURCE))]
        if len(reals) < 2 or not reals[-2][1]:
            return 0, None, None, None
        (d0, v0), (d1, v1) = reals[-2], reals[-1]
        months = max(1.0, _months_between(d0, d1))
        monthly_pct = ((v1 / v0) ** (1 / months) - 1) * 100

    axis = [r[0] for r in con.execute(
        "SELECT DISTINCT date_j FROM observations WHERE series NOT IN ('gold18','m2') "
        "ORDER BY date_j")]
    todo = [d for d in axis if d > d_last]
    if not todo:
        return 0, monthly_pct, None, None

    g = (1 + monthly_pct / 100) ** (1 / 30)      # رشد روزانهٔ معادل
    n = 0
    for d in todo:
        days = _days_between(d_last, d)
        res = upsert(con, d, "m2", v_last * (g ** days), EXTRAP_SOURCE,
                     f"ادامه از {d_last} با {monthly_pct:.2f}٪ ماهانه")
        if res.split(":")[0] in ("inserted", "updated"):
            n += 1
    return n, monthly_pct, todo[0], todo[-1]


def _days_between(a, b):
    import jdatetime
    da = jdatetime.date(int(a[:4]), int(a[4:6]), int(a[6:])).togregorian()
    db = jdatetime.date(int(b[:4]), int(b[4:6]), int(b[6:])).togregorian()
    return (db - da).days


def _months_between(a, b):
    return _days_between(a, b) / 30.4375
