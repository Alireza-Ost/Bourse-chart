# -*- coding: utf-8 -*-
"""
انتشار: ساخت صفحه و داده از دیتابیس، کپی در پوشهٔ ریپو، و پوش به گیت‌هاب.

    python3 publish.py            # ساخت + کپی + پوش
    python3 publish.py --dry      # فقط ساخت، بدون گیت

همین تابع را ربات هم صدا می‌زند: بعد از هر فوروارد که دادهٔ تازه‌ای بنویسد،
چند ثانیه صبر می‌کند (تا اگر چند پست پشت سر هم فوروارد شد یک بار منتشر شود)
و بعد خودش سایت را به‌روز می‌کند. پس فقط فوروارد کافی است.

گیت از اطلاعات حساب ویندوز شما استفاده می‌کند — همانی که یک بار با آن پوش زدید.
اگر گیت نصب نباشد یا ریپو پیدا نشود، فایل‌ها ساخته می‌شوند و فقط پوش رد می‌شود،
با پیام روشن. هیچ‌وقت بی‌صدا شکست نمی‌خورد.
"""
import json
import shutil
import subprocess
import sys

from config import CHART_DIR, REPO_DIR, PAGE_URL
from make_chart import WEB_DIR, build_payload
from store import connect


def _git(args, cwd):
    return subprocess.run(["git"] + args, cwd=str(cwd), capture_output=True,
                          text=True, encoding="utf-8", errors="replace", timeout=180)


def build(con):
    """
    web/index.html و web/data.json و web/ind/*.json را از دیتابیس می‌سازد.

    همان کاری که make_chart --web می‌کند؛ قطعاتش از همان‌جا می‌آید تا دو
    مسیرِ ساختِ صفحه از هم در نروند. یک بار در رفتند و گران تمام شد:
    قالب از app.js ساخته نشده بود و چهار سری تازه بی‌صدا از صفحه افتادند.
    """
    from make_chart import fresh_templates, ind_block, gate_into
    fresh_templates(log=lambda *a: None)
    tpl = CHART_DIR / "template_web.html"
    if not tpl.exists():
        raise FileNotFoundError(f"قالب پیدا نشد: {tpl} — charts/build_templates.py را بزنید")
    payload = build_payload(con)
    WEB_DIR.mkdir(exist_ok=True)
    payload["ind"] = ind_block(con, payload["d"], web=True)
    blob = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    (WEB_DIR / "index.html").write_text(
        gate_into(tpl.read_text(encoding="utf-8"), con), encoding="utf-8")
    (WEB_DIR / "data.json").write_text(blob, encoding="utf-8")
    return len(payload["d"]), payload["d"][-1]


def publish(con=None, push=True):
    """خروجی: متن گزارش کوتاه، برای چاپ یا فرستادن در تلگرام."""
    own = con is None
    if own:
        con = connect()
        import migrate
        migrate.run_all(con)
    try:
        n_days, last = build(con)
    finally:
        if own:
            con.close()

    lines = [f"📄 صفحه ساخته شد — {n_days} روز، تا {last}"]

    if not push:
        return "\n".join(lines)

    if not REPO_DIR or not (REPO_DIR / ".git").exists():
        lines.append(f"⚠️ ریپو پیدا نشد: {REPO_DIR}")
        lines.append("   مسیر را با متغیر BOURSE_REPO تنظیم کنید.")
        return "\n".join(lines)

    if shutil.which("git") is None:
        lines.append("⚠️ گیت نصب نیست — فایل‌ها ساخته شدند ولی پوش نشد.")
        return "\n".join(lines)

    # flow.json فایلِ تبِ «جمع ورود پول» است. اگر جا بماند، تب روی سایت
    # باز می‌شود و می‌گوید صنایع و صندوق‌ها نیامدند — دقیقاً همان دامی که
    # یک بار سرِ پوشهٔ صنایع افتادیم.
    from make_chart import FLOW_FILE
    for name in ("index.html", "data.json", FLOW_FILE):
        src = WEB_DIR / name
        if src.exists():
            shutil.copyfile(src, REPO_DIR / name)
    # پوشهٔ صنایع: یک فایل به ازای هر صنعت، کنار صفحه. اگر این را جا
    # بگذاریم، تب صنایع روی سایت باز می‌شود و «دادهٔ این صنعت نیامد»
    # می‌دهد — چون فایلش هیچ‌وقت آپلود نشده.
    src_ind = WEB_DIR / "ind"
    if src_ind.is_dir():
        dst_ind = REPO_DIR / "ind"
        dst_ind.mkdir(exist_ok=True)
        for f in src_ind.glob("*.json"):
            shutil.copyfile(f, dst_ind / f.name)

    _git(["add", "-A"], REPO_DIR)
    c = _git(["commit", "-m", f"update {last}"], REPO_DIR)
    if "nothing to commit" in (c.stdout + c.stderr):
        lines.append("⏭ چیزی برای کامیت نبود — سایت همین حالا هم به‌روز است.")
        return "\n".join(lines)

    p = _git(["push"], REPO_DIR)
    if p.returncode != 0:
        err = (p.stderr or p.stdout).strip().splitlines()
        lines.append("⛔️ پوش نشد:")
        lines += ["   " + e for e in err[-4:]]
        lines.append("   یک بار دستی `git push` بزنید تا ببینیم چه می‌خواهد.")
        return "\n".join(lines)

    lines.append("🚀 منتشر شد.")
    lines.append(f"   {PAGE_URL}")
    lines.append("   با Ctrl+Shift+R باز کنید (F5 نسخهٔ کش‌شده را نشان می‌دهد).")
    return "\n".join(lines)


if __name__ == "__main__":
    print(publish(push="--dry" not in sys.argv))
