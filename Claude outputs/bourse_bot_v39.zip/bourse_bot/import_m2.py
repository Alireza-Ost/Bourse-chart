# -*- coding: utf-8 -*-
"""
وارد کردن تاریخچهٔ نقدینگی M2 از فایل (اکسل یا CSV).

    python3 import_m2.py Book1.xlsx
    python3 import_m2.py Book1.xlsx --dry
    python3 import_m2.py Book1.xlsx --overwrite

فایل دو ستون می‌خواهد: مقدار (همت) و تاریخ شمسی. ترتیب ستون‌ها مهم نیست
— ستونی که تاریخ از آن درمی‌آید تاریخ است و آن یکی مقدار.

── چرا این مسیر جداست
   نقدینگی در این پروژه *مدل* است نه اندازه‌گیری: شما نرخ رشد ماهانه را
   می‌دهید و `m2.py` روزها را می‌سازد (`m2_rate`, `m2_interp`, …).
   فایلِ تاریخچه اما رقم واقعی است و نباید با آن مدل قاطی شود. پس با
   منبع `m2_file` ذخیره می‌شود که اولویتش (۵) از همهٔ سری‌های ساختگی
   بالاتر است و از رقم تأییدشدهٔ بانک مرکزی (`m2_level`، ۶) پایین‌تر.
   `m2.rebuild()` هم فقط سری‌های ساختگیِ خودش را پاک می‌کند، پس این
   ردیف‌ها دست‌نخورده می‌مانند.

── ردیف‌های خراب
   دو جور خرابی در این فایل‌ها دیده‌ام و هر دو گزارش می‌شوند:

   **مقدار ناخوانا** — مثل `#REF!` که فرمول شکستهٔ اکسل است. ردیف رد
   می‌شود؛ صفر حساب نمی‌شود.

   **تاریخ بیرون از ترتیب** — فایل روزانه و مرتب است، پس تاریخی که از
   تاریخ ردیف قبل عقب‌تر باشد یا بیش از چهل روز جلوتر، غلط تایپ شده.
   آن‌جا تاریخ از روی ردیف قبل بازسازی می‌شود (یک روز جلوتر)، چون
   *ترتیب* فایل درست است و فقط رشتهٔ تاریخ غلط است.

   در فایلی که داشتم سی ردیف «۱۳۹۸/۰۹» وسط دادهٔ آبان ۱۳۹۶ نشسته بود و
   مقدارهایش دقیقاً دنبالهٔ ۱۳۹۶/۰۸/۳۰ بود؛ یعنی ۱۳۹۶ با ۱۳۹۸ تایپ شده
   بود. بی این قاعده، سی روزِ آذر ۱۳۹۶ گم می‌شد و سی روزِ آذر ۱۳۹۸ عددِ
   غلطِ نصفِ واقعی می‌گرفت.
"""
import argparse
import sys

import jdatetime

from import_tradersarena import date_j, number, read_table
from store import connect, upsert

SOURCE = "m2_file"
MAX_STEP = 40          # فاصلهٔ باورپذیر بین دو ردیف پیاپی، به روز


def _d(date_j_str):
    return jdatetime.date(int(date_j_str[:4]), int(date_j_str[4:6]),
                          int(date_j_str[6:]))


def _s(d):
    return d.strftime("%Y%m%d")


def _gap(a, b):
    return (_d(b).togregorian() - _d(a).togregorian()).days


def extract(path, log=print):
    """{date_j: value} — با تاریخ‌های بیرون‌از‌ترتیب بازسازی‌شده."""
    table = read_table(path)
    if not table:
        log("  فایل خالی بود.")
        return {}

    heads = list(table[0])
    # ستون تاریخ: آن که در بیشتر ردیف‌ها تاریخ شمسی می‌دهد
    def score(h):
        return sum(1 for r in table[:200] if date_j(r.get(h)))
    dcol = max(heads, key=score)
    if score(dcol) == 0:
        log("  ⚠ ستون تاریخ پیدا نشد.")
        return {}
    vcols = [h for h in heads if h != dcol]
    if not vcols:
        log("  ⚠ ستون مقدار پیدا نشد.")
        return {}
    vcol = vcols[0]
    log(f"  تاریخ از «{dcol}» · مقدار از «{vcol}»")

    out, prev = {}, None
    unreadable, redated, dropped = 0, 0, 0
    for row in table:
        raw = date_j(row.get(dcol))
        if raw is None:
            dropped += 1
            continue
        d = raw
        if prev and (d <= prev or _gap(prev, d) > MAX_STEP):
            d = _s(_d(prev) + jdatetime.timedelta(days=1))
            redated += 1
        prev = d
        v = number(row.get(vcol))
        if v is None:                 # #REF! و مانندش
            unreadable += 1
            continue
        out[d] = v

    if dropped:
        log(f"  {dropped} ردیف بدون تاریخ رد شد.")
    if unreadable:
        log(f"  {unreadable} ردیف مقدار ناخوانا داشت (مثل #REF!) و رد شد.")
    if redated:
        log(f"  ⚠ {redated} ردیف تاریخش بیرون از ترتیب بود و از روی ردیف "
            f"قبلی بازسازی شد.")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--overwrite", action="store_true",
                    help="روزهایی که از قبل نقدینگی دارند را هم بازنویسی کن")
    a = ap.parse_args()

    print(f"خواندن {a.file}")
    data = extract(a.file)
    if not data:
        sys.exit("چیزی خوانده نشد.")
    days = sorted(data)
    print(f"  {len(days)} روز — {days[0]} تا {days[-1]}")

    con = connect()
    have = {r[0] for r in con.execute(
        "SELECT date_j FROM observations WHERE series='m2'")}
    stats = {}
    touched = set()
    for d in days:
        if d in have and not a.overwrite:
            stats["skipped"] = stats.get("skipped", 0) + 1
            continue
        res = upsert(con, d, "m2", data[d], SOURCE, a.file, dry=a.dry)
        k = res.split(":")[0]
        stats[k] = stats.get(k, 0) + 1
        if k in ("inserted", "updated"):
            touched.add(d)

    print("\nنتیجه: " + "، ".join(f"{k} {v}" for k, v in sorted(stats.items())))

    if touched and not a.dry:
        # نسبت «ارزش بازار ÷ نقدینگی» برای این روزها تازه ساخته می‌شود.
        from store import derive_totals
        derive_totals(con, touched)
        n = con.execute("SELECT COUNT(*) FROM observations WHERE series='ratio'"
                        ).fetchone()[0]
        print(f"نسبت نقدینگی بازسازی شد — حالا {n} روز.")
    if a.dry:
        print("(آزمایشی بود — چیزی نوشته نشد.)")
    else:
        print("حالا /publish بزنید.")
    con.close()


if __name__ == "__main__":
    main()
