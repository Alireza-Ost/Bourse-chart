#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ربات تلگرام — دریافت پست‌های فورواردشده، پارس، ذخیره، نمودار و هشدار تقاطع.

اجرا:
    export TELEGRAM_BOT_TOKEN="…"
    export TELEGRAM_OWNER_ID="…"
    python3 bot.py

دستورها (در چت خصوصی با ربات):
    /chart    نمودارها
    /cross    وضعیت میانگین‌ها و برخوردهای اخیر
    /status   پوشش داده و رکوردهای ردشده
    /export   خروجی اکسل
    /reparse  پارس دوبارهٔ همهٔ پیام‌های ذخیره‌شده (بعد از اصلاح پارسر)
"""
import io
import sys
import time
import datetime
import requests

from config import (BOT_TOKEN, OWNER_ID, DAILY_REPORT_AT, SERIES, EXPORT_XLSX,
                    AUTO_PUBLISH, PUBLISH_DELAY_SEC, M2_EXTEND_DAILY,
                    AUTO_FETCH, AUTO_FETCH_AT, STALE_ALERT_DAYS)

# ---- مالک ربات -------------------------------------------------------
# اگر TELEGRAM_OWNER_ID تنظیم شده باشد همان معتبر است. اگر نه، ربات اولین
# کسی را که در چت خصوصی به او پیام بدهد مالک ثبت می‌کند و شناسه‌اش را در
# دیتابیس نگه می‌دارد. این‌طور لازم نیست شناسهٔ عددی‌تان را از جای دیگری
# پیدا کنید — کافی است بعد از روشن‌کردن ربات یک /start برایش بفرستید.
_owner_cache = None
_publish_due = None          # زمانی که باید منتشر شود (None یعنی چیزی در صف نیست)

MANUAL_HELP = (
    "⚠️ چیزی از این متن نفهمیدم.\n\n"
    "برای ورود دستی، تاریخ و نام و عدد را بنویسید — هر خط یک مورد:\n\n"
    "<code>14050631 ارزش معاملات 21000</code>\n"
    "<code>14050631 ورود پول حقیقی -3500</code>\n\n"
    "یا تاریخ را یک بار بالا بنویسید:\n\n"
    "<code>1405/06/31\n"
    "ارزش معاملات 21000\n"
    "شاخص کل 7650000\n"
    "ارزش بازار 12500 همت</code>\n\n"
    "نام‌هایی که می‌شناسم: ارزش معاملات · ورود پول حقیقی · شاخص کل · "
    "شاخص هم وزن · ارزش بازار · نقدینگی · نسبت · P/E · سرانه خرید · سرانه فروش\n\n"
    "تاریخ لازم است — بدون آن نمی‌دانم عدد مال کدام روز است."
)


def owner(con=None):
    global _owner_cache
    if OWNER_ID:
        return str(OWNER_ID)
    if _owner_cache is None and con is not None:
        _owner_cache = get_setting(con, "owner_id")
    return _owner_cache


def claim_owner(con, chat_id):
    global _owner_cache
    set_setting(con, "owner_id", chat_id)
    _owner_cache = str(chat_id)
    return _owner_cache
from store import (connect, save_raw, upsert, coverage, get_setting,
                   set_setting, derive_totals, interpolate_m2, extend_m2)
import parsers
import analyze
import charts
import migrate
import publish as publisher

API = f"https://api.telegram.org/bot{BOT_TOKEN}"
TEHRAN = datetime.timezone(datetime.timedelta(hours=3, minutes=30))


def fmt(v):
    """۷۵۵۷۶۴۲ → 7,557,642 و ۲.۵ → 2.5 (بدون نماد علمی)."""
    return f"{v:,.0f}" if abs(v) >= 1000 or float(v).is_integer() else f"{v:,.2f}"


# ---------- لایهٔ تلگرام -------------------------------------------------
def api(method, **params):
    r = requests.post(f"{API}/{method}", data=params, timeout=70)
    r.raise_for_status()
    return r.json()


def send(text, chat_id=None):
    for chunk in [text[i:i + 3800] for i in range(0, len(text), 3800)] or [""]:
        api("sendMessage", chat_id=chat_id or owner(), text=chunk,
            parse_mode="HTML", disable_web_page_preview=True)


def send_photo(path, caption="", chat_id=None):
    with open(path, "rb") as f:
        requests.post(f"{API}/sendPhoto",
                      data={"chat_id": chat_id or owner(), "caption": caption},
                      files={"photo": f}, timeout=90).raise_for_status()


# ---------- دریافت پیام --------------------------------------------------
def origin_of(msg):
    """(کانال مبدأ، تاریخ اصلی، شناسهٔ پیام مبدأ) از متادیتای فوروارد."""
    fo = msg.get("forward_origin") or {}
    chat = fo.get("chat") or {}
    ch = chat.get("username") or fo.get("sender_user_name") or ""
    ts = fo.get("date") or msg.get("forward_date") or msg.get("date")
    # سازگاری با نسخه‌های قدیمی‌تر Bot API
    if not ch and msg.get("forward_from_chat"):
        ch = msg["forward_from_chat"].get("username", "")
    src_id = fo.get("message_id") or msg.get("forward_from_message_id")
    d = datetime.datetime.fromtimestamp(ts, TEHRAN).date() if ts else datetime.date.today()
    return ch, d, src_id


def ingest(con, msg):
    """یک پیام کانال را ذخیره و پارس می‌کند. خروجی: متن گزارش کوتاه."""
    text = msg.get("text") or msg.get("caption") or ""
    if not text.strip():
        return None
    channel, orig_date, src_id = origin_of(msg)
    uid = f"{msg['chat']['id']}:{msg['message_id']}"
    save_raw(con, uid, channel, src_id, orig_date.isoformat(), text)

    rows, used = parsers.parse(channel, text, orig_date, with_name=True)
    if not rows:
        if channel:
            return f"⚠️ از این پیام چیزی استخراج نشد (کانال: {channel})"
        return MANUAL_HELP
    source = channel or ("manual" if used == "manual" else "unknown")

    out, warn, changed = [], "", False
    for date_j, key, value, wd_ok in rows:
        if wd_ok is False:
            warn = "  ⚠️ نام روز هفته با تاریخ نمی‌خواند — با احتیاط"
        res = upsert(con, date_j, key, value,
                     source, f"t.me/{channel}/{src_id}" if src_id else "دستی")
        name = SERIES.get(key, (key,))[0]
        if res.split(":")[0] in ("inserted", "updated"):
            changed = True
        mark = {"inserted": "✅", "updated": "♻️", "kept": "⏭"}.get(res.split(":")[0], "⛔️")
        out.append(f"{mark} {date_j} · {name} = {fmt(value)}"
                   + ("" if not res.startswith("rejected") else f" — {res[10:]}"))
    # نقدینگی تازه: روزهای بین این رقم و رقم قبلی را پر کن و نسبت را بساز
    if any(k == "m2" for _, k, *_ in rows):
        n = interpolate_m2(con)
        days = [d for d, _ in con.execute(
            "SELECT DISTINCT date_j, 1 FROM observations WHERE series='m2'")]
        derive_totals(con, days)
        if n:
            out.append(f"↔ {n} روز نقدینگی بین دو رقم واقعی پر شد")
            changed = True
        if M2_EXTEND_DAILY:
            k, rate, a, b = extend_m2(con)
            if k:
                derive_totals(con, [a, b])
                out.append(f"→ {k} روز تا {b} ادامه یافت ({rate:.2f}٪ ماهانه — برآورد)")
                changed = True

    # اگر ارزش بورس یا فرابورس تازه رسید، جمعشان را هم به‌روز کن
    extra = derive_totals(con, [d for d, k, *_ in rows if k in ("mv_tse", "mv_ifb")])
    if extra:
        out += extra
        changed = True

    if changed:
        global _publish_due
        _publish_due = time.time() + PUBLISH_DELAY_SEC
    return "\n".join(out) + warn


def reparse_all(con):
    """پارس دوبارهٔ همهٔ پیام‌های خام. بعد از اصلاح پارسر این را بزنید."""
    rows = con.execute("SELECT src_channel, orig_date, text FROM raw_messages").fetchall()
    n = 0
    for channel, od, text in rows:
        d = datetime.date.fromisoformat(od) if od else datetime.date.today()
        for date_j, key, value, _wd in parsers.parse(channel, text, d):
            upsert(con, date_j, key, value, channel or "unknown", "reparse")
            n += 1
    return len(rows), n


# ---------- خروجی‌ها -----------------------------------------------------
def export_xlsx(con):
    import pandas as pd
    frames = {}
    for key in SERIES:
        rows = con.execute("SELECT date_j, value FROM observations WHERE series=? ORDER BY date_j",
                           (key,)).fetchall()
        if rows:
            frames[SERIES[key][0]] = pd.Series({d: v for d, v in rows})
    if not frames:
        return None
    df = pd.DataFrame(frames)
    df.index.name = "تاریخ شمسی"
    EXPORT_XLSX.parent.mkdir(parents=True, exist_ok=True)
    df.to_excel(EXPORT_XLSX)
    return EXPORT_XLSX


def status_text(con):
    from config import DB_PATH
    lines = ["<b>پوشش داده</b>"]
    for s, n, a, b in coverage(con):
        lines.append(f"  {SERIES.get(s, (s,))[0]}: {n} روز · {a} → {b}")
    nraw = con.execute("SELECT COUNT(*) FROM raw_messages").fetchone()[0]
    lines.append(f"\nپیام‌های خام ذخیره‌شده: {nraw}")
    lines.append(f"دیتابیس: <code>{DB_PATH}</code>")
    rej = con.execute("SELECT date_j, series, value, reason FROM rejected "
                      "ORDER BY id DESC LIMIT 8").fetchall()
    if rej:
        lines.append("\n<b>ردشده در اعتبارسنجی</b>")
        for d, s, v, why in rej:
            lines.append(f"  {d} · {SERIES.get(s, (s,))[0]} = {fmt(v)} — {why}")
    return "\n".join(lines)


def send_charts(con, chat_id=None):
    made = charts.build_all(con)
    if not made:
        send("نموداری ساخته نشد — داده کافی نیست.", chat_id)
        return
    for p in made:
        send_photo(p, caption=p.stem, chat_id=chat_id)


# ---------- حلقهٔ اصلی ---------------------------------------------------
FA_AR = {ord(c): str(i) for i, c in enumerate("۰۱۲۳۴۵۶۷۸۹")}
FA_AR.update({ord(c): str(i) for i, c in enumerate("٠١٢٣٤٥٦٧٨٩")})


def month_arg(s):
    """'1405/07' یا '140507' یا '۱۴۰۵-۰۷' → '140507'. نشد → None."""
    t = str(s).translate(FA_AR)
    d = "".join(ch for ch in t if ch.isdigit())
    return d[:6] if len(d) >= 6 else None


def num_arg(s):
    t = (str(s).translate(FA_AR)
         .replace("٫", ".")        # ممیز فارسی
         .replace("٬", "").replace(",", "")
         .replace("٪", "").replace("%", "").strip())
    try:
        return float(t)
    except ValueError:
        return None


def m2_set(con, args, kind):
    """
    /m2rate 1405/07 3.1          یک ماه
    /m2rate 1405/01 1405/06 3.54 یک بازه (هر دو سر، شامل)
    /m2real 1405/02 16200        رقم واقعی بانک مرکزی به همت
    """
    import m2
    months_ = [m for m in (month_arg(a) for a in args[:-1]) if m]
    value = num_arg(args[-1]) if args else None
    if not months_ or value is None:
        return ("فرمت:\n<code>/m2rate 1405/07 3.1</code>\n"
                "<code>/m2rate 1405/01 1405/06 3.54</code>   (بازه)\n"
                "<code>/m2real 1405/02 16200</code>   (رقم بانک مرکزی به همت)")
    if len(months_) >= 2:
        a, b = min(months_[:2]), max(months_[:2])
        span, cur = [], a
        while cur <= b and len(span) < 120:
            span.append(cur)
            cur = m2.next_month(cur)
    else:
        span = months_[:1]

    for mo in span:
        m2.set_month(con, mo, kind, value, "تلگرام")
    n, a, b, err = m2.rebuild(con)
    head = ("رقم واقعی" if kind == "level" else "نرخ رشد") + \
           f" برای {len(span)} ماه ثبت شد.\n\n"
    if err:
        return head + "⚠️ " + err
    global _publish_due
    _publish_due = time.time() + PUBLISH_DELAY_SEC
    return (head + f"نقدینگی {n} روز از نو حساب شد ({a} تا {b}).\n"
            "همهٔ ماه‌های بعدی هم خودکار جابه‌جا شدند.\n\n" + m2.summary(con))


def missing_text(con, want=None):
    """روزهایی که سری‌ها در آن‌ها خالی‌اند — برای پرکردن موردی و دستی."""
    axis = [r[0] for r in con.execute(
        "SELECT DISTINCT date_j FROM observations WHERE series NOT IN ('gold18','m2') "
        "ORDER BY date_j")]
    if not axis:
        return "دیتابیس خالی است."
    keys = [want] if want else [k for k in SERIES
                                if k not in ("mv", "ratio", "mv_gold", "mv_usd")]
    out, recent = [], axis[-120:]
    for k in keys:
        if k not in SERIES:
            continue
        have = {r[0] for r in con.execute(
            "SELECT date_j FROM observations WHERE series=?", (k,))}
        gaps = [d for d in recent if d not in have]
        if not gaps:
            continue
        label = SERIES[k][0] if isinstance(SERIES[k], (list, tuple)) else k
        show = "، ".join(f"{d[:4]}/{d[4:6]}/{d[6:]}" for d in gaps[:12])
        more = f" … و {len(gaps) - 12} روز دیگر" if len(gaps) > 12 else ""
        out.append(f"<b>{label}</b> — {len(gaps)} روز خالی از ۱۲۰ روز اخیر\n  {show}{more}")
    if not out:
        return "در ۱۲۰ روز اخیر هیچ جای خالی‌ای نیست. ✅"
    return ("جاهای خالی (۱۲۰ روز اخیر):\n\n" + "\n\n".join(out) +
            "\n\nبرای پرکردن، تاریخ و نام و عدد را بفرستید:\n"
            "<code>14050705 شاخص کل 7700000</code>")


def handle(con, upd):
    msg = upd.get("channel_post") or upd.get("edited_channel_post")
    if msg:
        rep = ingest(con, msg)
        if rep:
            send(rep)
        return

    msg = upd.get("message")
    if not msg:
        return
    chat_id = str(msg.get("chat", {}).get("id"))
    known = owner(con)
    if known is None:
        # اولین پیام خصوصی، مالک را تعیین می‌کند
        claim_owner(con, chat_id)
        send(f"سلام. شما به‌عنوان مالک این ربات ثبت شدید.\n"
             f"شناسهٔ عددی شما: <code>{chat_id}</code>\n\n"
             f"لازم نیست کار دیگری بکنید؛ همین در دیتابیس ذخیره شد. "
             f"اگر خواستید جای دیگری هم بنویسیدش، همین عدد است.", chat_id)
        known = chat_id
    elif chat_id != known:
        return
    body = msg.get("text") or msg.get("caption") or ""
    cmd = body.split()[0].lower() if body.strip() else ""
    chat = msg["chat"]["id"]

    # هر پیام خصوصی که دستور نیست — چه فوروارد باشد چه متن تایپ‌شده —
    # از همان مسیر پست‌های کانال رد می‌شود. پس فوروارد مستقیم به خود ربات
    # هم کار می‌کند، نه فقط فوروارد به کانال.
    if body.strip() and not cmd.startswith("/"):
        rep = ingest(con, msg)
        send(rep or "⚠️ این پیام متنی ندارد.", chat)
        return

    if cmd in ("/start", "/help"):
        send("<b>برداشت خودکار</b>\n"
             "/fetch برداشت همین حالا  ·  /fetch deep برای عقب‌تر رفتن\n"
             "/auto on|off روشن و خاموش کردن برداشت روزانه\n\n"
             "<b>نقدینگی</b>\n"
             "/m2rate 1405/07 3.1 — نرخ رشد ماهانه\n"
             "/m2rate 1405/01 1405/06 3.54 — یک بازه یک‌جا\n"
             "/m2real 1405/02 16200 — رقم واقعی بانک مرکزی (همت)\n"
             "/m2months فهرست ماه‌ها  ·  /m2clear 1405/07 حذف یک ماه\n\n"
             "<b>بقیه</b>\n"
             "/missing جاهای خالی داده\n/chart نمودارها\n"
             "/cross وضعیت میانگین‌ها\n/status پوشش داده\n"
             "/export خروجی اکسل\n/publish انتشار دستی\n/reparse پارس دوباره\n\n"
             "ورود دستی همچنان کار می‌کند — تاریخ و نام و عدد را بفرستید.", chat)
    elif cmd == "/fetch":
        dry = any(w in body for w in ("dry", "آزمایشی", "test"))
        send("در حال خواندن سایت‌ها…" + (" (آزمایشی)" if dry else ""), chat)
        import collect
        try:
            text, n = collect.run(con, pages=2 if "deep" in body else 1, dry=dry)
            send(text, chat)
            if n and not dry:
                globals()["_publish_due"] = time.time() + PUBLISH_DELAY_SEC
        except Exception as e:                                # noqa: BLE001
            send(f"⛔️ برداشت شکست خورد: {e}", chat)
    elif cmd == "/auto":
        arg = body.split()[1:]
        if arg and arg[0] in ("on", "off", "روشن", "خاموش"):
            set_setting(con, "auto_fetch", "1" if arg[0] in ("on", "روشن") else "0")
        state = get_setting(con, "auto_fetch", "1" if AUTO_FETCH else "0")
        send(f"برداشت خودکار روزانه: <b>{'روشن' if state == '1' else 'خاموش'}</b>\n"
             f"ساعت‌ها (تهران): {'، '.join(AUTO_FETCH_AT)}", chat)
    elif cmd == "/m2rate":
        send(m2_set(con, body.split()[1:], "rate"), chat)
    elif cmd == "/m2real":
        send(m2_set(con, body.split()[1:], "level"), chat)
    elif cmd == "/m2months":
        import m2
        send(m2.summary(con), chat)
    elif cmd == "/m2clear":
        import m2
        mo = month_arg(body.split()[1]) if len(body.split()) > 1 else None
        if not mo:
            send("فرمت: <code>/m2clear 1405/07</code>", chat)
        else:
            k = m2.clear_month(con, mo)
            n, a, b, err = m2.rebuild(con)
            send((f"{k} ماه حذف شد.\n" + (err or f"نقدینگی {n} روز از نو حساب شد.")
                  + "\n\n" + m2.summary(con)), chat)
    elif cmd == "/missing":
        arg = body.split()[1:]
        send(missing_text(con, arg[0] if arg else None), chat)
    elif cmd == "/chart":
        send_charts(con, chat)
    elif cmd == "/cross":
        send(analyze.report(con), chat)
    elif cmd == "/status":
        send(status_text(con), chat)
    elif cmd == "/export":
        p = export_xlsx(con)
        if p:
            with open(p, "rb") as f:
                requests.post(f"{API}/sendDocument", data={"chat_id": chat},
                              files={"document": f}, timeout=120)
        else:
            send("داده‌ای برای خروجی نیست.", chat)
    elif cmd == "/extendm2":
        arg = body.split()[1:] 
        rate = None
        try:
            rate = float(arg[0].replace("٪", "").replace("%", "")) if arg else None
        except ValueError:
            rate = None
        k, used, a, b = extend_m2(con, rate)
        if not k:
            send("چیزی برای ادامه‌دادن نبود — نقدینگی تا آخرین روز محور موجود است.", chat)
        else:
            days = [r[0] for r in con.execute(
                "SELECT DISTINCT date_j FROM observations WHERE series='m2'")]
            derive_totals(con, days)
            send(f"→ نقدینگی {k} روز ادامه یافت: {a} تا {b}\n"
                 f"نرخ استفاده‌شده: {used:.2f}٪ ماهانه\n\n"
                 f"⚠️ این‌ها <b>برآوردند نه رقم رسمی</b>. هر عدد واقعی که بعداً "
                 f"بفرستید جایشان را می‌گیرد.", chat)
            global _publish_due
            _publish_due = time.time() + PUBLISH_DELAY_SEC
    elif cmd == "/publish":
        send("در حال ساخت و انتشار…", chat)
        try:
            send(publisher.publish(con), chat)
        except Exception as e:
            send(f"⛔️ انتشار شکست خورد: {e}", chat)
    elif cmd == "/reparse":
        a, b = reparse_all(con)
        send(f"{a} پیام دوباره پارس شد، {b} مقدار نوشته شد.", chat)


def main():
    global _publish_due
    if not BOT_TOKEN:
        sys.exit("TELEGRAM_BOT_TOKEN را تنظیم کنید.")
    con = connect()
    migrate.run_all(con)
    if owner(con) is None:
        print("مالک هنوز ثبت نشده — در تلگرام به ربات /start بدهید.")
    else:
        print(f"مالک: {owner(con)}")
    offset, last_report = None, None
    last_fetch = {}                 # "HH:MM" -> "YYYY-MM-DD" آخرین اجرای آن نوبت
    print("ربات روشن شد.")
    while True:
        try:
            r = api("getUpdates", offset=offset, timeout=50,
                    allowed_updates='["message","channel_post","edited_channel_post"]')
            for upd in r.get("result", []):
                offset = upd["update_id"] + 1
                try:
                    handle(con, upd)
                except Exception as e:                       # یک پیام خراب، ربات را نخواباند
                    print("handle error:", e)

            if AUTO_PUBLISH and _publish_due and time.time() >= _publish_due:
                _publish_due = None
                try:
                    send(publisher.publish(con))
                except Exception as e:
                    send(f"⛔️ انتشار خودکار شکست خورد: {e}")

            # ---- برداشت خودکار از سایت‌ها ------------------------------
            # هر نوبت روزی یک بار. «>=» یعنی اگر کامپیوتر آن لحظه خاموش
            # بوده، همین که روشن شود نوبتِ ازدست‌رفته را جبران می‌کند.
            if get_setting(con, "auto_fetch", "1" if AUTO_FETCH else "0") == "1":
                now = datetime.datetime.now(TEHRAN)
                stamp, clock = now.strftime("%Y-%m-%d"), now.strftime("%H:%M")
                for at in AUTO_FETCH_AT:
                    if clock >= at and last_fetch.get(at) != stamp:
                        last_fetch[at] = stamp
                        import collect
                        try:
                            text, n = collect.run(con)
                            if n:
                                set_setting(con, "last_fetch_ok", stamp)
                                send(f"🔄 <b>برداشت خودکار</b> ({at})\n\n{text}")
                                _publish_due = time.time() + PUBLISH_DELAY_SEC
                        except Exception as e:               # noqa: BLE001
                            print("fetch error:", e)
                        break

                # ساکت خراب‌شدن بدترین حالت است: اگر چند روز هیچ دادهٔ
                # تازه‌ای نیامد، خبر بده.
                ok = get_setting(con, "last_fetch_ok")
                if ok:
                    gap = (now.date() - datetime.date.fromisoformat(ok)).days
                    if gap >= STALE_ALERT_DAYS and get_setting(con, "stale_told") != stamp:
                        set_setting(con, "stale_told", stamp)
                        send(f"⚠️ <b>{gap} روز</b> است هیچ دادهٔ تازه‌ای از سایت‌ها "
                             f"نیامده.\nیا بازار تعطیل بوده، یا یکی از سایت‌ها "
                             f"ساختارش عوض شده. با /fetch دستی امتحان کنید.")

            if DAILY_REPORT_AT:
                now = datetime.datetime.now(TEHRAN)
                stamp = now.strftime("%Y-%m-%d")
                if now.strftime("%H:%M") >= DAILY_REPORT_AT and last_report != stamp:
                    last_report = stamp
                    send("📊 <b>گزارش روزانه</b>\n\n" + analyze.report(con))
                    send_charts(con)
        except KeyboardInterrupt:
            break
        except Exception as e:
            print("loop error:", e)
            time.sleep(5)


if __name__ == "__main__":
    main()
