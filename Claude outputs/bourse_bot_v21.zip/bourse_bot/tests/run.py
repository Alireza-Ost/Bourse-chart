#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تست منابع خودکار، بدون اینترنت.

    python3 tests/run.py

صفحه‌های واقعیِ ۱۴۰۵/۰۷/۱۲ در پوشهٔ fixtures ذخیره شده‌اند. اگر روزی
یکی از سایت‌ها ساختارش را عوض کرد و برداشت خراب شد، اول این را بزنید:
اگر اینجا سبز است یعنی پارسر سالم است و مشکل جای دیگری است (شبکه،
فیلترینگ، تغییر آدرس). اگر اینجا هم قرمز شد یعنی واقعاً صفحه عوض شده.
"""
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))

FIX = HERE / "fixtures"

ok = fail = 0


def check(label, got, want, tol=0.0):
    global ok, fail
    good = (abs(got - want) <= tol) if isinstance(want, float) else (got == want)
    show = f"{got:,}" if isinstance(got, (int, float)) and not isinstance(got, bool) else repr(got)
    extra = "" if good else f"   (انتظار {want!r})"
    print(("  ✅ " if good else "  ❌ ") + f"{label}: {show}" + extra)
    ok, fail = ok + good, fail + (not good)


def main():
    import sources.common as common
    from sources import tradersarena, chartix_live, parsis_web

    print("تریدرزآرنا — جدول سوابق")
    rows, notes = tradersarena.parse((FIX / "ta_history.html").read_text(encoding="utf-8"))
    d = {(a, b): c for a, b, c, _ in rows}
    check("ارزش معاملات خرد ۱۴۰۵/۰۷/۱۲", d[("14050712", "value_retail")], 51319.8, 0.05)
    check("ورود پول ۱۴۰۵/۰۷/۱۲", d[("14050712", "flow_retail")], -846.4, 0.05)
    check("شاخص کل ۱۴۰۵/۰۷/۱۱", d[("14050711", "index_total")], 7808068.0, 0.5)
    check("شاخص هم‌وزن ۱۴۰۵/۰۷/۱۱", d[("14050711", "index_ew")], 2068720.0, 0.5)
    check("ردیف امروز بدون شاخص رد نشده", ("14050712", "index_total") not in d, True)
    if notes:
        print("  ⚠", "؛ ".join(notes))

    print("\nچارتیکس — قیمت از خود صفحه")
    H = chartix_live.RIAL_PER_HEMAT
    v, u = chartix_live.price_of((FIX / "chartix_page.html").read_text(encoding="utf-8"))
    check("ارزش بورس (همت)", round(v / H, 1), 22536.2, 0.05)
    v, u = chartix_live.price_of((FIX / "chartix_ifb.html").read_text(encoding="utf-8"))
    check("ارزش فرابورس (همت)", round(v / H, 1), 3314.4, 0.05)
    g, _ = chartix_live.price_of((FIX / "chartix_gold.html").read_text(encoding="utf-8"))
    check("طلای ۱۸ (تومان بر گرم)", g, 26395500.0, 0.5)
    a, _ = chartix_live.price_of((FIX / "chartix_all_irr.html").read_text(encoding="utf-8"))
    b, _ = chartix_live.price_of((FIX / "chartix_all_usd.html").read_text(encoding="utf-8"))
    check("نرخ دلار (تومان)", round(a / b / 10), 267500)

    print("\nپارسیس — نسخهٔ وب کانال")
    rows, notes = parsis_web.parse((FIX / "parsis_web.html").read_text(encoding="utf-8"))
    d = {(x, y): z for x, y, z, _ in rows}
    check("ارزش معاملات خرد", d[("14050712", "value_retail")], 51314.0, 0.5)
    check("خروج پول حقیقی", d[("14050712", "flow_retail")], -1131.0, 0.5)
    check("سرانه خرید", d[("14050712", "sarane_buy")], 83.4, 0.05)
    check("سهم حقیقی از خرید", d[("14050712", "buy_share")], 74.0, 0.05)

    print("\nنقدینگی — مدل ماهانه و اصلاح بازگشتی")
    import m2
    import sqlite3
    con = sqlite3.connect(":memory:")
    from store import SCHEMA
    con.executescript(SCHEMA)
    m2.ensure(con)
    con.execute("INSERT INTO observations VALUES ('14041206','m2',14834.48,'xlsx_seed','','')")
    # روز میانی و روز پایانی هر ماه، تا هم پخش روزانه و هم سطح ماه تست شود
    for day in ("14050115", "14050131", "14050215", "14050231", "14050315",
                "14050331", "14050431", "14050531", "14050615", "14050631"):
        con.execute("INSERT INTO observations VALUES (?,'index_total',1,'test','','')", (day,))
    con.commit()

    def val(d):
        return con.execute("SELECT value FROM observations WHERE series='m2' AND date_j=?",
                           (d,)).fetchone()[0]

    for mo in ("140501", "140502", "140503", "140504", "140505", "140506"):
        m2.set_month(con, mo, "rate", 3.54)
    m2.rebuild(con)

    # پایان شهریور باید دقیقاً ۱۴۸۳۴.۴۸ × ۱.۰۳۵۴^۶ باشد
    check("پایان شهریور با نرخ ۳.۵۴٪ (همت)", round(val("14050631"), 1),
          round(14834.48 * 1.0354 ** 6, 1), 1.0)
    check("پانزدهم شهریور وسط مرداد و شهریور است",
          val("14050531") < val("14050615") < val("14050631"), True)
    before = val("14050631")

    m2.set_month(con, "140502", "level", 16200)      # رقم واقعی بانک مرکزی رسید
    m2.rebuild(con)
    # اردیبهشت قفل می‌شود، چهار ماه بعدش با همان ۳.۵۴٪ از روی آن ادامه می‌یابند
    check("اردیبهشت دقیقاً روی رقم واقعی نشست", round(val("14050231"), 1), 16200.0, 1.0)
    check("پایان شهریور بعد از اصلاح", round(val("14050631"), 1),
          round(16200 * 1.0354 ** 4, 1), 1.0)
    check("اصلاح واقعاً ماه‌های بعدی را جابه‌جا کرد", val("14050631") > before * 1.01, True)
    check("فروردین (قبل از ماهِ اصلاح‌شده) دست‌نخورده ماند",
          round(val("14050131"), 1), round(14834.48 * 1.0354, 1), 1.0)
    src = con.execute("SELECT source FROM observations WHERE series='m2' AND date_j='14050231'"
                      ).fetchone()[0]
    check("منبع اردیبهشت رقم واقعی شد", src, "m2_level")

    print(f"\n{ok} تست سبز، {fail} قرمز")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
