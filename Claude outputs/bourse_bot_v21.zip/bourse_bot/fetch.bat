@echo off
REM ===================================================================
REM  One-off automatic harvest from chartix / tradersarena / parsis.
REM  You normally do NOT need this - the bot does it twice a day on
REM  its own. Use it to catch up after the PC was off for a while.
REM
REM      fetch.bat          today and the last 10 trading days
REM      fetch.bat --deep   also goes further back in the parsis channel
REM
REM  All three sites are reachable only from inside Iran, so this must
REM  run on this machine - not on a server.
REM  Messages are ASCII on purpose - the console mangles Persian.
REM ===================================================================
setlocal
cd /d "%~dp0"

where python >nul 2>nul && (set "PY=python") || (set "PY=py")

echo.
echo === Harvesting ...
%PY% collect.py %*
if errorlevel 1 (
  echo.
  echo [X] Harvest failed. Check your internet connection, then run:
  echo       python tests\run.py
  echo     If the tests pass, the parsers are fine and the problem is
  echo     the network. If they fail, a site changed its layout.
  echo.
  pause & exit /b 1
)

echo.
echo Done. Run update.bat to rebuild and publish the page.
echo.
pause
