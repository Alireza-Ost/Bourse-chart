# -*- coding: utf-8 -*-
"""
تریدرزآرنا — جدول «سوابق معاملات» (۱۰ روز آخر، بدون نیاز به لاگین).

    https://tradersarena.ir/market/history?type=1

چرا این منبع ارزش دارد: یک صفحه، ۱۰ روز، و شش سری با هم —
ارزش معاملات خرد، ورود پول حقیقی، سرانهٔ خرید و فروش، شاخص کل و هم‌وزن.
چون ۱۰ روز می‌دهد نه یک روز، اگر کامپیوتر چند روز خاموش باشد خودش
عقب‌افتادگی را جبران می‌کند؛ این مهم‌ترین مزیتش است.

نکتهٔ `type`: سه نسخهٔ مختلف از «ارزش معاملات» دارد.
    type=0  سهام + حق تقدم + صندوق سهامی + درآمدثابت   (۹۹٬۴۸۵ در ۱۴۰۵/۰۷/۱۲)
    type=1  سهام + حق تقدم + صندوق سهامی               (۵۱٬۳۲۰ در همان روز)
    type=2  سهام + حق تقدم                             (۳۸٬۷۱۶ در همان روز)
`type=1` همان تعریفی است که سری `value_retail` ما دارد — کانال پارسیس برای
همان روز ۵۱٬۳۱۴ گزارش کرد، یعنی یک‌صدم درصد اختلاف. هر type دیگری سری را
پله‌دار می‌کند.

ستون شاخص فقط روی ردیف روزهای *گذشته* پر است؛ ردیف امروز دو ستون کمتر دارد
چون شاخص پایانی هنوز اعلام نشده. پس ستون‌ها از روی هدر نگاشت می‌شوند و
ردیف کوتاه هم بدون خطا رد می‌شود.
"""
import re

from .common import get, num, strip_tags

URL = "https://tradersarena.ir/market/history?type=1"

# عنوان ستون (بعد از حذف تگ‌ها و فشرده‌کردن فاصله‌ها)  ->  (سری، ضریب)
# ضریب واحد را به واحد دیتابیس می‌برد. ارزش معاملات و ورود پول هر دو
# «میلیارد تومان»اند و سری ما هم همان است، پس ۱.
#
# سرانهٔ خرید/فروش عمداً اینجا نیست. تریدرزآرنا آن را «به ازای هر نماد»
# می‌دهد (۸۶.۵ و ۱۱۷.۹ در ۱۴۰۵/۰۷/۱۲) ولی پارسیس «به ازای هر کد»
# (۸۳.۴ و ۷۷.۴) — دو تعریف متفاوت از یک اسم. تاریخچهٔ سری ما از پارسیس
# آمده، پس همان‌جا می‌ماند تا وسط سری پله نیفتد.
COLUMNS = {
    "ارزش معاملات میلیارد تومان":   ("value_retail", 1.0),
    "ورود پول میلیارد تومان":       ("flow_retail",  1.0),
    "شاخص کل":                      ("index_total",  1.0),
    "شاخص هم وزن":                  ("index_ew",     1.0),
}

ROW_RE = re.compile(r"<tr\b[^>]*>(.*?)</tr>", re.S)
CELL_RE = re.compile(r"<t[dh]\b[^>]*>(.*?)</t[dh]>", re.S)
TABLE_RE = re.compile(r'<table[^>]*id="histo"[^>]*>(.*?)</table>', re.S)
DATE_RE = re.compile(r"\b(1[34]\d{2})/(\d{2})/(\d{2})\b")


def _text(cell_html: str) -> str:
    return re.sub(r"\s+", " ", strip_tags(cell_html)).strip()


def parse(html: str):
    """خروجی: (rows, notes) — rows = [(date_j, series, value, src_ref), …]"""
    notes = []
    m = TABLE_RE.search(html)
    if not m:
        return [], ["جدول «histo» در صفحهٔ تریدرزآرنا پیدا نشد — ساختار صفحه عوض شده؟"]

    trs = ROW_RE.findall(m.group(1))
    if not trs:
        return [], ["جدول تریدرزآرنا خالی برگشت."]

    header = [_text(c) for c in CELL_RE.findall(trs[0])]
    # عنوان و واحد در دو span جدا هستند؛ _text با یک فاصله به هم می‌چسباندشان.
    wanted = {}                       # شمارهٔ ستون -> (سری، ضریب)
    for i, h in enumerate(header):
        if h in COLUMNS:
            wanted[i] = COLUMNS[h]
    missing = set(s for s, _ in COLUMNS.values()) - set(s for s, _ in wanted.values())
    if missing:
        notes.append("ستون‌های پیدانشده در تریدرزآرنا: " + "، ".join(sorted(missing)))
    if not wanted:
        return [], notes + ["هیچ ستون شناخته‌شده‌ای در جدول تریدرزآرنا نبود."]

    rows = []
    for tr in trs[1:]:
        cells = CELL_RE.findall(tr)
        if len(cells) < 3:
            continue
        d = DATE_RE.search(_text(cells[1]))
        if not d:
            continue
        date_j = d.group(1) + d.group(2) + d.group(3)
        for i, (series, factor) in wanted.items():
            if i >= len(cells):        # ردیف امروز: ستون شاخص هنوز نیامده
                continue
            v = num(_text(cells[i]))
            if v is None:
                continue
            rows.append((date_j, series, v * factor, "tradersarena/history?type=1"))
    if not rows:
        notes.append("جدول تریدرزآرنا خوانده شد ولی هیچ ردیف معتبری نداشت.")
    return rows, notes


def fetch(session=None):
    try:
        html = get(URL, session)
    except Exception as e:                        # noqa: BLE001
        return [], [f"تریدرزآرنا در دسترس نبود: {e}"]
    return parse(html)


def trading_days(rows):
    """روزهایی که تریدرزآرنا برایشان ارزش معاملات دارد = روز معاملاتی بوده."""
    return {d for d, s, v, _ in rows if s == "value_retail" and v}
