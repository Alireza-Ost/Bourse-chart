# -*- coding: utf-8 -*-
"""
کانال «پارسیس تحلیل» — بدون فوروارد دستی.

تلگرام برای هر کانال عمومی یک نسخهٔ وب دارد:

    https://t.me/s/parsistahlil

همان پست‌ها را به‌صورت HTML ساده می‌دهد. پس همان `parse_parsis` که برای
پیام‌های فورواردشده نوشته‌ایم، بدون هیچ تغییری روی این متن‌ها هم کار می‌کند —
فقط متن از جای دیگری می‌آید.

با `?before=<id>` می‌شود عقب‌تر رفت؛ `fetch(pages=n)` همین کار را می‌کند و
برای پرکردن روزهای جامانده به درد می‌خورد.

⚠ این آدرس روی telegram.org است. اگر روی کامپیوتر شما باز نشود این منبع
می‌افتد و تریدرزآرنا جایش را می‌گیرد — بقیهٔ زنجیره سالم می‌ماند.
"""
import datetime
import html as _html
import re

from .common import get

CHANNEL = "parsistahlil"
URL = "https://t.me/s/{ch}"

MSG_RE = re.compile(
    r'<div class="tgme_widget_message_text[^"]*"[^>]*>(.*?)</div>', re.S)
TIME_RE = re.compile(r'<time[^>]*datetime="([^"]+)"')
POST_RE = re.compile(r'data-post="[^/]+/(\d+)"')


def _plain(fragment: str) -> str:
    t = re.sub(r"<br\s*/?>", "\n", fragment)
    t = re.sub(r"<[^>]+>", "", t)
    return _html.unescape(t)


def posts(html: str):
    """[(متن، تاریخ میلادی), …] به ترتیب صفحه (قدیمی → جدید)."""
    texts = MSG_RE.findall(html)
    times = TIME_RE.findall(html)
    out = []
    for i, frag in enumerate(texts):
        when = None
        if i < len(times):
            try:
                when = datetime.datetime.fromisoformat(times[i]).date()
            except ValueError:
                when = None
        out.append((_plain(frag), when or datetime.date.today()))
    return out


def oldest_id(html: str):
    ids = [int(x) for x in POST_RE.findall(html)]
    return min(ids) if ids else None


def parse(html: str):
    """خروجی: (rows, notes)"""
    from parsers import parse_parsis
    rows, notes = [], []
    found = 0
    for text, when in posts(html):
        for date_j, series, value, _wd in parse_parsis(text, when):
            rows.append((date_j, series, value, f"t.me/s/{CHANNEL}"))
            found += 1
    if not found:
        notes.append("صفحهٔ وب کانال پارسیس خوانده شد ولی هیچ عددی شناخته نشد.")
    return rows, notes


def fetch(pages=1, session=None):
    """pages>1 یعنی با ?before= عقب‌تر هم می‌رود (برای پرکردن روزهای جامانده)."""
    url = URL.format(ch=CHANNEL)
    rows, notes = [], []
    for _ in range(max(1, pages)):
        try:
            html = get(url, session)
        except Exception as e:                    # noqa: BLE001
            notes.append(f"صفحهٔ وب کانال پارسیس در دسترس نبود: {e}")
            break
        r, n = parse(html)
        rows += r
        notes += n
        older = oldest_id(html)
        if not older:
            break
        url = URL.format(ch=CHANNEL) + f"?before={older}"
    return rows, notes
