# -*- coding: utf-8 -*-
"""ابزارهای مشترک منابع خودکار."""
import re

import jdatetime

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

TIMEOUT = 20


def get(url: str, session=None) -> str:
    """یک GET ساده با هدر مرورگر. استثنا را بالا می‌دهد تا صدازننده تصمیم بگیرد."""
    import requests
    s = session or requests
    r = s.get(url, headers={"User-Agent": UA, "Accept-Language": "fa,en;q=0.8"},
              timeout=TIMEOUT)
    r.raise_for_status()
    return r.text


FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
AR_DIGITS = "٠١٢٣٤٥٦٧٨٩"


def num(s):
    """'۱٬۲۳۴.۵' یا '418.87 K' یا '-846.4' → float. نشد → None."""
    if s is None:
        return None
    out = []
    for ch in str(s):
        if ch in FA_DIGITS:
            out.append(str(FA_DIGITS.index(ch)))
        elif ch in AR_DIGITS:
            out.append(str(AR_DIGITS.index(ch)))
        else:
            out.append(ch)
    t = "".join(out).replace("٬", "").replace(",", "").strip()
    mult = 1.0
    if t.endswith(("K", "k")):
        mult, t = 1e3, t[:-1].strip()
    elif t.endswith(("M", "m")):
        mult, t = 1e6, t[:-1].strip()
    m = re.search(r"-?\d+(?:\.\d+)?", t)
    return float(m.group(0)) * mult if m else None


def strip_tags(html: str) -> str:
    return re.sub(r"<[^>]+>", " ", html)


def today_j() -> str:
    return jdatetime.date.today().strftime("%Y%m%d")


def is_weekend(date_j: str) -> bool:
    """پنجشنبه و جمعه — بازار بورس تعطیل است."""
    jd = jdatetime.date(int(date_j[:4]), int(date_j[4:6]), int(date_j[6:]))
    return jd.weekday() in (5, 6)        # 0=شنبه … 5=پنجشنبه، 6=جمعه
