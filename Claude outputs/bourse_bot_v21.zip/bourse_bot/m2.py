# -*- coding: utf-8 -*-
"""
نقدینگی M2 — مدل ماهانه با امکان اصلاح بازگشتی.

مسئله: بانک مرکزی نقدینگی را ماهانه و با چند ماه تأخیر منتشر می‌کند، ولی
نمودار روزانه است. تا امروز این‌طور حلش کرده بودیم که یک نرخ رشد فرضی
بگیریم و روزها را پر کنیم — ولی وقتی رقم واقعی می‌رسید، اصلاحش دردسر بود.

مدل تازه: به‌جای ذخیرهٔ خروجی، *ورودی* را ذخیره می‌کنیم.

    جدول m2_months:  هر ماه شمسی یک ردیف
        kind='rate'   → درصد رشد آن ماه (حدس شما)
        kind='level'  → رقم واقعی پایان آن ماه به همت (بانک مرکزی)

`rebuild()` از روی این جدول کل سری روزانه را از نو می‌سازد. چون ماه‌ها
زنجیروارند، عوض‌کردن یک ماه خودبه‌خود همهٔ ماه‌های بعدش را هم جابه‌جا
می‌کند. یعنی اصلاح، *همان* نوشتن رقم تازه است — کار اضافه‌ای ندارد:

    /m2real 1405/02 15120      ← رقم واقعی اردیبهشت رسید
    (اردیبهشت تا امروز، همه با هم، خودکار اصلاح می‌شوند)

داخل هر ماه رشد به‌صورت مرکب روزانه پخش می‌شود، نه خطی — نقدینگی درصدی
رشد می‌کند نه مقداری، و با رشد ۳٪ ماهانه تفاوتش در وسط ماه دیده می‌شود.

منبع ردیف‌های ساخته‌شده:
    m2_level  روزهای ماهی که رقم واقعی دارد      (اولویت بالا)
    m2_rate   روزهای ماهی که فقط نرخ فرضی دارد   (اولویت پایین)
هر دو در هر بازسازی پاک و از نو نوشته می‌شوند، پس بازسازی idempotent است.
لنگرهای واقعیِ قدیمی (xlsx_seed، manual، …) هرگز پاک نمی‌شوند و مبنای
زنجیره‌اند.
"""
import datetime

import jdatetime

SCHEMA = """
CREATE TABLE IF NOT EXISTS m2_months (
    month_j   TEXT PRIMARY KEY,      -- YYYYMM شمسی
    kind      TEXT NOT NULL,         -- 'rate' یا 'level'
    value     REAL NOT NULL,         -- درصد رشد ماهانه، یا همت
    note      TEXT,
    set_at    TEXT
);
"""

# منابعی که خود این ماژول می‌سازد و در هر بازسازی دور ریخته می‌شوند.
GENERATED = ("m2_level", "m2_rate", "m2_carry",
             "m2_interp", "m2_extrap", "m2_estimate")


# ---- جدول ماه‌ها --------------------------------------------------------

def ensure(con):
    con.executescript(SCHEMA)
    con.commit()


def set_month(con, month_j, kind, value, note=""):
    """kind='rate' درصد رشد ماهانه · kind='level' رقم واقعی پایان ماه (همت)."""
    if kind not in ("rate", "level"):
        raise ValueError("kind باید 'rate' یا 'level' باشد")
    ensure(con)
    con.execute(
        "INSERT INTO m2_months VALUES (?,?,?,?,?) ON CONFLICT(month_j) DO UPDATE SET "
        "kind=excluded.kind, value=excluded.value, note=excluded.note, set_at=excluded.set_at",
        (month_j, kind, float(value), note,
         datetime.datetime.now().isoformat(timespec="seconds")))
    con.commit()


def clear_month(con, month_j):
    ensure(con)
    n = con.execute("DELETE FROM m2_months WHERE month_j=?", (month_j,)).rowcount
    con.commit()
    return n


def months(con):
    ensure(con)
    return con.execute(
        "SELECT month_j, kind, value, note FROM m2_months ORDER BY month_j").fetchall()


# ---- تقویم --------------------------------------------------------------

def month_len(month_j):
    """تعداد روزهای یک ماه شمسی (با در نظر گرفتن کبیسه برای اسفند)."""
    y, m = int(month_j[:4]), int(month_j[4:6])
    if m <= 6:
        return 31
    if m <= 11:
        return 30
    return 30 if jdatetime.date(y, 1, 1).isleap() else 29


def month_end(month_j):
    return f"{month_j}{month_len(month_j):02d}"


def next_month(month_j):
    y, m = int(month_j[:4]), int(month_j[4:6])
    return f"{y + 1}01" if m == 12 else f"{y}{m + 1:02d}"


def _day_index(date_j, month_j):
    """چندمین روز ماه است (۱ تا طول ماه)."""
    return int(date_j[6:])


# ---- بازسازی ------------------------------------------------------------

def base_anchor(con):
    """آخرین رقم نقدینگیِ *واقعی* در دیتابیس — مبنای زنجیره."""
    q = "SELECT date_j, value FROM observations WHERE series='m2' AND source NOT IN ({}) " \
        "ORDER BY date_j DESC LIMIT 1".format(",".join("?" * len(GENERATED)))
    return con.execute(q, GENERATED).fetchone()


def chain(con, carry=True):
    """
    [(month_j, پایان ماه به همت، kind)] — زنجیرهٔ ماه‌ها از روی لنگر واقعی.

    هر ماهی که رقم واقعی دارد همان‌جا زنجیره را «قفل» می‌کند؛ ماه‌های بعدی
    از روی آن ادامه می‌یابند. ماه‌هایی که نه رقم دارند نه نرخ، زنجیره را
    تمام می‌کنند — عمداً حدس نمی‌زنیم.

    carry: ماه‌های بعد از آخرین ماهِ ثبت‌شده تا همین ماهِ جاری با *آخرین
    نرخ* ادامه داده می‌شوند، با kind='carry'. وگرنه هر ماه باید دستی وارد
    شود وگرنه نمودار همان‌جا تمام می‌شود. هر ماهی که بعداً دستی ثبت کنید
    جای ادامهٔ خودکار را می‌گیرد.
    """
    anchor = base_anchor(con)
    if not anchor:
        return [], "هیچ رقم واقعی نقدینگی در دیتابیس نیست."
    d0, v0 = anchor
    table = {m: (k, v) for m, k, v, _ in months(con)}
    if not table:
        return [], None

    out = []
    cur = next_month(d0[:6])
    level = v0
    last = max(table)
    last_rate = None
    while cur <= last:
        entry = table.get(cur)
        if entry is None:
            # ماهی که ثبت نشده زنجیره را نمی‌شکند؛ با آخرین نرخ پر می‌شود
            # تا ماه‌های ثبت‌شدهٔ بعدی از کار نیفتند. اگر هنوز هیچ نرخی
            # نداشته‌ایم، همین‌جا تمام — حدس بی‌پایه نمی‌زنیم.
            if last_rate is None:
                break
            level *= 1 + last_rate / 100
            out.append((cur, level, "carry"))
            cur = next_month(cur)
            continue
        kind, val = entry
        if kind == "rate":
            last_rate = val
        level = val if kind == "level" else level * (1 + val / 100)
        out.append((cur, level, kind))
        cur = next_month(cur)

    if carry and out and last_rate is not None:
        this_month = jdatetime.date.today().strftime("%Y%m")
        while cur <= this_month:
            level *= 1 + last_rate / 100
            out.append((cur, level, "carry"))
            cur = next_month(cur)
    return out, None


def rebuild(con, axis_series_excluded=("gold18", "m2")):
    """
    سری روزانهٔ نقدینگی را از نو می‌سازد.

    خروجی: (تعداد روز نوشته‌شده، اولین روز، آخرین روز، پیام خطا یا None)
    """
    from store import upsert, derive_totals
    ensure(con)

    anchor = base_anchor(con)
    if not anchor:
        return 0, None, None, "هیچ رقم واقعی نقدینگی در دیتابیس نیست."
    d0, v0 = anchor

    link, err = chain(con)
    if err:
        return 0, None, None, err
    if not link:
        return 0, None, None, "هیچ ماهی در جدول نرخ‌ها ثبت نشده — /m2rate بزنید."

    # روزهای محور نمودار (هر روزی که دست‌کم یک سری بورسی دارد)
    ph = ",".join("?" * len(axis_series_excluded))
    axis = [r[0] for r in con.execute(
        f"SELECT DISTINCT date_j FROM observations WHERE series NOT IN ({ph}) "
        "ORDER BY date_j", axis_series_excluded)]

    # ردیف‌های ساخته‌شدهٔ قبلی را دور می‌ریزیم تا بازسازی واقعاً «از نو» باشد؛
    # وگرنه قاعدهٔ اولویت منبع جلوی اصلاحِ رو‌به‌پایین را می‌گیرد.
    #
    # فقط *بعد از* لنگر. قبل از آن، روزهای بین لنگرهای واقعیِ تاریخی با
    # درون‌یابی پر شده‌اند (۱۳۹۹ تا ۱۴۰۴، چند صد روز) و ربطی به مدل ماهانه
    # ندارند — پاک‌کردنشان یعنی سوراخ‌کردن نمودار تاریخی.
    con.execute(
        "DELETE FROM observations WHERE series='m2' AND date_j > ? AND source IN ({})".format(
            ",".join("?" * len(GENERATED))), (d0,) + tuple(GENERATED))
    con.commit()

    # نقاط شکست: از لنگر واقعی تا پایان هر ماه زنجیره. بین هر دو نقطه،
    # رشد *مرکب* روزانه پخش می‌شود نه خطی — نقدینگی درصدی رشد می‌کند نه
    # مقداری، و با ۳٪ ماهانه این تفاوت وسط ماه دیده می‌شود.
    #
    # اولین بازه از خودِ تاریخ لنگر شروع می‌شود، نه از اول ماه بعد. وگرنه
    # روزهای باقی‌ماندهٔ ماهِ لنگر (مثلاً ۷ تا ۲۹ اسفند) بی‌صاحب می‌مانند.
    from store import _days_between
    points = [(d0, v0, None, None)]
    for month_j, end_level, kind in link:
        src = {"level": "m2_level", "rate": "m2_rate"}.get(kind, "m2_carry")
        label = {"level": "رقم بانک مرکزی", "rate": "نرخ فرضی"}.get(
            kind, "ادامهٔ آخرین نرخ")
        points.append((month_end(month_j), end_level, src, f"{month_j} · {label}"))

    written, touched = 0, set()
    for (da, va, _s, _r), (db, vb, src, ref) in zip(points, points[1:]):
        span = [d for d in axis if da < d <= db]
        if not span or not va:
            continue
        total = max(1, _days_between(da, db))
        ratio = vb / va
        for d in span:
            k = _days_between(da, d)
            res = upsert(con, d, "m2", va * (ratio ** (k / total)), src, ref)
            if res.split(":")[0] in ("inserted", "updated"):
                written += 1
                touched.add(d)

    if touched:
        derive_totals(con, touched)
    days = sorted(touched)
    return written, (days[0] if days else None), (days[-1] if days else None), None


def summary(con):
    """متن فارسی وضعیت ماه‌ها — برای /m2months."""
    anchor = base_anchor(con)
    rows = months(con)
    if not rows:
        return "هنوز هیچ ماهی ثبت نشده.\nمثال:  /m2rate 1405/07 3.1"
    link, err = chain(con)
    if err:
        return err
    level_of = {m: lv for m, lv, _ in link}
    out = []
    if anchor:
        out.append(f"لنگر واقعی: {anchor[0][:4]}/{anchor[0][4:6]}/{anchor[0][6:]}"
                   f" = {anchor[1]:,.0f} همت\n")
    entry = {m: (k, v) for m, k, v, _ in rows}
    for month_j, lv, kind in link:          # به ترتیب زمانی، شامل ماه‌های خودکار
        label = f"{month_j[:4]}/{month_j[4:6]}"
        if kind == "level":
            out.append(f"  {label}  رقم واقعی {lv:,.0f} همت ✅")
        elif kind == "rate":
            out.append(f"  {label}  رشد {entry[month_j][1]:g}٪ → {lv:,.0f} همت")
        else:
            out.append(f"  {label}  ادامهٔ خودکار → {lv:,.0f} همت")
    orphan = [m for m in entry if m not in level_of]
    if orphan:
        out.append("\n(خارج از زنجیره، چون قبل از لنگر واقعی‌اند: " +
                   "، ".join(sorted(orphan)) + ")")
    return "\n".join(out)
