# -*- coding: utf-8 -*-
"""
پر کردن اولیهٔ دیتابیس از فایل اکسل بازار.

    python3 seed_from_xlsx.py "/path/to/بررسی بازار.xlsx"

ستون‌ها بر اساس *نام سرستون* پیدا می‌شوند نه شمارهٔ ستون، تا اگر ترتیب ستون‌های
فایل عوض شد (که شد) این اسکریپت بی‌صدا دادهٔ اشتباه نریزد. هر دو شیت خوانده
می‌شوند، چون MV/M2/نسبت از «معاملات بورس» به شیت «نقدینگی» منتقل شده‌اند.

تاریخ تکراری: ردیف اول نگه داشته می‌شود و بقیه رد می‌شوند — با هشدار.
"""
import sys
import openpyxl
from store import connect, upsert

# نام شیت -> { نام سرستون در اکسل : کلید سری }
SHEETS = {
    "معاملات بورس": {
        "مجموع ارزش معاملات":        "value_retail",
        "ورود نقدینگی":              "flow_retail",
        "شاخص هم وزن":               "index_ew",
        "شاخص کل":                   "index_total",
        "P/E":                       "pe_market",
    },
    "نقدینگی": {
        "ارزش بازار MV (همت)":        "mv",
        "نقدینگی M2 (همت)":           "m2",
        "نسبت ارزش بازار به نقدینگی": "ratio",
    },
}


def read_sheet(wb, name, cols, con, stats, seen):
    if name not in wb.sheetnames:
        print(f"شیت «{name}» در فایل نیست — رد شد.")
        return
    ws = wb[name]
    it = ws.iter_rows(values_only=True)
    head = next(it)
    idx = {h: i for i, h in enumerate(head) if h}
    missing = [h for h in cols if h not in idx]
    if missing:
        print(f"[{name}] سرستون پیدا نشد (رد شد): " + "، ".join(missing))
    if "تاریخ" not in idx:
        print(f"[{name}] ستون «تاریخ» پیدا نشد — کل شیت رد شد.")
        return

    for row in it:
        d = row[idx["تاریخ"]]
        if d is None:
            continue
        date_j = str(d).strip()
        if len(date_j) != 8 or not date_j.isdigit():
            continue
        key_seen = (name, date_j)
        if key_seen in seen:
            stats[("—", "تاریخ تکراری")] = stats.get(("—", "تاریخ تکراری"), 0) + 1
            continue
        seen.add(key_seen)
        for h, key in cols.items():
            if h not in idx:
                continue
            v = row[idx[h]]
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                res = upsert(con, date_j, key, float(v), "xlsx_seed", h)
                stats[(key, res.split(":")[0])] = stats.get((key, res.split(":")[0]), 0) + 1


def main(path):
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    con = connect()
    stats, seen = {}, set()
    for name, cols in SHEETS.items():
        read_sheet(wb, name, cols, con, stats, seen)
    con.close()
    for (key, res), n in sorted(stats.items()):
        print(f"{key:14s} {res:16s} {n}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "بررسی بازار.xlsx")
