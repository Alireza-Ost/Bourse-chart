@echo off
REM ===================================================================
REM  Puts a shortcut to run_bot.bat in the Windows Startup folder, so
REM  the bot comes back by itself after a restart.
REM  Run it once. To undo, delete BourseBot.lnk from that folder
REM  (Win+R -> shell:startup).
REM ===================================================================
setlocal
cd /d "%~dp0"

powershell -NoProfile -Command ^
  "$w = New-Object -ComObject WScript.Shell;" ^
  "$p = [Environment]::GetFolderPath('Startup') + '\BourseBot.lnk';" ^
  "$s = $w.CreateShortcut($p);" ^
  "$s.TargetPath = '%~dp0run_bot.bat';" ^
  "$s.WorkingDirectory = '%~dp0';" ^
  "$s.Description = 'Bourse Telegram bot';" ^
  "$s.Save();" ^
  "Write-Host ('Shortcut created: ' + $p)"

if errorlevel 1 (
  echo.
  echo [X] Could not create the shortcut.
  echo     Do it by hand: press Win+R, type  shell:startup  and press Enter,
  echo     then drag run_bot.bat into that folder while holding Alt.
  echo.
  pause & exit /b 1
)

echo.
echo Done. The bot will start on its own after every restart.
echo Check now: press Win+R, type  shell:startup  - BourseBot.lnk should be there.
echo.
pause
