# -*- coding: utf-8 -*-
"""
میانگین متحرک و تشخیص برخورد.

دو نکته که این را از یک rolling(n).mean() ساده جدا می‌کند:

۱) گسست داده. فرق «بازار تعطیل بوده» با «داده نداریم» مهم است: تعطیلی یعنی آن
   روزها معامله‌ای نبوده و میانگینِ ۲۰۰ روز معاملاتی از رویش رد می‌شود؛ ولی
   حفرهٔ داده، میانگین را بی‌معنی می‌کند. تشخیص با ترکیب فاصلهٔ تقویمی و پرش
   مقدار است — هر میانگینی که پنجره‌اش گسست داشته باشد NaN می‌شود.

۲) تأیید برخورد. وقتی دو میانگین به هم نزدیک‌اند، نویز باعث می‌شود چند روز
   پشت‌سرهم قطع و وصل شوند. برخورد وقتی معتبر است که فاصله از آستانه عبور کند
   یا علامت چند روز پایدار بماند.
"""
import datetime
import jdatetime
import pandas as pd
from config import (MA_PAIRS, GAP_DAYS, GAP_BREAK_JUMP, CROSS_MIN_SEPARATION,
                    CROSS_MIN_SEPARATION_BY_SERIES, CONFIRM_DAYS, SERIES)


def to_frame(rows):
    """[(YYYYMMDD شمسی, value)] → DataFrame با ایندکس میلادی و ستون تاریخ شمسی."""
    recs = []
    for d, v in rows:
        d = str(d)
        try:
            g = jdatetime.date(int(d[:4]), int(d[4:6]), int(d[6:])).togregorian()
        except ValueError:
            continue
        recs.append((g, d, float(v)))
    if not recs:
        return pd.DataFrame(columns=["date_j", "value"])
    df = pd.DataFrame(recs, columns=["g", "date_j", "value"]).sort_values("g")
    return df.set_index("g")


def breaking_gaps(df):
    """
    Series بولی: True یعنی این ردیف بعد از یک «گسست واقعی» آمده.
    گسست = فاصلهٔ تقویمی بزرگ *و* پرش بزرگ در مقدار. تعطیلی بازار که مقدار را
    جابه‌جا نکرده، گسست حساب نمی‌شود و میانگین از رویش رد می‌شود.
    """
    days = df.index.to_series().diff().dt.days.fillna(0)
    jump = df["value"].pct_change().abs().fillna(0)
    return (days > GAP_DAYS) & (jump > GAP_BREAK_JUMP)


def _gap_mask(df, window):
    """True یعنی پنجرهٔ این نقطه گسست دارد و میانگینش بی‌اعتبار است."""
    brk = breaking_gaps(df).astype(int)
    return brk.rolling(window, min_periods=1).sum().gt(0)


def moving_averages(df, fast, slow):
    out = df.copy()
    for n, col in ((fast, f"ma{fast}"), (slow, f"ma{slow}")):
        ma = out["value"].rolling(n, min_periods=n).mean()
        ma[_gap_mask(out, n).values] = float("nan")
        out[col] = ma
    return out


def crossovers(df, fast, slow, key=None):
    """فهرست برخوردهای تأییدشده: [{date_j, kind, fast, slow, sep}]"""
    f, s = f"ma{fast}", f"ma{slow}"
    d = df.dropna(subset=[f, s]).copy()
    if len(d) < CONFIRM_DAYS + 1:
        return []
    d["diff"] = d[f] - d[s]
    d["sign"] = d["diff"].apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
    # مقیاس مرجع: میانگین قدرمطلق سری در پنجرهٔ کند. همیشه مثبت، و برای
    # سری‌های دوعلامته (جریان پول) هم معنی‌دار می‌ماند.
    scale = d["value"].abs().rolling(slow, min_periods=1).mean().replace(0, float("nan"))
    d["sep"] = d["diff"].abs() / scale

    thr = CROSS_MIN_SEPARATION_BY_SERIES.get(key, CROSS_MIN_SEPARATION)
    events, sign_prev = [], d["sign"].iloc[0]
    signs = d["sign"].tolist()
    for i in range(1, len(d)):
        cur = signs[i]
        if cur == 0 or cur == sign_prev:
            if cur != 0:
                sign_prev = cur
            continue
        row = d.iloc[i]
        persistent = all(signs[j] == cur for j in range(i, min(i + CONFIRM_DAYS, len(signs))))
        confirmed = (row["sep"] >= thr) and persistent
        if confirmed:
            events.append(dict(
                date_j=row["date_j"],
                kind="طلایی" if cur > 0 else "مرگ",
                fast=float(row[f]), slow=float(row[s]),
                sep=float(row["sep"]) * 100,
                value=float(row["value"]),
            ))
        sign_prev = cur
    return events


def analyse_series(con, key):
    """DataFrame با میانگین‌ها + فهرست برخوردها. اگر سری تعریف MA ندارد، None."""
    from store import load_series
    if key not in MA_PAIRS:
        return None, []
    fast, slow = MA_PAIRS[key]
    df = to_frame(load_series(con, key))
    if df.empty:
        return df, []
    df = moving_averages(df, fast, slow)
    return df, crossovers(df, fast, slow, key)


def latest_state(df, fast, slow):
    """وضعیت فعلی: میانگین تند بالای کند است یا پایین، و چند روز است."""
    f, s = f"ma{fast}", f"ma{slow}"
    d = df.dropna(subset=[f, s])
    if d.empty:
        return None
    sign = 1 if d[f].iloc[-1] > d[s].iloc[-1] else -1
    n = 0
    for i in range(len(d) - 1, -1, -1):
        cur = 1 if d[f].iloc[i] > d[s].iloc[i] else -1
        if cur != sign:
            break
        n += 1
    return dict(above=sign > 0, days=n,
                fast=float(d[f].iloc[-1]), slow=float(d[s].iloc[-1]),
                date_j=d["date_j"].iloc[-1])


def _days_between(j1, j2):
    """فاصلهٔ روز بین دو تاریخ شمسی YYYYMMDD."""
    def g(j):
        j = str(j)
        return jdatetime.date(int(j[:4]), int(j[4:6]), int(j[6:])).togregorian()
    return abs((g(j2) - g(j1)).days)


def report(con, days_back=120, stale_after=45):
    """
    متن گزارش فارسی برای ارسال در تلگرام.

    تفاوت «آخرین داده» و «آخرین میانگین معتبر» عمداً نشان داده می‌شود: اگر سری
    شکاف داشته باشد، میانگین متحرک ماه‌ها عقب‌تر از آخرین دادهٔ خام است و
    وضعیتی که اعلام می‌شود مالِ امروز نیست.
    """
    today = jdatetime.date.fromgregorian(date=datetime.date.today())
    cutoff = (today - jdatetime.timedelta(days=days_back)).strftime("%Y%m%d")
    today_j = today.strftime("%Y%m%d")
    lines = []
    for key, (fast, slow) in MA_PAIRS.items():
        name = SERIES[key][0]
        df, events = analyse_series(con, key)
        if df is None or df.empty:
            continue
        last_data = df["date_j"].iloc[-1]
        st = latest_state(df, fast, slow)

        if st is None:
            lines.append(f"⚪️ <b>{name}</b> — داده هست (تا {last_data}) ولی برای "
                         f"MA{slow} پیوستگی کافی وجود ندارد")
            continue

        stale = _days_between(st["date_j"], today_j) > stale_after
        arrow = "⚪️" if stale else ("🟢" if st["above"] else "🔴")
        rel = "بالای" if st["above"] else "زیر"
        lines.append(f"{arrow} <b>{name}</b> — MA{fast} {rel} MA{slow} ({st['days']} روز)")
        if stale:
            lines.append(f"    ⏳ این وضعیت مالِ {st['date_j']} است، نه امروز — "
                         f"سری تا {last_data} داده دارد ولی شکاف دارد")
        else:
            lines.append(f"    آخرین داده: {last_data}")

        recent = [e for e in events if e["date_j"] >= cutoff]
        for e in recent[-3:]:
            icon = "✨" if e["kind"] == "طلایی" else "⚠️"
            lines.append(f"    {icon} تقاطع {e['kind']} در {e['date_j']} "
                         f"(فاصله {e['sep']:.1f}٪ از میانگین قدرمطلق سری)")
        if not recent and not stale:
            lines.append(f"    — برخورد تازه‌ای در {days_back} روز اخیر نبود")
    return "\n".join(lines) if lines else "داده‌ای برای تحلیل نیست."
