#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ساخت دو قالب صفحهٔ نمودار از روی head.html + app.js.

    python3 charts/build_templates.py

    template.html      داده به جای __DATA__ می‌نشیند (برای دیدن روی کامپیوتر)
    template_web.html  داده را از data.json کناری می‌خواند (برای اینترنت)

صفحه در دو جا استفاده می‌شود، پس منبعش یکی است: هر تغییری در ظاهر یا رفتار
نمودار فقط در head.html و app.js نوشته می‌شود و این اسکریپت هر دو قالب را
دوباره می‌سازد. دست‌کاری مستقیم قالب‌ها یعنی دفعهٔ بعد بازنویسی می‌شود.
"""
import pathlib

HERE = pathlib.Path(__file__).parent
head = (HERE / "head.html").read_text(encoding="utf-8")
app = (HERE / "app.js").read_text(encoding="utf-8")

DOC_OPEN = ("<!doctype html><html lang='fa' dir='rtl'><head><meta charset='utf-8'>"
            "<meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'>"
            "<style>html,body{margin:0}[hidden]{display:none!important}</style></head><body>")
DOC_CLOSE = "</body></html>"

(HERE / "template.html").write_text(
    DOC_OPEN + head + "\n<script>\nconst DATA=__DATA__;\n" + app + "\n</script>\n" + DOC_CLOSE,
    encoding="utf-8")

boot = (
    "<div id='boot' style=\"padding:24px;font-family:Vazirmatn,system-ui,sans-serif;color:#82857a\">"
    "در حال بارگذاری داده…</div>\n"
    "<script>\nwindow.__boot=function(DATA){\n" + app + "\n};\n"
    "fetch('data.json?v='+Date.now())\n"
    "  .then(function(r){ if(!r.ok) throw new Error('HTTP '+r.status); return r.json(); })\n"
    "  .then(function(d){ document.getElementById('boot').remove();"
    " document.getElementById('appwrap').hidden=false; window.__boot(d); })\n"
    "  .catch(function(e){ document.getElementById('boot').textContent="
    "'داده بارگذاری نشد ('+e.message+'). مطمئن شوید data.json کنار همین صفحه است.'; });\n"
    "</script>\n")

web = DOC_OPEN + head + "\n" + boot + DOC_CLOSE
web = web.replace('<div class="app">', '<div class="app" hidden id="appwrap">', 1)
(HERE / "template_web.html").write_text(web, encoding="utf-8")

for f in ("template.html", "template_web.html"):
    print(f"  charts/{f}: {(HERE/f).stat().st_size:,} bytes")
