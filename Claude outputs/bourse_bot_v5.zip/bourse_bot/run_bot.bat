@echo off
REM ===================================================================
REM  Starts the Telegram bot. Keep this window open - it is the bot.
REM  Only the token is needed. Set it once, permanently:
REM
REM      setx TELEGRAM_BOT_TOKEN "123456:AA..."
REM
REM  then close and reopen the console (setx only affects new windows).
REM  The owner is registered automatically: send /start to the bot.
REM ===================================================================
setlocal
cd /d "%~dp0"

where python >nul 2>nul && (set "PY=python") || (set "PY=py")

if "%TELEGRAM_BOT_TOKEN%"=="" (
  echo.
  echo [X] TELEGRAM_BOT_TOKEN is not set.
  echo     Run this once in a Command Prompt, then close and reopen it:
  echo.
  echo       setx TELEGRAM_BOT_TOKEN "your-token-from-BotFather"
  echo.
  pause & exit /b 1
)

echo Bot running. Send /start to it in Telegram, then forward channel posts.
echo Ctrl+C to stop.
echo.
%PY% bot.py
pause
