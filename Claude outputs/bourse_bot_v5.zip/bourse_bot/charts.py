# -*- coding: utf-8 -*-
"""
رسم نمودارها (PNG برای ارسال در تلگرام).

قواعدی که رعایت شده و بهتر است موقع تغییر نشکنید:
  • هیچ نموداری دو محور Y ندارد. سری‌هایی با مقیاس متفاوت → نمودار جدا.
  • رنگ‌ها از پالت ثابت و به ترتیب ثابت گرفته می‌شوند (نه چرخشی).
  • هر سری هم در راهنما هست و هم برچسب مستقیم کنار انتهای خط دارد،
    تا هویت سری فقط به رنگ وابسته نباشد.
  • خطوط نازک، شبکهٔ کم‌رنگ، بدون عدد روی تک‌تک نقاط.
"""
import datetime
import jdatetime
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

from config import CHART_DIR, MA_PAIRS, SERIES

# ---- پالت ---------------------------------------------------------------
SURFACE   = "#fcfcfb"
INK       = "#0b0b0b"
INK_2     = "#52514e"
MUTED     = "#898781"
GRID      = "#e1e0d9"
AXIS      = "#c3c2b7"
S1, S2, S3 = "#2a78d6", "#eb6834", "#1baf7a"     # سری، MA تند، MA کند
POS, NEG   = "#2a78d6", "#e34948"                # ورود / خروج پول

# ---- متن فارسی ----------------------------------------------------------
try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    def fa(t: str) -> str:
        return get_display(arabic_reshaper.reshape(str(t)))
except Exception:                                  # بدون کتابخانه، متن خام
    def fa(t: str) -> str:
        return str(t)

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
    "savefig.facecolor": SURFACE,
    "axes.edgecolor": AXIS, "axes.labelcolor": INK_2,
    "xtick.color": MUTED, "ytick.color": MUTED,
    "text.color": INK, "axes.titlecolor": INK,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 130,
})


def _thousands(x, _):
    return f"{x:,.0f}"


def _jalali_ticks(ax, index):
    """محور افقی را با تاریخ شمسی برچسب می‌زند (حدود ۶ برچسب)."""
    if len(index) == 0:
        return
    step = max(1, len(index) // 6)
    pos = list(range(0, len(index), step))
    labs = []
    for i in pos:
        jd = jdatetime.date.fromgregorian(date=index[i].date()
                                          if hasattr(index[i], "date") else index[i])
        labs.append(fa(jd.strftime("%Y/%m")))
    ax.set_xticks(pos)
    ax.set_xticklabels(labs, fontsize=8)


def _label_end(ax, x, y, text, color):
    """برچسب مستقیم کنار انتهای خط — تا هویت سری فقط رنگ نباشد."""
    if y is None or y != y:
        return
    ax.annotate(fa(text), xy=(x, y), xytext=(6, 0), textcoords="offset points",
                color=color, fontsize=8.5, va="center", weight="bold")


def _break_gaps(d, col="value"):
    """
    روی شکاف تقویمی، خط را قطع می‌کند (NaN) تا نمودار یک خط راست از روی
    ماه‌ها تعطیلی نکشد و رشدِ نبوده را نشان ندهد.
    """
    from analyze import breaking_gaps
    y = d[col].astype(float).copy()
    y[breaking_gaps(d).values] = float("nan")
    return y


def line_with_ma(df, key, events=None, tail=None, path=None):
    """سری + دو میانگین متحرک + نشانهٔ برخوردها."""
    name, unit, _ = SERIES[key]
    fast, slow = MA_PAIRS[key]
    d = df.tail(tail) if tail else df
    if d.empty:
        return None
    x = list(range(len(d)))

    fig, ax = plt.subplots(figsize=(9, 4.6))
    ax.plot(x, _break_gaps(d), color=S1, lw=2, label=fa(name), zorder=3)
    ax.plot(x, d[f"ma{fast}"], color=S2, lw=2, label=fa(f"میانگین {fast} روزه"), zorder=4)
    ax.plot(x, d[f"ma{slow}"], color=S3, lw=2, label=fa(f"میانگین {slow} روزه"), zorder=4)

    if events:
        keep = set(d["date_j"])
        for e in events:
            if e["date_j"] not in keep:
                continue
            i = list(d["date_j"]).index(e["date_j"])
            col = "#0ca30c" if e["kind"] == "طلایی" else "#d03b3b"
            ax.scatter([i], [e["fast"]], s=52, color=col, zorder=6,
                       edgecolor=SURFACE, linewidth=2)

    last = len(d) - 1
    _label_end(ax, last, d["value"].iloc[-1], name, S1)
    _label_end(ax, last, d[f"ma{fast}"].iloc[-1], f"MA{fast}", S2)
    _label_end(ax, last, d[f"ma{slow}"].iloc[-1], f"MA{slow}", S3)

    from analyze import breaking_gaps
    for i, is_gap in enumerate(breaking_gaps(d).values):
        if is_gap:
            ax.axvline(i - 0.5, color=AXIS, lw=1, ls=(0, (3, 3)), zorder=1)
            ax.annotate(fa("گسست داده"), xy=(i - 0.5, 0.02), xycoords=("data", "axes fraction"),
                        rotation=90, fontsize=7, color=MUTED, ha="right", va="bottom")

    ax.set_title(fa(f"{name} و برخورد میانگین‌های متحرک"), fontsize=12, pad=12, loc="left")
    ax.set_ylabel(fa(unit), fontsize=9)
    ax.yaxis.set_major_formatter(FuncFormatter(_thousands))
    ax.grid(axis="x", visible=False)
    _jalali_ticks(ax, d.index)
    ax.margins(x=0.10)
    leg = ax.legend(loc="upper left", frameon=False, fontsize=9)
    for t in leg.get_texts():
        t.set_color(INK_2)

    path = path or CHART_DIR / f"{key}.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


def diverging_bars(df, key, tail=180, path=None):
    """سری دوعلامته (ورود/خروج پول) — میله‌های واگرا حول صفر + میانگین کوتاه."""
    name, unit, _ = SERIES[key]
    fast, _slow = MA_PAIRS.get(key, (7, 21))
    d = df.tail(tail)
    if d.empty:
        return None
    x = list(range(len(d)))
    colors = [POS if v >= 0 else NEG for v in d["value"]]

    fig, ax = plt.subplots(figsize=(9, 4.2))
    ax.bar(x, d["value"], color=colors, width=0.8, zorder=3)
    ax.axhline(0, color=AXIS, lw=1, zorder=4)
    if f"ma{fast}" in d:
        ax.plot(x, d[f"ma{fast}"], color=S2, lw=2, zorder=5,
                label=fa(f"میانگین {fast} روزه"))
        _label_end(ax, len(d) - 1, d[f"ma{fast}"].iloc[-1], f"MA{fast}", S2)

    from matplotlib.patches import Patch
    handles = [Patch(color=POS, label=fa("ورود پول")),
               Patch(color=NEG, label=fa("خروج پول"))]
    if f"ma{fast}" in d:
        handles.append(plt.Line2D([], [], color=S2, lw=2, label=fa(f"میانگین {fast} روزه")))
    leg = ax.legend(handles=handles, loc="upper left", frameon=False, fontsize=9, ncol=3)
    for t in leg.get_texts():
        t.set_color(INK_2)

    ax.set_title(fa(f"{name} — {len(d)} روز معاملاتی اخیر"), fontsize=12, pad=12, loc="left")
    ax.set_ylabel(fa(unit), fontsize=9)
    ax.yaxis.set_major_formatter(FuncFormatter(_thousands))
    ax.grid(axis="x", visible=False)
    _jalali_ticks(ax, d.index)

    path = path or CHART_DIR / f"{key}.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


def build_all(con, tail_index=400, tail_flow=180):
    """همهٔ نمودارها را می‌سازد و مسیرشان را برمی‌گرداند."""
    from analyze import analyse_series
    made = []
    for key in MA_PAIRS:
        df, events = analyse_series(con, key)
        if df is None or df.empty:
            continue
        if SERIES[key][2]:                       # سری دوعلامته
            p = diverging_bars(df, key, tail=tail_flow)
        else:
            p = line_with_ma(df, key, events, tail=tail_index)
        if p:
            made.append(p)
    return made
