@echo off
REM ===================================================================
REM  One-time setup: check Python, install the libraries.
REM ===================================================================
setlocal
cd /d "%~dp0"

where python >nul 2>nul && (set "PY=python") || (set "PY=py")

%PY% --version >nul 2>nul
if errorlevel 1 (
  echo.
  echo [X] Python not found.
  echo     Install it from https://www.python.org/downloads/
  echo     IMPORTANT: tick "Add python.exe to PATH" on the first screen.
  echo     Then run this file again.
  echo.
  pause & exit /b 1
)

echo Python found:
%PY% --version
echo.
echo Installing libraries...
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo [X] Install failed - check the error above.
  echo.
  pause & exit /b 1
)

echo.
echo Checking the database...
%PY% -c "from store import connect; c=connect(); print('rows:', c.execute('select count(*) from observations').fetchone()[0])"

echo.
echo Setup done. Next:
echo   1) setx TELEGRAM_BOT_TOKEN "your-token-from-BotFather"
echo   2) close this window, open a new one, run run_bot.bat
echo   3) in Telegram, send /start to your bot  (this registers you as owner)
echo   4) each day after forwarding posts, run update.bat
echo.
pause
