#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ساخت صفحهٔ نمودار از روی دیتابیس — دو حالت:

    python3 make_chart.py            charts/chart.html   (داده داخل خود صفحه)
    python3 make_chart.py --web      web/index.html + web/data.json
    python3 make_chart.py --open     همان حالت اول، و بازکردنش در مرورگر

حالت --web برای وقتی است که صفحه را روی اینترنت می‌گذارید: صفحه یک بار آپلود
می‌شود و از آن به بعد هر روز فقط data.json عوض می‌شود.
"""
import json
import sys
import webbrowser
from pathlib import Path

import datetime

import jdatetime

from config import (BASE, CHART_DIR, SERIES, MARKET_CLOSED,
                    INDUSTRIES, IND_METRICS)
from store import connect, get_setting

WEB_DIR = BASE / "web"
IND_DIR = "ind"


def ind_metrics():
    """فهرست سری‌های صنعت، به همان شکلی که صفحه می‌خواهد."""
    return [{"k": k, "n": n, "u": u, "signed": s, "dec": d}
            for k, (n, u, s, d) in IND_METRICS.items()]


def write_industries(con, ds):
    """
    `web/ind/<کد>.json` — یک فایل به ازای هر صنعت، و فهرستشان برمی‌گردد.

    چرا جدا و نه داخل data.json: بیست صنعت × سیزده سری = ۲۶۰ سری. اگر
    همه را به data.json می‌ریختیم، فایل چند مگابایت می‌شد و هر بازکردن
    صفحه — حتی برای دیدن شاخص کل — همه‌اش را می‌کشید. این‌طور، تب صنایع
    تا کلیک‌نشدن هیچ بایتی نمی‌گیرد و بعدش هم فقط همان یک صنعت را.

    قالب هر فایل تُنُک است: `i` فهرست *شمارهٔ ردیف* روی محور اصلی است و
    بعد هر سری به همان طول. صنعتی که ۲۵۰ روز داده دارد، ۲۵۰ عدد می‌دهد
    نه ۸٬۰۴۷ عدد که بیشترش تهی باشد.
    """
    pos = {d: i for i, d in enumerate(ds)}
    out = WEB_DIR / IND_DIR
    out.mkdir(parents=True, exist_ok=True)
    index = []
    # کدام صنعت زیرتب می‌گیرد؟ آن که داده دارد — نه آن که در config است.
    # ترتیبشان هم به ارزش معاملات، پس بزرگ‌ها اول نوار می‌نشینند و لازم
    # نیست کسی فهرست را دستی مرتب کند. اکسل صنعت تازه که وارد شود، خودش
    # سر جای درستش ظاهر می‌شود.
    #
    # ⚠ مرتب‌سازی به ارزش معاملات است، ولی عضویت در فهرست نه: صنعتی که
    #   فقط P/E و شاخص گروه دارد (از bourse-trader) ارزش معاملات ندارد و
    #   اگر فهرست را از همان کوئری می‌ساختیم بی‌صدا می‌افتاد بیرون. پس
    #   اول رتبه‌بندی، بعد هر چه داده دارد و در رتبه‌بندی نبود، ته فهرست.
    ranked = [r[0] for r in con.execute(
        "SELECT ind, SUM(value) s FROM industry_obs WHERE metric='value' "
        "GROUP BY ind ORDER BY s DESC")]
    rest = [r[0] for r in con.execute(
        "SELECT ind, COUNT(*) n FROM industry_obs GROUP BY ind ORDER BY n DESC")
        if r[0] not in ranked]
    ranked += rest
    for code in ranked:
        name = INDUSTRIES.get(code, f"صنعت {code}")
        by = {}
        for d, m, v in con.execute(
                "SELECT date_j, metric, value FROM industry_obs WHERE ind=?",
                (code,)):
            if d in pos and m in IND_METRICS:
                by.setdefault(d, {})[m] = v
        if not by:
            continue
        days = sorted(by)
        payload = {"c": code, "n": name, "i": [pos[d] for d in days]}
        for m in IND_METRICS:
            col = [round(by[d][m], 4) if m in by[d] else None for d in days]
            if any(v is not None for v in col):
                payload[m] = col
        (out / f"{code}.json").write_text(
            json.dumps(payload, separators=(",", ":"), ensure_ascii=False),
            encoding="utf-8")
        index.append({"c": code, "n": name, "d": len(days),
                      "f": days[0], "l": days[-1]})
    return index


def gate_into(html, con):
    """
    هش کد ورود را در قالب می‌نشاند. کد تنظیم‌نشده یعنی کادر اصلاً
    نشان داده نمی‌شود و صفحه مثل قبل باز می‌شود.

    ⚠ این یک «در» است نه قفل: data.json کنار صفحه عمومی می‌ماند و هر کسی
      آدرسش را مستقیم باز کند بدون کد همه‌چیز را دارد. خودِ کد در سورس
      صفحه نیست (فقط هشش)، ولی داده هست. با `/code` در تلگرام تنظیم می‌شود.
    """
    return html.replace("__GATE__", get_setting(con, "page_code_hash", "") or "")
KEYS = ["index_total", "index_ew", "value_retail", "flow_retail",
        "flow_fixed", "value_fixed", "flow_lev", "value_lev",
        "flow_goldfund", "value_goldfund", "sarane_buy", "sarane_sell",
        "mv", "mv_tse", "mv_ifb", "mv_usd", "usd_rate", "gold18", "mv_gold",
        "m2", "ratio", "pe_market"]
ALIAS = {"pe_market": "pe"}
# محور افقی بر مبنای «روز معاملاتی بورس» است. طلا شنبه تا چهارشنبه نیست و
# روزهایی هم معامله می‌شود که بورس بسته است؛ اگر آن روزها هم ردیف بگیرند،
# محور کش می‌آید و همهٔ نمودارها یک نوار خالی وسطشان پیدا می‌کنند. پس ردیف‌ها
# را سری‌های بورسی تعیین می‌کنند و طلا روی همان روزها نمونه‌برداری می‌شود.
# نقدینگی هم ردیف نمی‌سازد: ماهانه است و نقاط لنگرش لزوماً روز معاملاتی
# نیستند. روی روزهای معاملاتی درون‌یابی می‌شود و همان‌جا دیده می‌شود.
# P/E هم همین‌طور: منبعش (مفید) تقویم خودش را دارد و حتی روزهایی که بورس
# بسته بوده عدد می‌دهد — در تعطیلی ۱۴۰۴/۱۲ تا ۱۴۰۵/۰۲ چهل‌وهفت روز. آن‌ها
# ردیف جعلی می‌ساختند.
AXIS_EXCLUDE = {"gold18", "m2", "pe_market"}

# ستون فقراتِ محور: روزی که شاخص کل ندارد روز معاملاتی نبوده.
# تاریخچهٔ شاخص کل از ۱۳۷۱/۱۲/۱۵ کامل است و فقط روزهای معاملاتی را دارد،
# پس خودش بهترین تقویم بازار است. بعضی سری‌ها تقویم خودشان را دارند و
# روزهای تعطیل هم عدد می‌دهند — «ارزش دلاری بازار» ۶۰۹ جمعه در خودش دارد
# (بازار ارز جمعه هم کار می‌کند) و ارزش بازار روی ۱۵۱ تعطیل رسمیِ میان‌هفته
# رقم روز قبل را حمل کرده. آن ۷۶۰ ردیف، نوارهای خالیِ وسط همهٔ نمودارها
# بودند.
AXIS_ANCHOR = "index_total"


def closed_days():
    """مجموعهٔ تاریخ‌هایی که بازار تعطیل بوده — از روی بازه‌های config."""
    out = set()
    for lo, hi in MARKET_CLOSED:
        d = jdatetime.date(int(lo[:4]), int(lo[4:6]), int(lo[6:]))
        end = jdatetime.date(int(hi[:4]), int(hi[4:6]), int(hi[6:]))
        while d <= end:
            out.add(d.strftime("%Y%m%d"))
            d += datetime.timedelta(days=1)
    return out


def build_payload(con):
    series, dates = {}, set()
    for k in KEYS:
        rows = dict(con.execute(
            "SELECT date_j, value FROM observations WHERE series=? ORDER BY date_j", (k,)))
        series[k] = rows
        if k not in AXIS_EXCLUDE:
            dates |= rows.keys()

    # تعطیلی طولانی بازار: هر منبعی که در این بازه عدد بدهد ردیف نمی‌سازد.
    # این یک گاردِ صریح است، نه فقط برای P/E — هر منبع تازه‌ای هم که فردا
    # اضافه شود و تقویم خودش را داشته باشد، اینجا گرفته می‌شود.
    dates -= closed_days()

    # فیلتر لنگر فقط *درون* بازهٔ خود شاخص اعمال می‌شود. بعد از آخرین روزی
    # که شاخص داریم دست نمی‌زند: ارزش بازار و دلار معمولاً چند ساعت زودتر از
    # شاخص می‌رسند و اگر این شرط نبود، داده‌های امروز تا رسیدن شاخص ناپدید
    # می‌شدند.
    anchor = series.get(AXIS_ANCHOR) or {}
    if anchor:
        lo, hi = min(anchor), max(anchor)
        dates = {d for d in dates if d in anchor or not (lo <= d <= hi)}

    ds = sorted(dates)
    out = {"d": ds, "t": []}
    for j in ds:
        g = jdatetime.date(int(j[:4]), int(j[4:6]), int(j[6:])).togregorian()
        out["t"].append(int(g.strftime("%Y%m%d")))
    for k in KEYS:
        out[ALIAS.get(k, k)] = [
            (round(series[k][j], 4) if j in series[k] else None) for j in ds]
    return out


def fresh_templates(log=print):
    """
    اگر app.js یا head.html از قالب‌ها تازه‌تر باشد، قالب‌ها را دوباره می‌سازد.

    قالب‌ها خروجی ساخت‌اند، نه منبع: `charts/build_templates.py` آن‌ها را
    از head.html + app.js می‌سازد. قبلاً این دستور دستی بود و یک بار
    فراموش شد — چهار سری تازه (اهرمی و طلا) در data.json بودند ولی صفحه
    فهرست سری‌های قدیمی را داشت، پس نه چیپ گرفتند و نه ستون جدول. چیزی
    هم خطا نمی‌داد. حالا خودکار است و آن اشتباه دیگر ممکن نیست.
    """
    srcs = [CHART_DIR / "app.js", CHART_DIR / "head.html"]
    outs = [CHART_DIR / "template.html", CHART_DIR / "template_web.html"]
    if not all(s.exists() for s in srcs):
        return False
    newest = max(s.stat().st_mtime for s in srcs)
    if all(o.exists() and o.stat().st_mtime >= newest for o in outs):
        return False
    log("app.js تازه‌تر از قالب‌هاست — قالب‌ها دوباره ساخته می‌شوند…")
    import runpy
    runpy.run_path(str(CHART_DIR / "build_templates.py"), run_name="__main__")
    return True


def main():
    web = "--web" in sys.argv
    fresh_templates()
    tpl = CHART_DIR / ("template_web.html" if web else "template.html")
    if not tpl.exists():
        sys.exit(f"قالب پیدا نشد: {tpl} — charts/build_templates.py را بزنید")

    con = connect()

    # مهاجرت‌ها قبل از ساختن صفحه اجرا می‌شوند.
    #
    # چرا این‌جا و نه فقط موقع بالا آمدن ربات: `update.bat` مستقیم همین
    # فایل را صدا می‌زند و هیچ‌وقت از مسیر ربات یا publish رد نمی‌شود. تا
    # پیش از این، هر داده‌ای که فقط از مهاجرت می‌آمد — مثل کل جدول صنایع
    # و نقدینگی اکسلی — روی کامپیوتری که فقط `update.bat` می‌زند هرگز
    # وارد نمی‌شد و صفحه بی‌صدا خالی ساخته می‌شد.
    #
    # اجرای دوباره‌اش بی‌ضرر است: هر مهاجرت اول نگاه می‌کند کاری مانده یا
    # نه و اگر نمانده ساکت برمی‌گردد.
    try:
        import migrate
        migrate.run_all(con)
    except Exception as e:                      # noqa: BLE001
        print(f"⚠ مهاجرت‌ها کامل اجرا نشدند: {e}")

    payload = build_payload(con)

    # تب صنایع فقط در حالت وب کار می‌کند: دادهٔ هر صنعت فایل جداگانه‌ای
    # است که با fetch می‌آید، و صفحهٔ تک‌فایلیِ محلی (file://) نمی‌تواند
    # کنارِ خودش فایل بخواند. در حالت محلی فهرست خالی می‌رود و خود صفحه
    # تب را نشان نمی‌دهد.
    ind_index = []
    if web:
        WEB_DIR.mkdir(exist_ok=True)
        ind_index = write_industries(con, payload["d"])
    payload["ind"] = {"dir": IND_DIR if web else None,
                      "codes": ind_index, "metrics": ind_metrics()}
    con.close()
    blob = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)

    if web:
        con2 = connect()
        page = gate_into(tpl.read_text(encoding="utf-8"), con2)
        con2.close()
        (WEB_DIR / "index.html").write_text(page, encoding="utf-8")
        (WEB_DIR / "data.json").write_text(blob, encoding="utf-8")
        out = WEB_DIR / "index.html"
        print(f"{WEB_DIR}/index.html  +  data.json ({len(blob):,} بایت)")
    else:
        out = CHART_DIR / "chart.html"
        out.write_text(tpl.read_text(encoding="utf-8").replace("__DATA__", blob),
                       encoding="utf-8")
        print(f"{out}  ({len(blob):,} بایت داده)")

    print(f"{len(payload['d'])} روز — {payload['d'][0]} تا {payload['d'][-1]}")
    for k in KEYS:
        a = payload[ALIAS.get(k, k)]
        print(f"  {SERIES.get(k, (k,))[0]}: {sum(1 for v in a if v is not None)}")

    if payload["ind"]["codes"]:
        tot = sum(c["d"] for c in payload["ind"]["codes"])
        print(f"\nصنایع: {len(payload['ind']['codes'])} صنعت، {tot} روز-صنعت")
        for c in payload["ind"]["codes"][:6]:
            print(f"  {c['n']}: {c['d']} روز ({c['f']} تا {c['l']})")
        if len(payload["ind"]["codes"]) > 6:
            print(f"  … و {len(payload['ind']['codes']) - 6} صنعت دیگر")
    elif web:
        print("\nصنایع: جدول صنایع خالی است — یک بار /fetch بزنید.")

    if "--open" in sys.argv and not web:
        webbrowser.open(out.resolve().as_uri())


if __name__ == "__main__":
    main()
