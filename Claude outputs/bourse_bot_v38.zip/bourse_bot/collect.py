# -*- coding: utf-8 -*-
"""
جمع‌آوری خودکار روزانه — جایگزین فوروارد دستی.

    python3 collect.py              یک بار اجرا و گزارش
    python3 collect.py --quiet      فقط خلاصه

ترتیب عمدی است:

 ۱. تریدرزآرنا اول — چون ۱۰ روز تاریخچه می‌دهد، هم روزهای جامانده را پر
    می‌کند و هم معلوم می‌کند کدام روزها اصلاً روز معاملاتی بوده‌اند.
 ۲. چارتیکس فقط برای روزِ معاملاتی. عددش «آخرین قیمت» است نه «پایانی»؛
    روز تعطیل همان عدد دیروز را نشان می‌دهد و اگر گارد نداشته باشیم یک
    پلهٔ جعلی در نمودار می‌سازد.
 ۳. نسخهٔ وب کانال پارسیس — سرانه‌ها و جریان پول با تعریف تاریخی خودمان.
 ۴. سری‌های مشتق (ارزش کل، نسبت، بازار به طلا، ارزش دلاری) و بازسازی
    نقدینگی از روی مدل ماهانه.

هیچ منبعی «حیاتی» نیست: اگر یکی بالا نیاید بقیه کارشان را می‌کنند و
دلیلش در گزارش می‌آید.
"""
import sys

from store import connect, upsert, upsert_ind, derive_totals


def run(con=None, log=print, pages=1, dry=False):
    """
    خروجی: (خلاصهٔ فارسی، تعداد ردیف تازه)

    dry=True یعنی هیچ‌چیز نوشته نمی‌شود — فقط گزارش می‌دهد چه چیزی اضافه
    و چه چیزی *بازنویسی* می‌شد. برای اولین اجرا، که می‌خواهید مطمئن شوید
    دادهٔ دستی‌تان دست نمی‌خورد.
    """
    from sources import (tradersarena, chartix_live, parsis_web,
                         ta_home, ta_industries)
    import m2

    own = con is None
    con = con or connect()
    lines, notes, touched = [], [], set()
    written, overwrites = {}, []

    def absorb(rows, source):
        n = 0
        for date_j, series, value, ref in rows:
            old = con.execute(
                "SELECT value, source FROM observations WHERE date_j=? AND series=?",
                (date_j, series)).fetchone() if dry else None
            res = upsert(con, date_j, series, value, source, ref, dry=dry)
            if res.split(":")[0] in ("inserted", "updated"):
                written[series] = written.get(series, 0) + 1
                touched.add(date_j)
                n += 1
                if dry and res == "updated" and old:
                    overwrites.append(
                        f"{date_j[:4]}/{date_j[4:6]}/{date_j[6:]} · {series}: "
                        f"{old[0]:,.1f} [{old[1]}] ← {value:,.1f} [{source}]")
            elif res.startswith("rejected"):
                notes.append(f"رد شد — {date_j} {series}: {res[9:]}")
        return n

    # ۱) تریدرزآرنا
    ta_rows, ta_notes = tradersarena.fetch()
    notes += ta_notes
    n = absorb(ta_rows, "tradersarena")
    lines.append(f"تریدرزآرنا: {len(ta_rows)} مقدار خوانده شد، {n} تازه")
    trading = tradersarena.trading_days(ta_rows)

    # ۱-ب) صفحهٔ اول تریدرزآرنا — صندوق‌های اهرمی و طلا. تنها جایی که این
    #      دو رایگان و روزانه پیدا می‌شوند. فقط *یک* روز می‌دهد (همان روزی
    #      که خودِ صفحه در `id="time"` نوشته)، پس اگر کامپیوتر چند روز
    #      خاموش بماند جاافتادگی‌اش را جبران نمی‌کند — تاریخچه از اکسل
    #      اشتراک می‌آید. عددهایش هم رُند است و اکسل بعداً دقیقشان می‌کند.
    ta_day, th_rows, th_notes = ta_home.fetch_day()
    notes += th_notes
    n = absorb(th_rows, "tradersarena")
    lines.append(f"صفحهٔ اول تریدرزآرنا: {len(th_rows)} مقدار خوانده شد، {n} تازه")

    # ۱-ج) دیده‌بان صنایع — همان منبع، همان روز. تاریخ از پاسخ بالا می‌آید،
    #      نه از ساعت کامپیوتر (API صنایع خودش تاریخ ندارد).
    # هر چه در config اسم دارد — چهل‌وهشت صنعت و سیزده سبد صندوق. یک
    # درخواست همه را می‌دهد. کدام‌شان روی صفحه زیرتب بگیرد را داشتنِ
    # داده تعیین می‌کند، نه این‌جا.
    from config import INDUSTRIES
    ind_rows, ind_notes = ta_industries.fetch(ta_day, keep=set(INDUSTRIES))
    notes += ind_notes
    ni = 0
    for date_j, ind, metric, value, ref in ind_rows:
        res = upsert_ind(con, date_j, ind, metric, value, "tradersarena", ref, dry=dry)
        if res in ("inserted", "updated"):
            ni += 1
    if not dry:
        con.commit()
    inds = len({r[1] for r in ind_rows})
    lines.append(f"صنایع: {inds} صنعت × {len(ta_industries.COLUMNS)} سری "
                 f"خوانده شد، {ni} مقدار تازه")

    # ۱-د) صفحهٔ سوابق هر صنعت — ده روز آخر. «شاخص گروه» فقط از این‌جا
    #      می‌آید، و چون ده روز می‌دهد چند روز خاموشیِ کامپیوتر را هم
    #      جبران می‌کند. گران‌ترین قدمِ برداشت است (۴۸ درخواست)، پس با
    #      IND_BACKFILL در config خاموش می‌شود.
    from config import IND_BACKFILL
    if IND_BACKFILL:
        import backfill_industries
        nb, span = backfill_industries.run(dry=dry, log=lambda *a: None, con=con)
        lines.append(f"سوابق صنایع: {nb} مقدار تازه ({span})")

    # ۲) چارتیکس — فقط اگر امروز روز معاملاتی بوده
    from sources.common import today_j
    today = today_j()
    cx_rows, cx_notes = chartix_live.fetch(trading=(today in trading) or not ta_rows)
    notes += cx_notes
    n = absorb(cx_rows, "chartix_live")
    lines.append(f"چارتیکس: {len(cx_rows)} مقدار خوانده شد، {n} تازه")

    # ۳) کانال پارسیس از نسخهٔ وب
    pw_rows, pw_notes = parsis_web.fetch(pages=pages)
    notes += pw_notes
    n = absorb(pw_rows, "parsistahlil")
    lines.append(f"پارسیس (وب): {len(pw_rows)} مقدار خوانده شد، {n} تازه")

    # ۴) مشتق‌ها و نقدینگی
    if not dry:
        if touched:
            derive_totals(con, touched)
        mn, ma, mb, merr = m2.rebuild(con)
        if merr:
            notes.append("نقدینگی: " + merr)
        elif mn:
            lines.append(f"نقدینگی: {mn} روز بازسازی شد ({ma} تا {mb})")

    total = sum(written.values())
    if written:
        lines.append("")
        lines.append("سری‌های به‌روزشده: " +
                     "، ".join(f"{k}×{v}" for k, v in sorted(written.items())))
    if not total:
        lines.append("چیز تازه‌ای نبود — همه‌چیز از قبل در دیتابیس هست.")

    if dry:
        lines.insert(0, "🔍 <b>آزمایشی — چیزی نوشته نشد</b>\n")
        lines.append("")
        if overwrites:
            lines.append(f"<b>{len(overwrites)} مقدار بازنویسی می‌شد:</b>")
            lines += ["  " + o for o in overwrites[:25]]
            if len(overwrites) > 25:
                lines.append(f"  … و {len(overwrites) - 25} مورد دیگر")
        else:
            lines.append("✅ <b>هیچ مقدار موجودی بازنویسی نمی‌شد</b> — "
                         "هرچه هست اضافه است، نه جایگزین.")
        lines.append("\nبرای اجرای واقعی: /fetch")

    if notes:
        lines.append("")
        lines.append("⚠ " + "\n⚠ ".join(notes[:8]))

    if own:
        con.close()
    return "\n".join(lines), total


if __name__ == "__main__":
    text, n = run(pages=2 if "--deep" in sys.argv else 1)
    print(text)
    sys.exit(0 if n or "--quiet" in sys.argv else 0)
