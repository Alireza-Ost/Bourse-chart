#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تست منابع خودکار، بدون اینترنت.

    python3 tests/run.py

صفحه‌های واقعیِ ۱۴۰۵/۰۷/۱۲ در پوشهٔ fixtures ذخیره شده‌اند. اگر روزی
یکی از سایت‌ها ساختارش را عوض کرد و برداشت خراب شد، اول این را بزنید:
اگر اینجا سبز است یعنی پارسر سالم است و مشکل جای دیگری است (شبکه،
فیلترینگ، تغییر آدرس). اگر اینجا هم قرمز شد یعنی واقعاً صفحه عوض شده.
"""
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))

FIX = HERE / "fixtures"

ok = fail = 0


def check(label, got, want, tol=0.0):
    global ok, fail
    good = (abs(got - want) <= tol) if isinstance(want, float) else (got == want)
    show = f"{got:,}" if isinstance(got, (int, float)) and not isinstance(got, bool) else repr(got)
    extra = "" if good else f"   (انتظار {want!r})"
    print(("  ✅ " if good else "  ❌ ") + f"{label}: {show}" + extra)
    ok, fail = ok + good, fail + (not good)


def main():
    import sources.common as common
    from sources import tradersarena, chartix_live, parsis_web

    print("تریدرزآرنا — جدول سوابق")
    rows, notes = tradersarena.parse((FIX / "ta_history.html").read_text(encoding="utf-8"))
    d = {(a, b): c for a, b, c, _ in rows}
    check("ارزش معاملات خرد ۱۴۰۵/۰۷/۱۲", d[("14050712", "value_retail")], 51319.8, 0.05)
    check("ورود پول ۱۴۰۵/۰۷/۱۲", d[("14050712", "flow_retail")], -846.4, 0.05)
    check("شاخص کل ۱۴۰۵/۰۷/۱۱", d[("14050711", "index_total")], 7808068.0, 0.5)
    check("شاخص هم‌وزن ۱۴۰۵/۰۷/۱۱", d[("14050711", "index_ew")], 2068720.0, 0.5)
    check("ردیف امروز بدون شاخص رد نشده", ("14050712", "index_total") not in d, True)
    if notes:
        print("  ⚠", "؛ ".join(notes))

    print("\nچارتیکس — قیمت از خود صفحه")
    H = chartix_live.RIAL_PER_HEMAT
    v, u = chartix_live.price_of((FIX / "chartix_page.html").read_text(encoding="utf-8"))
    check("ارزش بورس (همت)", round(v / H, 1), 22536.2, 0.05)
    v, u = chartix_live.price_of((FIX / "chartix_ifb.html").read_text(encoding="utf-8"))
    check("ارزش فرابورس (همت)", round(v / H, 1), 3314.4, 0.05)
    g, _ = chartix_live.price_of((FIX / "chartix_gold.html").read_text(encoding="utf-8"))
    check("طلای ۱۸ (تومان بر گرم)", g, 26395500.0, 0.5)
    a, _ = chartix_live.price_of((FIX / "chartix_all_irr.html").read_text(encoding="utf-8"))
    b, _ = chartix_live.price_of((FIX / "chartix_all_usd.html").read_text(encoding="utf-8"))
    check("نرخ دلار (تومان)", round(a / b / 10), 267500)

    print("\nپارسیس — نسخهٔ وب کانال")
    rows, notes = parsis_web.parse((FIX / "parsis_web.html").read_text(encoding="utf-8"))
    d = {(x, y): z for x, y, z, _ in rows}
    check("ارزش معاملات خرد", d[("14050712", "value_retail")], 51314.0, 0.5)
    check("خروج پول حقیقی", d[("14050712", "flow_retail")], -1131.0, 0.5)
    check("سهم حقیقی از خرید", d[("14050712", "buy_share")], 74.0, 0.05)
    # سرانه عمداً از پارسیس نوشته نمی‌شود — تعریفش با تریدرزآرنا یکی نیست
    check("پارسیس سرانه نمی‌نویسد",
          not any(s.startswith("sarane") for _, s, _, _ in rows), True)

    print("\nصندوق درآمد ثابت — از تفاضل دو جدول تریدرزآرنا")
    import pathlib as _p
    import sources.tradersarena as _ta
    _fix = {"type=1": FIX / "ta_history.html", "type=0": FIX / "ta_history_all.html"}
    _real = _ta.get
    _ta.get = lambda u, s=None: _p.Path(
        next(v for k, v in _fix.items() if k in u)).read_text(encoding="utf-8")
    try:
        trows, _ = _ta.fetch()
    finally:
        _ta.get = _real
    td = {(a, b): c for a, b, c, _ in trows}
    check("ورود پول به درآمد ثابت", td[("14050712", "flow_fixed")], 3926.8, 0.05)
    check("معاملات درآمد ثابت", td[("14050712", "value_fixed")], 48165.3, 0.05)
    check("سرانه خرید (تریدرزآرنا)", td[("14050712", "sarane_buy")], 86.5, 0.05)
    check("سرانه فروش (تریدرزآرنا)", td[("14050712", "sarane_sell")], 117.9, 0.05)

    print("\nخروجی اکسل تریدرزآرنا — واحد و «فقط جای خالی»")
    import import_tradersarena as ita
    ex = ita.extract(FIX / "ta_export.csv", log=lambda *a: None)
    r = ex["14050722"]
    # ستون‌های فایل تومان‌اند؛ دیتابیس میلیارد تومان (ارزش/جریان) و
    # میلیون تومان (سرانه) می‌خواهد. اگر مقسوم‌علیه بیفتد، ارزش معاملات
    # می‌شود ۵۳ هزار میلیارد و نمودار به آسمان می‌رود.
    check("ارزش معاملات (میلیارد تومان)", round(r["value_retail"], 1), 53482.0, 0.05)
    check("ورود پول (میلیارد تومان)", round(r["flow_retail"], 1), -402.6, 0.05)
    check("سرانه خرید (میلیون تومان)", round(r["sarane_buy"], 2), 89.07, 0.005)
    check("شاخص کل بدون تقسیم", r["index_total"], 8425725.0, 0.5)
    check("شاخص هم‌وزن (عنوان با فاصلهٔ آخر)", r["index_ew"], 2225797.0, 0.5)
    # ستون «میانگین ارزش معاملات ۵ روزه» نباید به ارزش معاملات بخورد
    check("ستون‌های ۵ روزه نادیده گرفته شدند",
          abs(r["value_retail"] - 54327.9) > 1, True)

    import sqlite3
    from store import SCHEMA, upsert
    con = sqlite3.connect(":memory:")
    con.executescript(SCHEMA)
    con.execute("INSERT INTO observations VALUES "
                "('14050722','value_retail',99999,'xlsx_seed','','')")
    con.commit()
    have = {d for d, in con.execute(
        "SELECT date_j FROM observations WHERE series='value_retail'")}
    for d in sorted(ex):
        if d in have:                      # همان قاعدهٔ migrate: جای پر دست نمی‌خورد
            continue
        upsert(con, d, "value_retail", ex[d]["value_retail"], "tradersarena", "")
    got = dict(con.execute("SELECT date_j, value FROM observations WHERE series='value_retail'"))
    check("روز موجود دست‌نخورده ماند", got["14050722"], 99999.0)
    check("روز خالی پر شد", round(got["14050721"], 1), 48882.1, 0.05)

    # خروجی اختصاصی صندوق‌ها ستون‌هایش هم‌نام جدول اصلی است ولی معنایش
    # صندوق است. اگر نگاشت عوض نشود، ارزش معاملات صندوق روی ارزش معاملات
    # خرد می‌نشیند و سرانهٔ صندوق جای سرانهٔ حقیقیِ کل بازار را می‌گیرد.
    fx = {d: {ita.AS_FIXED[k]: v for k, v in vals.items() if k in ita.AS_FIXED}
          for d, vals in ex.items()}
    check("ارزش معاملات → ارزش صندوق", round(fx["14050722"]["value_fixed"], 1), 53482.0, 0.05)
    check("ورود پول → ورود پول صندوق", round(fx["14050722"]["flow_fixed"], 1), -402.6, 0.05)
    check("سرانهٔ صندوق سری نمی‌سازد",
          [k for k in fx["14050722"] if k.startswith("sarane")], [])
    check("شاخص از فایل صندوق نوشته نمی‌شود", "index_total" in fx["14050722"], False)

    print("\nAPI صفحهٔ اول تریدرزآرنا — صندوق اهرمی و طلا")
    from sources import ta_home
    th_rows, th_notes = ta_home.parse(
        (FIX / "ta_home_market0.json").read_text(encoding="utf-8"))
    th = {(a, b): c for a, b, c, _ in th_rows}
    check("تاریخ از خودِ پاسخ خوانده شد", {a for a, _ in th}, {"14050722"})
    # ارقام ریالی‌اند: ÷۱۰^۱۰ می‌شود میلیارد تومان. اگر مقسوم‌علیه بیفتد،
    # ارزش معاملات اهرمی می‌شود ۴۸ هزار میلیارد و نمودار به آسمان می‌رود.
    check("ارزش معاملات اهرمی (میلیارد تومان)",
          round(th[("14050722", "value_lev")], 2), 4873.23, 0.005)
    check("ورود پول اهرمی", round(th[("14050722", "flow_lev")], 2), 117.66, 0.005)
    check("ارزش معاملات صندوق طلا",
          round(th[("14050722", "value_goldfund")], 1), 18073.0, 0.05)
    check("ورود پول صندوق طلا",
          round(th[("14050722", "flow_goldfund")], 1), 2145.9, 0.05)
    # سبدهای دیگر در همان پاسخ هستند (afl، nsf) ولی نوشته نمی‌شوند: منبع
    # دقیق‌تری دارند. شاخص هم عمداً نه — عددش «آخرین» است نه پایانی.
    check("سبدهای دیگر نوشته نمی‌شوند",
          sorted({b for _, b in th}),
          ["flow_goldfund", "flow_lev", "value_goldfund", "value_lev"])
    if th_notes:
        print("  ⚠", "؛ ".join(th_notes))

    print("\nدیده‌بان صنایع — API روزانه")
    from sources import ta_industries as tind
    ir, inotes = tind.parse((FIX / "ta_industries.json").read_text(encoding="utf-8"),
                            "14050722", keep={"44", "27", "57", "01"})
    ind = {}
    for d, c, m, v, _ in ir:
        ind.setdefault(c, {})[m] = v
    check("تعداد صنعت خوانده‌شده", sorted(ind), ["01", "27", "44", "57"])
    check("ارزش معاملات بانک‌ها (میلیارد تومان)",
          round(ind["57"]["value"], 1), 5248.4, 0.05)
    check("ورود پول بانک‌ها", round(ind["57"]["flow"], 1), 204.4, 0.05)
    check("سرانه خرید بانک‌ها (میلیون تومان)",
          round(ind["57"]["sarane_buy"], 1), 167.0, 0.05)
    check("قدرت خرید فلزات اساسی", round(ind["27"]["power"], 2), -2.05, 0.005)
    # API هفت ستون از ده ستونِ جدول را دارد؛ حقوقی‌ها و شاخص گروه در آن
    # نیستند و از اکسل و جدول سوابق می‌آیند.
    check("API هفت سری می‌دهد", {len(v) for v in ind.values()}, {7})
    check("حقوقی از API نمی‌آید",
          any(k.endswith("_inst") for v in ind.values() for k in v), False)
    check("هشدار نداشت", inotes, [])

    # ردیفی که یک ستون جابه‌جا شده باید رد شود، نه اینکه عدد غلط بنویسد
    import json as _json
    raw = _json.loads((FIX / "ta_industries.json").read_text(encoding="utf-8"))
    shifted = [r[:3] + r[4:] for r in raw]          # یک ستون به چپ
    sr, snotes = tind.parse(_json.dumps(shifted), "14050722")
    check("ردیف جابه‌جاشده رد شد", sr, [])
    check("و دلیلش گزارش شد", len(snotes) > 0, True)

    # سبدهای صندوق کدشان نامکی است («gold-funds») و پذیرفته می‌شوند —
    # زیرتب خودشان را دارند. ولی فقط اگر در keep باشند: کدِ ناشناخته
    # بی‌سر‌و‌صدا وارد دیتابیس نمی‌شود.
    with_funds = raw + [["gold-funds", "صندوق های طلا"] + [1.0] * 29]
    fr, _ = tind.parse(_json.dumps(with_funds), "14050722",
                       keep={"44", "27", "57", "01", "gold-funds"})
    check("سبد صندوق هم برداشته می‌شود",
          sorted({c for _, c, _, _, _ in fr}),
          ["01", "27", "44", "57", "gold-funds"])
    fr2, _ = tind.parse(_json.dumps(with_funds), "14050722",
                        keep={"44", "27", "57", "01"})
    check("کد بیرون از keep رد می‌شود",
          sorted({c for _, c, _, _, _ in fr2}), ["01", "27", "44", "57"])

    print("\nصنایع — واحدِ سرستون و جدول سوابق")
    import import_industries as ii
    check("واحد داخل پرانتز", ii.split_unit("ارزش معاملات (تومان)"),
          ("ارزش معاملات", "تومان"))
    # تلهٔ هزاربرابر: اگر «میلیارد تومان» به «تومان» بخورد، عدد ۱۰^۹ برابر
    # غلط می‌شود. ترتیب بلند-به-کوتاه در UNITS همین را می‌گیرد.
    check("واحد بی‌پرانتز", ii.split_unit("ارزش معاملاتمیلیارد تومان"),
          ("ارزش معاملات", "میلیارد تومان"))
    check("بی‌واحد", ii.split_unit("قدرت خرید"), ("قدرت خرید", ""))
    check("تومان ÷ ۱۰^۹", ii.divisor("value", "تومان"), 1e9)
    check("میلیارد تومان همان‌طور", ii.divisor("value", "میلیارد تومان"), 1.0)
    check("سرانه تومان ÷ ۱۰^۶", ii.divisor("sarane_buy", "تومان"), 1e6)
    check("قدرت خرید بی‌واحد", ii.divisor("power", ""), 1.0)

    import backfill_industries as bi
    hdata, hnotes = bi.parse(
        (FIX / "ta_industry_history.html").read_text(encoding="utf-8"))
    check("دو روز از جدول سوابق", sorted(hdata), ["14050721", "14050722"])
    check("ارزش معاملات از سوابق", round(hdata["14050722"]["value"], 1), 5248.4, 0.05)
    check("ورود پول از سوابق", round(hdata["14050722"]["flow"], 1), 204.4, 0.05)
    check("شاخص گروه از جدول سوابق آمد",
          round(hdata["14050722"]["gindex"], 1), 31452.7, 0.05)
    check("ستون‌های ۵ و ۲۰ روزه کنار گذاشته شدند",
          sorted(hdata["14050722"]),
          ["buy_real", "flow", "gindex", "power", "sarane_buy",
           "sarane_sell", "sell_real", "value"])
    check("سوابق هشدار نداشت", hnotes, [])

    print("\nصنایع — فایل تُنُک هر صنعت")
    import make_chart
    import sqlite3 as _sq3
    from store import SCHEMA as _SC3
    c3 = _sq3.connect(":memory:")
    c3.executescript(_SC3)
    for d, v in (("14050301", 10.0), ("14050304", 12.0)):
        c3.execute("INSERT INTO industry_obs VALUES (?,?,?,?,'t','',' ')",
                   (d, "44", "value", v))
    c3.commit()
    idx = make_chart.write_industries(c3, ["14050301", "14050302", "14050304"])
    check("فهرست یک صنعت دارد", [(x["c"], x["d"]) for x in idx], [("44", 2)])
    import json as _j3
    f3 = make_chart.WEB_DIR / make_chart.IND_DIR / "44.json"
    j3 = _j3.loads(f3.read_text(encoding="utf-8"))
    # ۰ و ۲ یعنی ردیف اول و سومِ محور — ردیف دوم داده ندارد و جا نمی‌گیرد
    check("شمارهٔ ردیف‌ها روی محور", j3["i"], [0, 2])
    check("مقدارها به ترتیب", j3["value"], [10.0, 12.0])
    check("سری بی‌داده ذخیره نشد", "flow" in j3, False)
    f3.unlink()

    print("\nمحور نمودار — تقویم بازار از روی شاخص کل")
    import sqlite3 as _sq
    from store import SCHEMA as _SC
    c2 = _sq.connect(":memory:")
    c2.executescript(_SC)
    rows = [
        ("14050301", "index_total", 100.0),
        ("14050302", "index_total", 101.0),
        ("14050304", "index_total", 102.0),   # ۰۳ تعطیل رسمی بوده
        ("14050303", "mv_usd",       50.0),   # تعطیل، ولی بازار ارز باز
        ("14050302", "mv",          900.0),
        ("14050305", "mv",          910.0),   # فردای آخرین شاخص — باید بماند
        ("14041210", "mv",          800.0),   # درون تعطیلی طولانی بازار
        ("13990101", "gold18",   500000.0),   # طلا ردیف نمی‌سازد
    ]
    for d, s, v in rows:
        c2.execute("INSERT INTO observations VALUES (?,?,?,'test','','')", (d, s, v))
    c2.commit()
    p = make_chart.build_payload(c2)
    check("روز تعطیل رسمی حذف شد", "14050303" in p["d"], False)
    check("روزهای معاملاتی ماندند",
          [d for d in p["d"] if d.startswith("140503")],
          ["14050301", "14050302", "14050304", "14050305"])
    check("روز بعد از آخرین شاخص نمی‌افتد", "14050305" in p["d"], True)
    check("تعطیلی طولانی بازار حذف شد", "14041210" in p["d"], False)
    check("طلا ردیف نساخت", "13990101" in p["d"], False)

    print("\nنقدینگی — مدل ماهانه و اصلاح بازگشتی")
    import m2
    import sqlite3
    con = sqlite3.connect(":memory:")
    from store import SCHEMA
    con.executescript(SCHEMA)
    m2.ensure(con)
    con.execute("INSERT INTO observations VALUES ('14041206','m2',14834.48,'xlsx_seed','','')")
    # روز میانی و روز پایانی هر ماه، تا هم پخش روزانه و هم سطح ماه تست شود
    for day in ("14050115", "14050131", "14050215", "14050231", "14050315",
                "14050331", "14050431", "14050531", "14050615", "14050631"):
        con.execute("INSERT INTO observations VALUES (?,'index_total',1,'test','','')", (day,))
    con.commit()

    def val(d):
        return con.execute("SELECT value FROM observations WHERE series='m2' AND date_j=?",
                           (d,)).fetchone()[0]

    for mo in ("140501", "140502", "140503", "140504", "140505", "140506"):
        m2.set_month(con, mo, "rate", 3.54)
    m2.rebuild(con)

    # پایان شهریور باید دقیقاً ۱۴۸۳۴.۴۸ × ۱.۰۳۵۴^۶ باشد
    check("پایان شهریور با نرخ ۳.۵۴٪ (همت)", round(val("14050631"), 1),
          round(14834.48 * 1.0354 ** 6, 1), 1.0)
    check("پانزدهم شهریور وسط مرداد و شهریور است",
          val("14050531") < val("14050615") < val("14050631"), True)
    before = val("14050631")

    m2.set_month(con, "140502", "level", 16200)      # رقم واقعی بانک مرکزی رسید
    m2.rebuild(con)
    # اردیبهشت قفل می‌شود، چهار ماه بعدش با همان ۳.۵۴٪ از روی آن ادامه می‌یابند
    check("اردیبهشت دقیقاً روی رقم واقعی نشست", round(val("14050231"), 1), 16200.0, 1.0)
    check("پایان شهریور بعد از اصلاح", round(val("14050631"), 1),
          round(16200 * 1.0354 ** 4, 1), 1.0)
    check("اصلاح واقعاً ماه‌های بعدی را جابه‌جا کرد", val("14050631") > before * 1.01, True)
    check("فروردین (قبل از ماهِ اصلاح‌شده) دست‌نخورده ماند",
          round(val("14050131"), 1), round(14834.48 * 1.0354, 1), 1.0)
    src = con.execute("SELECT source FROM observations WHERE series='m2' AND date_j='14050231'"
                      ).fetchone()[0]
    check("منبع اردیبهشت رقم واقعی شد", src, "m2_level")

    # ------------------------------------------------------------------
    # این بخش بعد از یک اشتباه واقعی اضافه شد: چهار سری تازه (اهرمی و طلا)
    # به app.js و به دیتابیس اضافه شدند، data.json هم داشتشان، ولی قالب
    # صفحه از app.js *ساخته* می‌شود و ساختنش یادم رفت. نتیجه: نه چیپ
    # گرفتند و نه ستون جدول، و هیچ خطایی هم نداد. این تست همان را می‌گیرد.
    print("\nقالب صفحه — همگام با app.js")
    import re as _re
    from config import CHART_DIR
    appjs = (CHART_DIR / "app.js").read_text(encoding="utf-8")
    body = appjs.split("const SERIES = [", 1)[1].split("\n];", 1)[0]
    app_keys = _re.findall(r'\{k:"([^"]+)"', body)
    check("app.js فهرست سری دارد", len(app_keys) > 10, True)

    payload_keys = {make_chart.ALIAS.get(k, k) for k in make_chart.KEYS}
    missing = [k for k in app_keys if k not in payload_keys]
    check("هر سری صفحه در داده هم هست", missing, [])

    for name in ("template.html", "template_web.html"):
        tpl = (CHART_DIR / name)
        stale = [k for k in app_keys if f'k:"{k}"' not in tpl.read_text(encoding="utf-8")]
        check(f"{name} کهنه نیست", stale, [])

    # ------------------------------------------------------------------
    # این بخش هم بعد از یک اشتباه واقعی اضافه شد: اکسل‌ها در گفت‌وگو وارد
    # دیتابیسِ من می‌شدند، ولی هیچ فایلی همراه کد نمی‌رفت — پس روی
    # کامپیوتر کاربر هیچ‌کدامشان نبودند و سایت خالی می‌ماند. حالا
    # export_bundle.py فایلشان را می‌سازد و migrate واردشان می‌کند.
    # ------------------------------------------------------------------
    # علامت ورود پول — یک بار خواستم از کلاس `minus` بخوانمش و داده را
    # وارونه کرد. این تست همان قاعده را قفل می‌کند: علامت فقط از متن.
    # ------------------------------------------------------------------
    # چارتیکس آبان ۱۴۰۵ قالب صفحه را عوض کرد و هر پنج نماد ساکت از کار
    # افتادند. این تست هر دو قالب را نگه می‌دارد، و مهم‌تر: مطمئن می‌شود
    # عددِ «نمادهای مرتبط» پایین صفحه با تیتر قیمت اشتباه گرفته نشود.
    print("\nچارتیکس — قالب تازهٔ صفحه")
    from sources import chartix_live as _cx
    _new = (FIX / "chartix_new_layout.html").read_text(encoding="utf-8")
    _v, _u = _cx.price_of(_new)
    check("قیمت از قالب تازه خوانده شد", _v, 274303193274824160.0)
    check("واحد هم خوانده شد", _u, "IRR")
    _old = (FIX / "chartix_page.html").read_text(encoding="utf-8")
    check("قالب قدیمی هنوز کار می‌کند", _cx.price_of(_old)[0] is not None, True)
    check("صفحهٔ بی‌قیمت ساکت نمی‌ماند", _cx.price_of("<html>هیچ</html>"), (None, None))

    print("\nعلامت ورود پول — فقط از متن، نه از کلاس قرمز")
    from sources import tradersarena as _ta
    _rows, _ = _ta.parse((FIX / "ta_history_all.html").read_text(encoding="utf-8"))
    _flow = {d: v for d, s, v, _ in _rows if s == "flow_retail"}
    check("خانهٔ کلاس‌minus با متن مثبت، مثبت ماند",
          round(_flow.get("14050712", 0), 1), 3080.4, 0.05)
    check("خانه‌ای که علامتش در متن است منفی خوانده شد",
          round(_flow.get("14050711", 0), 1), -7140.8, 0.05)
    _val = {d: v for d, s, v, _ in _rows if s == "value_retail"}
    check("ارزش معاملات هیچ‌وقت منفی نشد",
          [d for d, v in _val.items() if v < 0], [])

    # ------------------------------------------------------------------
    # و همین‌جا بود که باز خورد زمین، از یک جای دیگر: علامت *در متن* بود
    # ولی خط‌تیرهٔ اَسکی نبود. تریدرزآرنا ستون فارسی‌رقم «ورود پول» را با
    # U+2212 و یک U+200E می‌نویسد، و الگوی `-?\d+` آن را بی‌صدا می‌انداخت.
    # ۱۴۰۵/۰۷/۲۹ و ۰۸/۰۲ و ۰۸/۰۳ خروج پول داشتند، در دیتابیس ورود شدند.
    # ------------------------------------------------------------------
    print("\nعلامت منفی یونیکدی (U+2212) — نه فقط خط‌تیرهٔ اَسکی")
    check("U+2212 با رقم لاتین", common.num("‎−2,194.4"), -2194.4, 0.001)
    check("U+2212 با رقم فارسی", common.num("‎−۲,۱۹۴.۴"), -2194.4, 0.001)
    check("خط‌تیرهٔ اَسکی مثل قبل", common.num("-846.4"), -846.4, 0.001)
    check("منفیِ جدا‌افتاده با مرز تگ", common.num("- 4,108.0"), -4108.0, 0.001)
    check("«۱۲۳ - ۴۵۶» اشتباهی منفی نشد", common.num("۱۲۳ - ۴۵۶"), 123.0, 0.001)
    check("پسوند K سر جایش", common.num("418.87 K"), 418870.0, 0.5)
    check("خانهٔ خالی/خط‌تیره تنها → None", common.num("—"), None)

    _rows, _ = _ta.parse((FIX / "tradersarena_u2212.html").read_text(encoding="utf-8"))
    _flow = {d: v for d, s, v, _ in _rows if s == "flow_retail"}
    check("خروج پول ۱۴۰۵/۰۸/۰۳ منفی خوانده شد",
          round(_flow.get("14050803", 0), 1), -2194.4, 0.05)
    check("ورود پول ۱۴۰۵/۰۷/۲۷ مثبت ماند",
          round(_flow.get("14050727", 0), 1), 3309.8, 0.05)
    _v2 = {d: v for d, s, v, _ in _rows if s == "value_retail"}
    check("ارزش معاملات همان قالب سالم ماند",
          round(_v2.get("14050803", 0), 1), 46780.5, 0.05)
    _i2 = {d: v for d, s, v, _ in _rows if s == "index_total"}
    check("شاخص کل همان قالب سالم ماند", _i2.get("14050803"), 8015546.0)

    print("\nفایل‌های همراه — داده‌هایی که فقط از اکسل می‌آیند")
    import gzip as _gz
    import csv as _csv
    import sqlite3 as _sq4
    import migrate as _mig
    from store import SCHEMA as _SC4, upsert_ind as _ui

    check("فایل صنایع همراه کد هست", _mig.IND_BUNDLE.exists(), True)
    check("فایل سری‌های بی‌فایل همراه کد هست", _mig.EXTRA_BUNDLE.exists(), True)

    if _mig.IND_BUNDLE.exists():
        with _gz.open(_mig.IND_BUNDLE, "rt", encoding="utf-8", newline="") as _fh:
            _rows = list(_csv.DictReader(_fh))
        check("فایل صنایع خالی نیست", len(_rows) > 1000, True)
        check("درآمد ثابت داخلش هست",
              any(r["ind"] == "fixed-income-funds" for r in _rows), True)
        check("مسیر کامپیوترِ من داخلش نیست",
              any("/" in (r.get("source") or "") for r in _rows), False)

        # قاعدهٔ طلایی: مهاجرت فقط جای خالی را پر می‌کند. یک ردیف دستی با
        # عدد عمداً غلط می‌گذاریم و می‌بینیم دست‌نخورده می‌ماند.
        c4 = _sq4.connect(":memory:")
        c4.executescript(_SC4)
        r0 = _rows[0]
        _ui(c4, r0["date_j"], r0["ind"], "value", -12345.0, "tsetmc", "قبلی")
        c4.commit()
        _mig.ensure_industry_bundle(c4, log=lambda *a: None)
        kept = c4.execute("SELECT value, source FROM industry_obs WHERE date_j=? "
                          "AND ind=? AND metric='value'",
                          (r0["date_j"], r0["ind"])).fetchone()
        check("ردیف موجود دست‌نخورده ماند", kept, (-12345.0, "tsetmc"))
        n_new = c4.execute("SELECT COUNT(*) FROM industry_obs").fetchone()[0]
        check("بقیه وارد شدند", n_new > 1000, True)
        c4.close()

    if _mig.EXTRA_BUNDLE.exists():
        with open(_mig.EXTRA_BUNDLE, encoding="utf-8", newline="") as _fh:
            _ex = list(_csv.DictReader(_fh))
        check("نقدینگی اکسلی داخلش هست",
              sum(1 for r in _ex if r["source"] == "m2_file") > 1000, True)
        check("مسیر آپلود داخلش نیست",
              any("uploads" in (r.get("src_ref") or "") for r in _ex), False)

    # ------------------------------------------------------------------
    # تصحیح ردیف‌هایی که باگ علامت خراب کرده بود. تنها بازنویسیِ برنامه
    # است، پس قیدهایش باید قفل باشند: فقط منبع tradersarena، فقط همان
    # روزها، و بار دوم هیچ کاری نکند.
    # ------------------------------------------------------------------
    print("\nتصحیح علامتِ ردیف‌های ثبت‌شده")
    c5 = _sq4.connect(":memory:")
    c5.executescript(_SC4)
    _u5 = __import__("store").upsert
    # وضعیت دیتابیس کاربر: ۰۸/۰۳ غلط از تریدرزآرنا، ۰۸/۰۴ درست از پارسیس
    for _d, _s, _v, _src in [("14050803", "flow_retail", 2194.4, "tradersarena"),
                             ("14050803", "flow_fixed", -1745.0, "tradersarena"),
                             ("14050802", "flow_retail", 8121.7, "parsistahlil"),
                             ("14050727", "flow_retail", 3309.8, "tradersarena")]:
        _u5(c5, _d, _s, _v, _src, "تست")
    _ui(c5, "14050803", "fixed-income-funds", "flow", -1745.0, "tradersarena", "تست")
    c5.commit()
    check("بار اول کار کرد", _mig.ensure_flow_sign_fix(c5, log=lambda *a: None), True)
    _g5 = lambda d, s: c5.execute(                                    # noqa: E731
        "SELECT value FROM observations WHERE date_j=? AND series=?",
        (d, s)).fetchone()[0]
    check("ردیف غلط تریدرزآرنا منفی شد", _g5("14050803", "flow_retail"), -2194.4)
    check("درآمد ثابتِ همان روز بازحساب شد", _g5("14050803", "flow_fixed"), 2643.8)
    check("ردیف پارسیس دست‌نخورده ماند", _g5("14050802", "flow_retail"), 8121.7)
    check("روزی که از اول درست بود دست‌نخورده ماند",
          _g5("14050727", "flow_retail"), 3309.8)
    check("آینهٔ صنایع هم تصحیح شد",
          c5.execute("SELECT value FROM industry_obs WHERE date_j='14050803' "
                     "AND ind='fixed-income-funds' AND metric='flow'").fetchone()[0],
          2643.8)
    check("بار دوم ساکت", _mig.ensure_flow_sign_fix(c5, log=lambda *a: None), False)
    c5.close()

    print(f"\n{ok} تست سبز، {fail} قرمز")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
