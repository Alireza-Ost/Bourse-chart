#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ساخت صفحهٔ نمودار از روی دیتابیس — دو حالت:

    python3 make_chart.py            charts/chart.html   (داده داخل خود صفحه)
    python3 make_chart.py --web      web/index.html + web/data.json
    python3 make_chart.py --open     همان حالت اول، و بازکردنش در مرورگر

حالت --web برای وقتی است که صفحه را روی اینترنت می‌گذارید: صفحه یک بار آپلود
می‌شود و از آن به بعد هر روز فقط data.json عوض می‌شود.
"""
import json
import sys
import webbrowser
from pathlib import Path

import jdatetime

from config import BASE, CHART_DIR, SERIES
from store import connect

WEB_DIR = BASE / "web"
KEYS = ["index_total", "index_ew", "value_retail", "flow_retail",
        "mv", "mv_tse", "mv_ifb", "mv_usd", "usd_rate", "gold18", "mv_gold",
        "m2", "ratio", "pe_market"]
ALIAS = {"pe_market": "pe"}
# محور افقی بر مبنای «روز معاملاتی بورس» است. طلا شنبه تا چهارشنبه نیست و
# روزهایی هم معامله می‌شود که بورس بسته است؛ اگر آن روزها هم ردیف بگیرند،
# محور کش می‌آید و همهٔ نمودارها یک نوار خالی وسطشان پیدا می‌کنند. پس ردیف‌ها
# را سری‌های بورسی تعیین می‌کنند و طلا روی همان روزها نمونه‌برداری می‌شود.
AXIS_EXCLUDE = {"gold18"}


def build_payload(con):
    series, dates = {}, set()
    for k in KEYS:
        rows = dict(con.execute(
            "SELECT date_j, value FROM observations WHERE series=? ORDER BY date_j", (k,)))
        series[k] = rows
        if k not in AXIS_EXCLUDE:
            dates |= rows.keys()

    ds = sorted(dates)
    out = {"d": ds, "t": []}
    for j in ds:
        g = jdatetime.date(int(j[:4]), int(j[4:6]), int(j[6:])).togregorian()
        out["t"].append(int(g.strftime("%Y%m%d")))
    for k in KEYS:
        out[ALIAS.get(k, k)] = [
            (round(series[k][j], 4) if j in series[k] else None) for j in ds]
    return out


def main():
    web = "--web" in sys.argv
    tpl = CHART_DIR / ("template_web.html" if web else "template.html")
    if not tpl.exists():
        sys.exit(f"قالب پیدا نشد: {tpl}")

    con = connect()
    payload = build_payload(con)
    con.close()
    blob = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)

    if web:
        WEB_DIR.mkdir(exist_ok=True)
        (WEB_DIR / "index.html").write_text(tpl.read_text(encoding="utf-8"), encoding="utf-8")
        (WEB_DIR / "data.json").write_text(blob, encoding="utf-8")
        out = WEB_DIR / "index.html"
        print(f"{WEB_DIR}/index.html  +  data.json ({len(blob):,} بایت)")
    else:
        out = CHART_DIR / "chart.html"
        out.write_text(tpl.read_text(encoding="utf-8").replace("__DATA__", blob),
                       encoding="utf-8")
        print(f"{out}  ({len(blob):,} بایت داده)")

    print(f"{len(payload['d'])} روز — {payload['d'][0]} تا {payload['d'][-1]}")
    for k in KEYS:
        a = payload[ALIAS.get(k, k)]
        print(f"  {SERIES.get(k, (k,))[0]}: {sum(1 for v in a if v is not None)}")

    if "--open" in sys.argv and not web:
        webbrowser.open(out.resolve().as_uri())


if __name__ == "__main__":
    main()
