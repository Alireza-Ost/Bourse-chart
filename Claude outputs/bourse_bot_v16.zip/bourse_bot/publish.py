# -*- coding: utf-8 -*-
"""
انتشار: ساخت صفحه و داده از دیتابیس، کپی در پوشهٔ ریپو، و پوش به گیت‌هاب.

    python3 publish.py            # ساخت + کپی + پوش
    python3 publish.py --dry      # فقط ساخت، بدون گیت

همین تابع را ربات هم صدا می‌زند: بعد از هر فوروارد که دادهٔ تازه‌ای بنویسد،
چند ثانیه صبر می‌کند (تا اگر چند پست پشت سر هم فوروارد شد یک بار منتشر شود)
و بعد خودش سایت را به‌روز می‌کند. پس فقط فوروارد کافی است.

گیت از اطلاعات حساب ویندوز شما استفاده می‌کند — همانی که یک بار با آن پوش زدید.
اگر گیت نصب نباشد یا ریپو پیدا نشود، فایل‌ها ساخته می‌شوند و فقط پوش رد می‌شود،
با پیام روشن. هیچ‌وقت بی‌صدا شکست نمی‌خورد.
"""
import json
import shutil
import subprocess
import sys

from config import CHART_DIR, REPO_DIR, PAGE_URL
from make_chart import WEB_DIR, build_payload
from store import connect


def _git(args, cwd):
    return subprocess.run(["git"] + args, cwd=str(cwd), capture_output=True,
                          text=True, encoding="utf-8", errors="replace", timeout=180)


def build(con):
    """web/index.html و web/data.json را از دیتابیس می‌سازد."""
    tpl = CHART_DIR / "template_web.html"
    if not tpl.exists():
        raise FileNotFoundError(f"قالب پیدا نشد: {tpl} — charts/build_templates.py را بزنید")
    payload = build_payload(con)
    blob = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    WEB_DIR.mkdir(exist_ok=True)
    (WEB_DIR / "index.html").write_text(tpl.read_text(encoding="utf-8"), encoding="utf-8")
    (WEB_DIR / "data.json").write_text(blob, encoding="utf-8")
    return len(payload["d"]), payload["d"][-1]


def publish(con=None, push=True):
    """خروجی: متن گزارش کوتاه، برای چاپ یا فرستادن در تلگرام."""
    own = con is None
    if own:
        con = connect()
        import migrate
        migrate.run_all(con)
    try:
        n_days, last = build(con)
    finally:
        if own:
            con.close()

    lines = [f"📄 صفحه ساخته شد — {n_days} روز، تا {last}"]

    if not push:
        return "\n".join(lines)

    if not REPO_DIR or not (REPO_DIR / ".git").exists():
        lines.append(f"⚠️ ریپو پیدا نشد: {REPO_DIR}")
        lines.append("   مسیر را با متغیر BOURSE_REPO تنظیم کنید.")
        return "\n".join(lines)

    if shutil.which("git") is None:
        lines.append("⚠️ گیت نصب نیست — فایل‌ها ساخته شدند ولی پوش نشد.")
        return "\n".join(lines)

    for name in ("index.html", "data.json"):
        shutil.copyfile(WEB_DIR / name, REPO_DIR / name)

    _git(["add", "-A"], REPO_DIR)
    c = _git(["commit", "-m", f"update {last}"], REPO_DIR)
    if "nothing to commit" in (c.stdout + c.stderr):
        lines.append("⏭ چیزی برای کامیت نبود — سایت همین حالا هم به‌روز است.")
        return "\n".join(lines)

    p = _git(["push"], REPO_DIR)
    if p.returncode != 0:
        err = (p.stderr or p.stdout).strip().splitlines()
        lines.append("⛔️ پوش نشد:")
        lines += ["   " + e for e in err[-4:]]
        lines.append("   یک بار دستی `git push` بزنید تا ببینیم چه می‌خواهد.")
        return "\n".join(lines)

    lines.append("🚀 منتشر شد.")
    lines.append(f"   {PAGE_URL}")
    lines.append("   با Ctrl+Shift+R باز کنید (F5 نسخهٔ کش‌شده را نشان می‌دهد).")
    return "\n".join(lines)


if __name__ == "__main__":
    print(publish(push="--dry" not in sys.argv))
