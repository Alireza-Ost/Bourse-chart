# -*- coding: utf-8 -*-
"""
پر کردن نقدینگی شش ماههٔ اول ۱۴۰۵ با نرخ رشد ماهانهٔ فرضی.

    python3 estimate_m2.py 3.54

این ارقام **رسمی نیستند** — برآوردند. با منبع «m2_estimate» ذخیره می‌شوند که
اولویتش پایین است، پس هر رقم واقعی بانک مرکزی که بعداً بفرستید جایشان را
می‌گیرد. روزهای بین دو ماه هم خودکار درون‌یابی می‌شوند.
"""
import sys
from store import connect, upsert, interpolate_m2, derive_totals

MONTHS = ["14050131", "14050231", "14050331", "14050431", "14050531", "14050631"]
NAMES = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور"]


def main(rate_pct):
    g = 1 + rate_pct / 100
    con = connect()
    base = con.execute(
        "SELECT date_j, value FROM observations WHERE series='m2' "
        "AND source NOT IN ('m2_estimate','m2_interp') ORDER BY date_j DESC LIMIT 1"
    ).fetchone()
    if not base:
        sys.exit("هیچ رقم واقعی نقدینگی در دیتابیس نیست.")
    d0, v0 = base
    print(f"پایه: {d0} = {v0:,.2f} همت  ·  رشد ماهانه {rate_pct}٪\n")

    v = v0
    for date_j, name in zip(MONTHS, NAMES):
        v *= g
        upsert(con, date_j, "m2", v, "m2_estimate", f"رشد ماهانه {rate_pct}٪ از {d0}")
        print(f"  {date_j}  {name:9s} {v:>10,.0f} همت   (×{v/v0:.4f})")

    n = interpolate_m2(con)
    days = [r[0] for r in con.execute("SELECT DISTINCT date_j FROM observations WHERE series='m2'")]
    derive_totals(con, days)
    print(f"\n{n} روز بین ماه‌ها درون‌یابی شد و نسبت بازسازی شد.")
    con.close()


if __name__ == "__main__":
    main(float(sys.argv[1]) if len(sys.argv) > 1 else 3.54)
