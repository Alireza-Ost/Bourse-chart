# -*- coding: utf-8 -*-
"""
مهاجرت‌های خودکار — چیزهایی که باید یک بار روی دیتابیسِ موجود اجرا شوند.

هر بار که ربات بالا می‌آید صدا زده می‌شود و اگر کاری لازم نباشد ساکت است.
دلیل وجودش: دیتابیس شما بیرون از پوشهٔ پروژه است (تا با به‌روزرسانی کد پاک
نشود)، پس دیتابیسِ اولیهٔ همراه نسخهٔ تازه به دستتان نمی‌رسد. هر سری تازه‌ای
که بعداً اضافه شود، از این مسیر وارد دیتابیسِ خودتان می‌شود.

هر سری جداگانه بررسی می‌شود، نه همه با هم — وگرنه اضافه‌شدن سری چهارم به
دیتابیسی که سه سری اول را دارد نادیده گرفته می‌شود.
"""
from config import BASE

CHARTIX_DIR = BASE / "data" / "chartix"

# کلید سری -> (نام فایل، مقسوم‌علیه واحد، برچسب)
CHARTIX = [
    ("mv_tse", "mv_tse.csv", "RIAL_PER_HEMAT", "ارزش بازار بورس"),
    ("mv_ifb", "mv_ifb.csv", "RIAL_PER_HEMAT", "ارزش بازار فرابورس"),
    ("mv_usd", "mv_usd.csv", "USD_PER_BILLION", "ارزش دلاری بازار"),
    ("gold18", "gold18.csv", "ONE",             "طلای ۱۸ عیار"),
]


def ensure_market_value(con, log=print):
    """هر سری چارتیکسی که در دیتابیس نیست را از CSV همراه پروژه وارد می‌کند."""
    import import_chartix as ix
    DIVISORS = {"RIAL_PER_HEMAT": ix.RIAL_PER_HEMAT,
                "USD_PER_BILLION": ix.USD_PER_BILLION,
                "ONE": 1.0}

    todo = []
    for series, fname, div, label in CHARTIX:
        have = con.execute("SELECT COUNT(*) FROM observations WHERE series=?",
                           (series,)).fetchone()[0]
        if have or not (CHARTIX_DIR / fname).exists():
            continue
        todo.append((series, fname, DIVISORS[div], label))
    if not todo:
        return False

    log("سری‌های تازه پیدا شد — از فایل‌های همراه پروژه اضافه می‌شود…")

    # اگر ارزش بازار بورس/فرابورس تازه می‌آید، ردیف‌های «ارزش بازار» از منابع
    # ضعیف‌تر باید بروند: اختلاف سطحشان حدود ۸٪ است و سری را پله‌دار می‌کند.
    if any(t[0] in ("mv_tse", "mv_ifb") for t in todo):
        con.execute("DELETE FROM observations WHERE series IN ('mv','ratio') "
                    "AND source IN ('xlsx_seed','json_restore','unknown')")
        con.commit()

    touched = set()
    for series, fname, divisor, label in todo:
        rows = ix.load(con, CHARTIX_DIR / fname, series, divisor, label)
        touched |= set(rows)

    from store import derive_totals
    derive_totals(con, touched)
    log("انجام شد.")
    return True


def ensure_usd_rate(con, log=print):
    """
    نرخ دلار را از تاریخچه بازسازی می‌کند: ارزش بازار (همت) ÷ ارزش دلاری
    (میلیارد دلار) × ۱۰^۳ = تومان به ازای هر دلار. همان نرخی که خود چارتیکس
    برای ساختن سری دلاری استفاده کرده، پس «ضمنی» است نه یک منبع مستقل.
    """
    from store import upsert
    have = con.execute(
        "SELECT COUNT(*) FROM observations WHERE series='usd_rate'").fetchone()[0]
    if have:
        return False
    mv = dict(con.execute("SELECT date_j, value FROM observations WHERE series='mv'"))
    usd = dict(con.execute("SELECT date_j, value FROM observations WHERE series='mv_usd'"))
    shared = sorted(set(mv) & set(usd))
    if not shared:
        return False
    for date_j in shared:
        if usd[date_j]:
            upsert(con, date_j, "usd_rate", mv[date_j] * 1e3 / usd[date_j],
                   "chartix", "ارزش بازار ÷ ارزش دلاری")
    log(f"نرخ دلار برای {len(shared)} روز ساخته شد ({shared[0]} → {shared[-1]}).")
    return True


def run_all(con, log=print):
    a = ensure_market_value(con, log)
    b = ensure_usd_rate(con, log)
    return a or b
