# -*- coding: utf-8 -*-
"""
برگرداندن داده از روی یک data.json به دیتابیس.

    python3 import_json.py "C:\\Users\\ostov\\bourse-chart\\data.json"

برای وقتی که دیتابیس را از دست داده‌اید ولی صفحهٔ منتشرشده هنوز داده دارد.
هر چیزی که در دیتابیس نباشد اضافه می‌شود؛ چیزی که هست و منبع قوی‌تری دارد
دست‌نخورده می‌ماند (همان قواعد SOURCE_PRIORITY).
"""
import json
import sys

from store import connect, upsert

# کلید داخل data.json  ->  کلید سری در دیتابیس
KEYS = {
    "index_total": "index_total", "index_ew": "index_ew",
    "value_retail": "value_retail", "flow_retail": "flow_retail",
    "mv": "mv", "mv_tse": "mv_tse", "mv_ifb": "mv_ifb", "mv_usd": "mv_usd",
    "gold18": "gold18", "mv_gold": "mv_gold", "usd_rate": "usd_rate",
    "m2": "m2", "ratio": "ratio", "pe": "pe_market",
}


def main(path):
    data = json.load(open(path, encoding="utf-8"))
    dates = data.get("d") or []
    if not dates:
        sys.exit("این فایل آرایهٔ «d» ندارد — data.json درست است؟")

    con = connect()
    stats = {}
    for jkey, series in KEYS.items():
        arr = data.get(jkey) or []
        for date_j, value in zip(dates, arr):
            if value is None:
                continue
            res = upsert(con, str(date_j), series, float(value),
                         "json_restore", path)
            k = res.split(":")[0]
            stats[(series, k)] = stats.get((series, k), 0) + 1
    print(f"{len(dates)} روز خوانده شد — {dates[0]} تا {dates[-1]}\n")
    for (series, res), n in sorted(stats.items()):
        print(f"  {series:14s} {res:9s} {n}")
    print("\nبعدش یک /publish بزنید تا صفحه دوباره ساخته شود.")
    con.close()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("مسیر data.json را بدهید.")
    main(sys.argv[1])
