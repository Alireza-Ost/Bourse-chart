#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ربات تلگرام — دریافت پست‌های فورواردشده، پارس، ذخیره، نمودار و هشدار تقاطع.

اجرا:
    export TELEGRAM_BOT_TOKEN="…"
    export TELEGRAM_OWNER_ID="…"
    python3 bot.py

دستورها (در چت خصوصی با ربات):
    /chart    نمودارها
    /cross    وضعیت میانگین‌ها و برخوردهای اخیر
    /status   پوشش داده و رکوردهای ردشده
    /export   خروجی اکسل
    /reparse  پارس دوبارهٔ همهٔ پیام‌های ذخیره‌شده (بعد از اصلاح پارسر)
"""
import io
import sys
import time
import datetime
import requests

from config import (BOT_TOKEN, OWNER_ID, DAILY_REPORT_AT, SERIES, EXPORT_XLSX,
                    AUTO_PUBLISH, PUBLISH_DELAY_SEC)

# ---- مالک ربات -------------------------------------------------------
# اگر TELEGRAM_OWNER_ID تنظیم شده باشد همان معتبر است. اگر نه، ربات اولین
# کسی را که در چت خصوصی به او پیام بدهد مالک ثبت می‌کند و شناسه‌اش را در
# دیتابیس نگه می‌دارد. این‌طور لازم نیست شناسهٔ عددی‌تان را از جای دیگری
# پیدا کنید — کافی است بعد از روشن‌کردن ربات یک /start برایش بفرستید.
_owner_cache = None
_publish_due = None          # زمانی که باید منتشر شود (None یعنی چیزی در صف نیست)

MANUAL_HELP = (
    "⚠️ چیزی از این متن نفهمیدم.\n\n"
    "برای ورود دستی، تاریخ و نام و عدد را بنویسید — هر خط یک مورد:\n\n"
    "<code>14050631 ارزش معاملات 21000</code>\n"
    "<code>14050631 ورود پول حقیقی -3500</code>\n\n"
    "یا تاریخ را یک بار بالا بنویسید:\n\n"
    "<code>1405/06/31\n"
    "ارزش معاملات 21000\n"
    "شاخص کل 7650000\n"
    "ارزش بازار 12500 همت</code>\n\n"
    "نام‌هایی که می‌شناسم: ارزش معاملات · ورود پول حقیقی · شاخص کل · "
    "شاخص هم وزن · ارزش بازار · نقدینگی · نسبت · P/E · سرانه خرید · سرانه فروش\n\n"
    "تاریخ لازم است — بدون آن نمی‌دانم عدد مال کدام روز است."
)


def owner(con=None):
    global _owner_cache
    if OWNER_ID:
        return str(OWNER_ID)
    if _owner_cache is None and con is not None:
        _owner_cache = get_setting(con, "owner_id")
    return _owner_cache


def claim_owner(con, chat_id):
    global _owner_cache
    set_setting(con, "owner_id", chat_id)
    _owner_cache = str(chat_id)
    return _owner_cache
from store import connect, save_raw, upsert, coverage, get_setting, set_setting
import parsers
import analyze
import charts
import publish as publisher

API = f"https://api.telegram.org/bot{BOT_TOKEN}"
TEHRAN = datetime.timezone(datetime.timedelta(hours=3, minutes=30))


def fmt(v):
    """۷۵۵۷۶۴۲ → 7,557,642 و ۲.۵ → 2.5 (بدون نماد علمی)."""
    return f"{v:,.0f}" if abs(v) >= 1000 or float(v).is_integer() else f"{v:,.2f}"


# ---------- لایهٔ تلگرام -------------------------------------------------
def api(method, **params):
    r = requests.post(f"{API}/{method}", data=params, timeout=70)
    r.raise_for_status()
    return r.json()


def send(text, chat_id=None):
    for chunk in [text[i:i + 3800] for i in range(0, len(text), 3800)] or [""]:
        api("sendMessage", chat_id=chat_id or owner(), text=chunk,
            parse_mode="HTML", disable_web_page_preview=True)


def send_photo(path, caption="", chat_id=None):
    with open(path, "rb") as f:
        requests.post(f"{API}/sendPhoto",
                      data={"chat_id": chat_id or owner(), "caption": caption},
                      files={"photo": f}, timeout=90).raise_for_status()


# ---------- دریافت پیام --------------------------------------------------
def origin_of(msg):
    """(کانال مبدأ، تاریخ اصلی، شناسهٔ پیام مبدأ) از متادیتای فوروارد."""
    fo = msg.get("forward_origin") or {}
    chat = fo.get("chat") or {}
    ch = chat.get("username") or fo.get("sender_user_name") or ""
    ts = fo.get("date") or msg.get("forward_date") or msg.get("date")
    # سازگاری با نسخه‌های قدیمی‌تر Bot API
    if not ch and msg.get("forward_from_chat"):
        ch = msg["forward_from_chat"].get("username", "")
    src_id = fo.get("message_id") or msg.get("forward_from_message_id")
    d = datetime.datetime.fromtimestamp(ts, TEHRAN).date() if ts else datetime.date.today()
    return ch, d, src_id


def ingest(con, msg):
    """یک پیام کانال را ذخیره و پارس می‌کند. خروجی: متن گزارش کوتاه."""
    text = msg.get("text") or msg.get("caption") or ""
    if not text.strip():
        return None
    channel, orig_date, src_id = origin_of(msg)
    uid = f"{msg['chat']['id']}:{msg['message_id']}"
    save_raw(con, uid, channel, src_id, orig_date.isoformat(), text)

    rows, used = parsers.parse(channel, text, orig_date, with_name=True)
    if not rows:
        if channel:
            return f"⚠️ از این پیام چیزی استخراج نشد (کانال: {channel})"
        return MANUAL_HELP
    source = channel or ("manual" if used == "manual" else "unknown")

    out, warn, changed = [], "", False
    for date_j, key, value, wd_ok in rows:
        if wd_ok is False:
            warn = "  ⚠️ نام روز هفته با تاریخ نمی‌خواند — با احتیاط"
        res = upsert(con, date_j, key, value,
                     source, f"t.me/{channel}/{src_id}" if src_id else "دستی")
        name = SERIES.get(key, (key,))[0]
        if res.split(":")[0] in ("inserted", "updated"):
            changed = True
        mark = {"inserted": "✅", "updated": "♻️", "kept": "⏭"}.get(res.split(":")[0], "⛔️")
        out.append(f"{mark} {date_j} · {name} = {fmt(value)}"
                   + ("" if not res.startswith("rejected") else f" — {res[10:]}"))
    if changed:
        global _publish_due
        _publish_due = time.time() + PUBLISH_DELAY_SEC
    return "\n".join(out) + warn


def reparse_all(con):
    """پارس دوبارهٔ همهٔ پیام‌های خام. بعد از اصلاح پارسر این را بزنید."""
    rows = con.execute("SELECT src_channel, orig_date, text FROM raw_messages").fetchall()
    n = 0
    for channel, od, text in rows:
        d = datetime.date.fromisoformat(od) if od else datetime.date.today()
        for date_j, key, value, _wd in parsers.parse(channel, text, d):
            upsert(con, date_j, key, value, channel or "unknown", "reparse")
            n += 1
    return len(rows), n


# ---------- خروجی‌ها -----------------------------------------------------
def export_xlsx(con):
    import pandas as pd
    frames = {}
    for key in SERIES:
        rows = con.execute("SELECT date_j, value FROM observations WHERE series=? ORDER BY date_j",
                           (key,)).fetchall()
        if rows:
            frames[SERIES[key][0]] = pd.Series({d: v for d, v in rows})
    if not frames:
        return None
    df = pd.DataFrame(frames)
    df.index.name = "تاریخ شمسی"
    EXPORT_XLSX.parent.mkdir(parents=True, exist_ok=True)
    df.to_excel(EXPORT_XLSX)
    return EXPORT_XLSX


def status_text(con):
    from config import DB_PATH
    lines = ["<b>پوشش داده</b>"]
    for s, n, a, b in coverage(con):
        lines.append(f"  {SERIES.get(s, (s,))[0]}: {n} روز · {a} → {b}")
    nraw = con.execute("SELECT COUNT(*) FROM raw_messages").fetchone()[0]
    lines.append(f"\nپیام‌های خام ذخیره‌شده: {nraw}")
    lines.append(f"دیتابیس: <code>{DB_PATH}</code>")
    rej = con.execute("SELECT date_j, series, value, reason FROM rejected "
                      "ORDER BY id DESC LIMIT 8").fetchall()
    if rej:
        lines.append("\n<b>ردشده در اعتبارسنجی</b>")
        for d, s, v, why in rej:
            lines.append(f"  {d} · {SERIES.get(s, (s,))[0]} = {fmt(v)} — {why}")
    return "\n".join(lines)


def send_charts(con, chat_id=None):
    made = charts.build_all(con)
    if not made:
        send("نموداری ساخته نشد — داده کافی نیست.", chat_id)
        return
    for p in made:
        send_photo(p, caption=p.stem, chat_id=chat_id)


# ---------- حلقهٔ اصلی ---------------------------------------------------
def handle(con, upd):
    msg = upd.get("channel_post") or upd.get("edited_channel_post")
    if msg:
        rep = ingest(con, msg)
        if rep:
            send(rep)
        return

    msg = upd.get("message")
    if not msg:
        return
    chat_id = str(msg.get("chat", {}).get("id"))
    known = owner(con)
    if known is None:
        # اولین پیام خصوصی، مالک را تعیین می‌کند
        claim_owner(con, chat_id)
        send(f"سلام. شما به‌عنوان مالک این ربات ثبت شدید.\n"
             f"شناسهٔ عددی شما: <code>{chat_id}</code>\n\n"
             f"لازم نیست کار دیگری بکنید؛ همین در دیتابیس ذخیره شد. "
             f"اگر خواستید جای دیگری هم بنویسیدش، همین عدد است.", chat_id)
        known = chat_id
    elif chat_id != known:
        return
    body = msg.get("text") or msg.get("caption") or ""
    cmd = body.split()[0].lower() if body.strip() else ""
    chat = msg["chat"]["id"]

    # هر پیام خصوصی که دستور نیست — چه فوروارد باشد چه متن تایپ‌شده —
    # از همان مسیر پست‌های کانال رد می‌شود. پس فوروارد مستقیم به خود ربات
    # هم کار می‌کند، نه فقط فوروارد به کانال.
    if body.strip() and not cmd.startswith("/"):
        rep = ingest(con, msg)
        send(rep or "⚠️ این پیام متنی ندارد.", chat)
        return

    if cmd in ("/start", "/help"):
        send("دستورها:\n/chart نمودارها\n/cross وضعیت میانگین‌ها\n"
             "/status پوشش داده\n/export خروجی اکسل\n/publish انتشار دستی\n"
             "/reparse پارس دوباره\n\n"
             "برای افزودن داده، پست کانال‌ها را به کانال خودتان فوروارد کنید.", chat)
    elif cmd == "/chart":
        send_charts(con, chat)
    elif cmd == "/cross":
        send(analyze.report(con), chat)
    elif cmd == "/status":
        send(status_text(con), chat)
    elif cmd == "/export":
        p = export_xlsx(con)
        if p:
            with open(p, "rb") as f:
                requests.post(f"{API}/sendDocument", data={"chat_id": chat},
                              files={"document": f}, timeout=120)
        else:
            send("داده‌ای برای خروجی نیست.", chat)
    elif cmd == "/publish":
        send("در حال ساخت و انتشار…", chat)
        try:
            send(publisher.publish(con), chat)
        except Exception as e:
            send(f"⛔️ انتشار شکست خورد: {e}", chat)
    elif cmd == "/reparse":
        a, b = reparse_all(con)
        send(f"{a} پیام دوباره پارس شد، {b} مقدار نوشته شد.", chat)


def main():
    global _publish_due
    if not BOT_TOKEN:
        sys.exit("TELEGRAM_BOT_TOKEN را تنظیم کنید.")
    con = connect()
    if owner(con) is None:
        print("مالک هنوز ثبت نشده — در تلگرام به ربات /start بدهید.")
    else:
        print(f"مالک: {owner(con)}")
    offset, last_report = None, None
    print("ربات روشن شد.")
    while True:
        try:
            r = api("getUpdates", offset=offset, timeout=50,
                    allowed_updates='["message","channel_post","edited_channel_post"]')
            for upd in r.get("result", []):
                offset = upd["update_id"] + 1
                try:
                    handle(con, upd)
                except Exception as e:                       # یک پیام خراب، ربات را نخواباند
                    print("handle error:", e)

            if AUTO_PUBLISH and _publish_due and time.time() >= _publish_due:
                _publish_due = None
                try:
                    send(publisher.publish(con))
                except Exception as e:
                    send(f"⛔️ انتشار خودکار شکست خورد: {e}")

            if DAILY_REPORT_AT:
                now = datetime.datetime.now(TEHRAN)
                stamp = now.strftime("%Y-%m-%d")
                if now.strftime("%H:%M") >= DAILY_REPORT_AT and last_report != stamp:
                    last_report = stamp
                    send("📊 <b>گزارش روزانه</b>\n\n" + analyze.report(con))
                    send_charts(con)
        except KeyboardInterrupt:
            break
        except Exception as e:
            print("loop error:", e)
            time.sleep(5)


if __name__ == "__main__":
    main()
