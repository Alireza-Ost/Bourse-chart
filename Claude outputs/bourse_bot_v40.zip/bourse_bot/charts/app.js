/* ------------------------------------------------------------------ *
 *  نمای بازار سرمایه — نمودار خطی با جابه‌جایی و بزرگ‌نمایی
 *  محور افقی بر مبنای «روز معاملاتی» است نه روز تقویمی، پس تعطیلی بازار
 *  فاصلهٔ جعلی نمی‌سازد؛ روزهای شکاف با خط‌چین کم‌رنگ علامت می‌خورند.
 * ------------------------------------------------------------------ */
const SERIES = [
  {k:"index_total",  n:"شاخص کل",              u:"واحد",          ma:[50,200], dec:0},
  {k:"index_ew",     n:"شاخص هم‌وزن",           u:"واحد",          ma:[50,200], dec:0},
  {k:"value_retail", n:"ارزش معاملات خرد",      u:"میلیارد تومان", ma:[7,21],   dec:0},
  {k:"flow_retail",  n:"ورود پول حقیقی", fn:"خالص ورود پول حقیقی به بازار",        u:"میلیارد تومان", ma:[7,21],   dec:0, signed:true},
  {k:"flow_fixed",   n:"ورود پول به درآمد ثابت", fn:"خالص ورود پول به صندوق‌های درآمد ثابت",u:"میلیارد تومان", ma:[7,21],   dec:0, signed:true},
  {k:"value_fixed",  n:"معاملات درآمد ثابت", fn:"ارزش معاملات صندوق‌های درآمد ثابت",    u:"میلیارد تومان", ma:[7,21],   dec:0},
  {k:"flow_lev",     n:"ورود پول به اهرمی", fn:"خالص ورود پول به صندوق‌های اهرمی",     u:"میلیارد تومان", ma:[7,21],   dec:0, signed:true},
  {k:"value_lev",    n:"معاملات اهرمی", fn:"ارزش معاملات صندوق‌های اهرمی",         u:"میلیارد تومان", ma:[7,21],   dec:0},
  {k:"flow_goldfund",  n:"ورود پول به ص.طلا", fn:"خالص ورود پول به صندوق‌های طلا",   u:"میلیارد تومان", ma:[7,21],   dec:0, signed:true},
  {k:"value_goldfund", n:"معاملات ص.طلا", fn:"ارزش معاملات صندوق‌های طلا",       u:"میلیارد تومان", ma:[7,21],   dec:0},
  {k:"sarane_buy",   n:"سرانه خرید حقیقی",      u:"میلیون تومان",  ma:[7,21],   dec:1},
  {k:"sarane_sell",  n:"سرانه فروش حقیقی",      u:"میلیون تومان",  ma:[7,21],   dec:1},
  {k:"mv",           n:"ارزش کل بازار", fn:"ارزش کل بازار (بورس + فرابورس)",         u:"همت",           ma:[50,200], dec:0},
  {k:"mv_tse",       n:"ارزش بورس", fn:"ارزش بازار بورس",             u:"همت",           ma:[50,200], dec:0, hide:true},
  {k:"mv_ifb",       n:"ارزش فرابورس", fn:"ارزش بازار فرابورس",          u:"همت",           ma:[50,200], dec:0, hide:true},
  {k:"mv_usd",       n:"ارزش دلاری بازار",      u:"میلیارد دلار",  ma:[50,200], dec:1},
  {k:"usd_rate",     n:"نرخ دلار",              u:"تومان",         ma:[50,200], dec:0},
  {k:"gold18",       n:"طلای ۱۸ عیار",          u:"تومان بر گرم",  ma:[50,200], dec:0},
  {k:"mv_gold",      n:"ارزش بازار به طلا",     u:"تن طلا",        ma:[50,200], dec:0},
  {k:"pe",           n:"P/E کل بازار",          u:"",              ma:[50,200], dec:2},
  {k:"m2",           n:"نقدینگی M2",            u:"همت",           ma:[50,200], dec:0},
  /* ماهانه است، نه روزانه: یک نقطه روی اولین روز معاملاتیِ هر ماه. برای
     همین میانگین متحرکش کوتاه است — MA۵۰ روی سری‌ای که ماهی یک نقطه
     دارد یعنی چهار سال، که هیچ‌چیز را نشان نمی‌دهد. */
  {k:"rfr",          n:"نرخ بهره بدون ریسک", fn:"بازده تا سررسید اسناد خزانه (میانه)", u:"درصد", ma:[3,12], dec:2, hole:45},
  {k:"ratio",        n:"ارزش بازار به نقدینگی", fn:"ارزش کل بازار ÷ نقدینگی M2", u:"نسبت",          ma:[50,200], dec:3, hide:true},
];

/* هر «نما» یک چیدمان آماده است: سری اصلی، میانگین‌ها، و پنل پایین. */
const VIEWS = [
  {id:"explore", tab:"نمای کلی", free:true, panel:"volume"},
  {id:"ratio",   tab:"نسبت نقدینگی", key:"ratio", resample:true, ema:[28,110], panel:"none",
   title:"نسبت ارزش بازار به نقدینگی",
   note:"ارزش بازار ÷ نقدینگی M2"},
  /* پنل پایینِ «خالص ورود پول» برداشته شد: همان عدد حالا ستون داخلیِ
     خودِ نمودار است و دو بار نشان‌دادنش فقط ارتفاع نمودار اصلی را
     می‌خورد. */
  {id:"value",   tab:"ارزش معاملات", key:"value_retail", ema:[7,28], panel:"none",
   title:"ارزش معاملات خرد"},
  /* دو واحد روی یک نمودار: ارزش بازار به همت و همان ارزش به دلار. چون
     مقیاسشان حدود ۲۶۴ برابر فرق دارد، هر کدام محور عمودی خودش را دارد —
     وگرنه خط دلاری صاف می‌چسبید به کف نمودار. */
  {id:"mv",      tab:"ارزش بازار", key:"mv", lines:["mv","mv_usd"], dual:true,
   panel:"none", title:"ارزش بازار",
   note:"محور راست: همت · محور چپ: میلیارد دلار"},
  {id:"gold",    tab:"بازار به طلا", key:"mv_gold", ema:[28,110], panel:"none",
   title:"ارزش بازار بر حسب طلا",
   note:"ارزش کل بازار ÷ قیمت یک گرم طلای ۱۸ عیار — بر حسب تن"},
  /* همان نمودار ستونیِ ارزش معاملات، این بار برای یک صنعت: ستون بیرونی
     ارزش معاملات کل آن صنعت و ستون داخلی خالص ورود پول حقیقی‌اش. صنعت
     از کشویی بالای نمودار عوض می‌شود. */
  {id:"indval",  tab:"ارزش معاملات صنایع", indBars:true, ema:[7,28], panel:"none",
   title:"ارزش معاملات صنایع"},
  /* صنایع فقط جدول است، نه نمودار: سیزده ستون در یک نگاه کنار هم بیشتر
     به کار می‌آید تا سیزده نمودار که باید یکی‌یکی عوضشان کرد. */
  {id:"ind",     tab:"صنایع", sheet:true, ind:true, title:"دیده‌بان صنایع"},
  /* جمع ورود پول بین دو تاریخ — هم کل بازار هم تفکیک صنایع.
     `sheet:true` دارد تا همهٔ گاردهای «این نما بوم ندارد» همان‌طور کار
     کنند؛ `flow:true` آن را از جدولِ معمولی جدا می‌کند. */
  {id:"flow",    tab:"جمع ورود پول", sheet:true, flow:true,
   title:"جمع ورود پول حقیقی"},
  {id:"sheet",   tab:"جدول", sheet:true, title:"جدول داده‌ها"},
];

/* نسبت نقدینگی سه بازهٔ نمونه‌برداری دارد. هفتگی و ماهانه از همان سری
   روزانه ساخته می‌شوند — آخرین مقدار هر هفته/ماه — پس داده‌ای اضافه
   نمی‌خواهند. نوسان روزانهٔ نسبت بیشتر از آن است که روند چندساله را
   نشان دهد؛ ماهانه همان روند را لخت می‌کند.
   دورهٔ میانگین‌ها هم با بازه عوض می‌شود: EMA ۱۱۰ روی سری ماهانه یعنی
   نُه سال، که بی‌معنی است. */
const RATIO_STEPS = [
  {id:"d", n:"روزانه", key:"ratio",   ema:[28,110], hole:6},
  {id:"w", n:"هفتگی",  key:"ratio_w", ema:[8,26],   hole:12},
  {id:"m", n:"ماهانه", key:"ratio_m", ema:[6,12],   hole:40},
];
const ratioStep = () => RATIO_STEPS.find(s=>s.id===state.ratioStep) || RATIO_STEPS[0];
const ratioKey  = () => ratioStep().key;

const RANGES = [
  {n:"۱م", d:22}, {n:"۳م", d:65}, {n:"۶م", d:130},
  {n:"۱س", d:250}, {n:"۳س", d:750}, {n:"همه", d:0},
];
const N = DATA.d.length;

const state = {
  view:"explore",
  key:"index_total",
  compare:[],           // کلیدهای سری در حالت مقایسه
  cmpMode:false,
  ind:null,            // کد صنعت انتخاب‌شده در تب صنایع
  ratioStep:"d",       // روزانه / هفتگی / ماهانه در تب نسبت نقدینگی
  maKind:"ema",
  rsi:{},              // نما -> دورهٔ RSI، یا null یعنی خاموش
  ma:{},               // نما -> فهرست دوره‌ها؛ با پیش‌فرض همان نما پر می‌شود
  vwap:{},             // نما -> {anchor,k} یا null
  lrc:{},              // نما -> طول پنجره، یا null
  i0:Math.max(0,N-250), i1:N-1,
  hover:-1,
};

/* ---------- ابزارها ---------- */
const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const PAL = () => [css("--s1"),css("--s2"),css("--s3"),css("--s4"),css("--s5")];
const MAX_MA = 4;
/* سری‌های صنعت هنگام باز کردن تب صنایع ساخته می‌شوند، پس در SERIES نیستند.
   EXTRA همان نقش را برایشان بازی می‌کند و fa() اول آن را نگاه می‌کند. */
const EXTRA = [];
/* سری‌های صنعت کلیدشان `ind_<کد>_<سری>` است و تعدادشان ۶۱×۸ می‌شود؛
   به‌جای ساختن پانصد ردیف توصیف، کلید همان‌جا خوانده می‌شود.
   ترتیب مهم است: اول EXTRA و SERIES، بعد این — وگرنه کلیدهای عادی هم
   به IND سر می‌زدند که هنوز تعریف نشده است. */
/* کد صنعت زیرخط ندارد («۲۷» یا «gold-funds») ولی نام سری دارد
   («sarane_buy»)، پس کد تا نخستین زیرخط است و بقیه نام سری. */
const IND_KEY_RE = /^ind_([^_]+)_(.+)$/;
function fa(k){
  const hit = EXTRA.find(s=>s.k===k) || SERIES.find(s=>s.k===k);
  if(hit) return hit;
  const m = IND_KEY_RE.exec(String(k||""));
  if(!m) return undefined;
  const met = IND.metrics.find(x=>x.k===m[2]);
  if(!met) return undefined;
  const c = IND.codes.find(x=>String(x.c)===m[1]);
  return {k, n:met.n, u:met.u, dec:met.dec, signed:met.signed,
          fn:(c ? `${met.n} — ${c.n}` : met.n)};
}
const view = () => VIEWS.find(v=>v.id===state.view);
const jDate = j => `${j.slice(0,4)}/${j.slice(4,6)}/${j.slice(6)}`;
const PD = "۰۱۲۳۴۵۶۷۸۹";
const pnum = s => String(s).replace(/[0-9]/g, d=>PD[+d]);
const fmt = (v,dec) => v==null ? "—"
  : v.toLocaleString("en-US",{minimumFractionDigits:dec??0,maximumFractionDigits:dec??0});
function nice(v,dec){
  if(v==null) return "—";
  if(v===0) v=0;                       // ‎-0 در JS وجود دارد و روی محور بد می‌نشیند
  if(v<0) return "\u200E\u2212"+nice(-v,dec);   // علامت منفی همیشه سمت چپِ عدد
  if(dec!=null) return fmt(v,dec);
  const a=Math.abs(v);
  if(a>=1000) return fmt(v,0);
  if(a>=10) return fmt(v,1);
  return fmt(v,2);
}
/* عدد سری جاری با تعداد رقم اعشار خودش */
const niceK = (v,k) => nice(v, fa(k)?.dec);

/* درصد تغییر نسبت به نقطهٔ دادهٔ قبلی در همان سری — نه ردیف قبلی محور.
   فرقشان وقتی پیداست که روز قبل تعطیل بوده یا آن سری آن روز داده
   نداشته؛ آن‌وقت تغییر نسبت به آخرین روزی حساب می‌شود که عدد داشت. */
function pctSince(a, i){
  if(!a || a[i]==null) return "";
  let j=i-1; while(j>=0 && a[j]==null) j--;
  if(j<0 || !a[j]) return "";
  const d=(a[i]/a[j]-1)*100;
  if(!isFinite(d)) return "";
  const cls = d>0 ? "up" : (d<0 ? "down" : "");
  const sign = d>0 ? "+" : (d<0 ? "−" : "");
  return `<i class="pc ${cls}">${sign}${Math.abs(d).toFixed(2)}٪</i>`;
}

/* فاصلهٔ تقویمی بین دو ستون محور، برای علامت‌زدن تعطیلی.
   روی قاب هفتگی هر فاصله هفت روز است و روی ماهانه حدود سی — پس آستانه
   هم با طول دورهٔ قاب بزرگ می‌شود، وگرنه کل نمودار خط‌چین می‌شد. */
function gapDays(i){
  if(i<=0) return 0;
  const T=frame().t;
  const p=String(T[i-1]), c=String(T[i]);
  const dp=new Date(+p.slice(0,4),+p.slice(4,6)-1,+p.slice(6));
  const dc=new Date(+c.slice(0,4),+c.slice(4,6)-1,+c.slice(6));
  return Math.round((dc-dp)/864e5);
}
/* میانگین متحرک ساده */
function movingAvg(arr,win){
  const out=new Array(arr.length).fill(null);
  let sum=0, cnt=0; const q=[];
  for(let i=0;i<arr.length;i++){
    const v=arr[i];
    q.push(v); if(v!=null){sum+=v;cnt++;}
    if(q.length>win){const o=q.shift(); if(o!=null){sum-=o;cnt--;}}
    if(q.length===win && cnt>=Math.ceil(win*0.6)) out[i]=sum/cnt;
  }
  return out;
}
/* میانگین متحرک نمایی — روزهای بی‌داده رد می‌شوند، نه اینکه صفر حساب شوند.
   تا وقتی span مشاهدهٔ واقعی جمع نشده چیزی بیرون نمی‌دهد (دورهٔ گرم‌شدن). */
function ema(arr,span){
  const out=new Array(arr.length).fill(null);
  const k=2/(span+1);
  let prev=null, seen=0;
  for(let i=0;i<arr.length;i++){
    const v=arr[i];
    if(v==null) continue;
    prev = prev==null ? v : v*k + prev*(1-k);
    seen++;
    if(seen>=span) out[i]=prev;
  }
  return out;
}
/* شاخص قدرت نسبی، به روش وایلدر.
   روزهای بی‌داده رد می‌شوند و مرجعِ تفاضل، آخرین مقدار معتبر است — نه صفر.
   تا وقتی «period» تفاضل واقعی جمع نشده خروجی نمی‌دهد. */
function rsiOf(arr, period){
  const out=new Array(arr.length).fill(null);
  let prev=null, ag=0, al=0, seen=0;
  for(let i=0;i<arr.length;i++){
    const v=arr[i];
    if(v==null) continue;
    if(prev==null){ prev=v; continue; }
    const d=v-prev; prev=v;
    const gain=d>0?d:0, loss=d<0?-d:0;
    seen++;
    if(seen<=period){
      ag+=gain/period; al+=loss/period;
      if(seen===period) out[i] = al===0 ? 100 : 100 - 100/(1+ag/al);
    } else {
      ag=(ag*(period-1)+gain)/period;
      al=(al*(period-1)+loss)/period;
      out[i] = al===0 ? 100 : 100 - 100/(1+ag/al);
    }
  }
  return out;
}

/* ================= VWAP لنگرانداخته و منحنی رگرسیون =================

   هر دو روی «قیمت پایانی» کار می‌کنند — یعنی همان سری‌ای که رسم شده، چون
   دادهٔ ما روزانه است و هر روز یک عدد دارد، نه OHLC.

   VWAP: میانگین وزنیِ قیمت به حجم، ولی **انباشته از آغاز دوره** نه متحرک.
   در آغاز هر هفته/ماه/فصل/سال از صفر شروع می‌شود — همان «Anchored VWAP»
   که در تریدینگ‌ویو می‌شناسید. وزنش ارزش معاملات همان روز است.

   نوارها انحراف معیارِ **وزنیِ** قیمت حول خود VWAP‌اند، نه انحراف معیار
   ساده:  σ² = Σw(p−vwap)² / Σw = Σwp²/Σw − vwap².
   پس نوار پهن یعنی قیمت در آن دوره پراکنده بوده، نه اینکه صرفاً نوسان
   روزانه زیاد بوده.

   LRC: خط کمترین مربعات روی n نقطهٔ آخر، و مقدارش را *در همان نقطه*
   می‌گیریم. پس برخلاف میانگین متحرک، عقب‌ماندگی فاز ندارد و شیبش جهت روند
   را می‌گوید. نقطه‌های بی‌داده رد می‌شوند و اگر کمتر از ۶۰٪ پنجره داده
   باشد چیزی نمی‌دهد — همان قاعدهٔ میانگین‌ها.
   ------------------------------------------------------------------ */
const VWAP_ANCHORS = [
  {id:"w", n:"هفتگی"}, {id:"m", n:"ماهانه"},
  {id:"q", n:"فصلی"},  {id:"y", n:"سالانه"},
];
const LRC_WINS = [
  {id:5,   n:"هفتگی — ۵ روز"},
  {id:21,  n:"ماهانه — ۲۱ روز"},
  {id:63,  n:"فصلی — ۶۳ روز"},
  {id:250, n:"سالانه — ۲۵۰ روز"},
];
const VWAP_K_DEFAULT = 2;
/* بیشتر از این تعداد تقاطع در یک نما، نشانه‌ها فقط شلوغی‌اند */
const MAX_CROSS_MARKS = 25;

/* نتیجه‌ها سنگین‌اند (۸٬۰۴۷ نقطه × پنجرهٔ ۲۵۰) و draw با هر جابه‌جایی
   صدا زده می‌شود، پس یک بار حساب و نگه داشته می‌شوند. کلید شامل قاب است
   چون سری هفتگی و روزانه هم‌نام‌اند ولی یکی نیستند. */
const _calcCache = new Map();
function cached(key, make){
  if(_calcCache.has(key)) return _calcCache.get(key);
  const v = make();
  if(_calcCache.size > 60) _calcCache.clear();
  _calcCache.set(key, v);
  return v;
}

/* کدام سری وزنِ VWAP این سری است؟ null یعنی VWAP برایش بی‌معنی است. */
const VWAP_WEIGHT = {
  index_total:"value_retail", index_ew:"value_retail",
  mv:"value_retail", mv_tse:"value_retail", mv_ifb:"value_retail",
  mv_usd:"value_retail", mv_gold:"value_retail", pe:"value_retail",
  ratio:"value_retail",
};
function weightKey(k){
  const m = IND_KEY_RE.exec(String(k||""));
  if(m) return (m[2]==="gindex" || m[2]==="pe") ? `ind_${m[1]}_value` : null;
  return VWAP_WEIGHT[k] || null;
}

/* شناسهٔ دوره برای ردیف i. هفته از تاریخ میلادی حساب می‌شود (شنبه مرز
   است) چون شمارهٔ هفتهٔ شمسی دردسر دارد و روزِ هفته همان است. */
function periodKey(i, mode){
  const d = FD(i);
  if(mode==="y") return d.slice(0,4);
  if(mode==="q") return d.slice(0,4) + "Q" + Math.ceil(+d.slice(4,6)/3);
  if(mode==="m") return d.slice(0,6);
  const g = String(frame().t[i]);
  const dt = new Date(+g.slice(0,4), +g.slice(4,6)-1, +g.slice(6,8));
  dt.setDate(dt.getDate() - ((dt.getDay()+1) % 7));   // عقب تا شنبه
  return "W" + dt.getFullYear() + (dt.getMonth()+1) + "_" + dt.getDate();
}

function vwapCalc(price, wgt, mode, k){
  const n = price.length;
  const mid=new Array(n).fill(null), up=new Array(n).fill(null),
        dn=new Array(n).fill(null);
  let key=null, sw=0, swp=0, swp2=0;
  for(let i=0;i<n;i++){
    const pk = periodKey(i, mode);
    if(pk !== key){ key=pk; sw=swp=swp2=0; }
    const p=price[i], w=wgt ? wgt[i] : null;
    if(p==null || w==null || !(w>0)) continue;
    sw+=w; swp+=w*p; swp2+=w*p*p;
    const v = swp/sw;
    const sd = Math.sqrt(Math.max(0, swp2/sw - v*v));
    mid[i]=v; up[i]=v+k*sd; dn[i]=v-k*sd;
  }
  return {mid, up, dn};
}

function lrcCalc(a, win){
  const n=a.length, out=new Array(n).fill(null);
  const need = Math.max(3, Math.ceil(win*0.6));
  for(let i=0;i<n;i++){
    let c=0, sx=0, sy=0, sxx=0, sxy=0;
    for(let j=Math.max(0, i-win+1); j<=i; j++){
      const v=a[j]; if(v==null) continue;
      const x=j-i;                       // آخرین نقطه x=0 می‌شود
      c++; sx+=x; sy+=v; sxx+=x*x; sxy+=x*v;
    }
    if(c < need) continue;
    const den = c*sxx - sx*sx;
    if(!den) continue;
    const slope = (c*sxy - sx*sy)/den;
    out[i] = (sy - slope*sx)/c;          // مقدار خط در x=0
  }
  return out;
}

/* تنظیمات اندیکاتورهای نمای جاری.
   lrcOn یک جفت پنجره برمی‌گرداند: {a, b} — دومی می‌تواند null باشد.
   عدد تنها هم پذیرفته می‌شود تا حالت‌های ذخیره‌شدهٔ قدیمی نشکنند. */
function vwapOn(){ const v=state.vwap[state.view]; return v || null; }
function lrcOn(){
  const v = state.lrc[state.view];
  if(!v) return null;
  return typeof v === "number" ? {a:v, b:null} : v;
}

/* نقاط تقاطع دو منحنی — جایی که علامت اختلافشان عوض می‌شود.
   نقطهٔ گزارش‌شده همان ردیفِ بعد از تغییر علامت است، و `up` می‌گوید
   منحنی کوتاه از پایین به بالا رد شده یا برعکس. */
function crossings(a, b, i0, i1){
  const out = [];
  let prev = null;
  for(let i=Math.max(0,i0); i<=i1; i++){
    if(a[i]==null || b[i]==null) continue;
    const d = a[i] - b[i];
    if(d === 0) continue;
    const s = d > 0;
    if(prev !== null && s !== prev) out.push({i, up:s});
    prev = s;
  }
  return out;
}

/* لایهٔ آمادهٔ رسم: {vwap?, lrc?} — یا تهی اگر خاموش/بی‌معنی باشند */
function overlays(PL){
  const out = {};
  if(PL.indexed || !PL.keys.length) return out;
  const key = PL.keys[0], fid = frame().id || "day";
  const V = vwapOn();
  if(V){
    const wk = weightKey(key);
    const w = wk ? FS(wk) : null;
    if(w) out.vwap = Object.assign(
      cached(`vwap|${fid}|${key}|${wk}|${V.anchor}|${V.k}`,
             () => vwapCalc(FS(key)||[], w, V.anchor, V.k)),
      {anchor:V.anchor, k:V.k, wk});
  }
  const W = lrcOn();
  if(W){
    const mk = w => cached(`lrc|${fid}|${key}|${w}`, () => lrcCalc(FS(key)||[], w));
    out.lrc = { win:W.a, a:mk(W.a) };
    if(W.b && W.b !== W.a) out.lrc2 = { win:W.b, a:mk(W.b) };
  }
  return out;
}

/* دورهٔ RSI نمای جاری — null یعنی خاموش */
function rsiPeriod(){
  const id=state.view;
  return (id in state.rsi) ? state.rsi[id] : null;
}

/* آخرین روزی که این سری داده دارد */
function lastValid(k){
  const a=FS(k), n=FN(); if(!a) return n-1;
  for(let i=n-1;i>=0;i--) if(a[i]!=null) return i;
  return n-1;
}

/* ---------- بوم ---------- */
const stage=document.getElementById("stage"), cv=document.getElementById("cv");
const ctx=cv.getContext("2d"), tip=document.getElementById("tip");
let W=0,H=0,DPR=1;
const PAD={t:14,r:62,b:26,l:12};
/* پهنای ستون برچسب‌های محور عمودی. قیمت طلا هشت‌رقمی است و در ۶۲ پیکسل جا
   نمی‌شود؛ پس بعد از اندازه‌گیریِ پهن‌ترین برچسب، یک بار دوباره چیده می‌شود. */
let GUTTER = 62;
let relaying = false;
function pad(){ return {...PAD, r: Math.max(W<560?52:62, GUTTER)}; }
const PANEL_H=0.20;             // سهم پنل سری از ارتفاع
const RSI_H=0.20;               // سهم پنل RSI

function resize(){
  const r=stage.getBoundingClientRect();
  DPR=Math.min(window.devicePixelRatio||1,2);
  W=Math.max(1,r.width); H=Math.max(1,r.height);
  cv.width=Math.round(W*DPR); cv.height=Math.round(H*DPR);
  ctx.setTransform(DPR,0,0,DPR,0,0);
  draw();
}

/* ---------- چیدمان ---------- */
function layout(){
  const P=pad();
  const V=view();
  const hasPanel = !V.sheet && plan().panel!=="none";
  const hasRsi   = !V.sheet && rsiPeriod()!=null;
  const inner = H-P.t-P.b;

  /* از پایین به بالا چیده می‌شود: RSI پایین‌ترین، بعد پنل سری، بعد نمودار اصلی */
  let bot = H-P.b;
  let rsiTop=null, rsiBot=null, panelTop=null, panelBot=null;
  if(hasRsi){
    rsiBot=bot; rsiTop=bot-Math.round(inner*RSI_H); bot=rsiTop-14;
  }
  if(hasPanel){
    panelBot=bot; panelTop=bot-Math.round(inner*PANEL_H); bot=panelTop-14;
  }
  return {
    x0:P.l, x1:W-P.r,
    mainTop:P.t, mainBot:bot,
    panelTop, panelBot, hasPanel,
    rsiTop, rsiBot, hasRsi,
    bottom: rsiBot ?? panelBot ?? (H-P.b),
  };
}
const xAt = (i,L) => L.x0 + (i-state.i0)/Math.max(1,(state.i1-state.i0)) * (L.x1-L.x0);
const iAt = (px,L) => state.i0 + (px-L.x0)/(L.x1-L.x0) * (state.i1-state.i0);

function ticks(lo,hi,n){
  const raw=(hi-lo)/n, mag=Math.pow(10,Math.floor(Math.log10(raw)));
  const step=[1,2,2.5,5,10].map(m=>m*mag).find(s=>s>=raw)||10*mag;
  const out=[]; for(let v=Math.ceil(lo/step)*step; v<=hi; v+=step) out.push(v);
  return out;
}
function roundRectPath(x,y,w,h,r){
  r=Math.min(r,Math.abs(w)/2,Math.abs(h)/2);
  ctx.beginPath();
  if(ctx.roundRect) ctx.roundRect(x,y,w,h,r);
  else ctx.rect(x,y,w,h);
}

/* پنل میله‌ای ارزش معاملات زیر این سری‌ها چیزی اضافه نمی‌کند:
   یا خودشان همان ارزش معاملات‌اند، یا اصلاً ربطی به حجم معاملات بورس ندارند
   (طلا، دلار، نقدینگی). پس آنجا پنل پایین حذف می‌شود و نمودار تمام‌قد است. */
/* خودِ «ارزش معاملات» پنل میله‌ای ارزش معاملات لازم ندارد — دو بار یک چیز.
   سبدهای صندوق (اهرمی و طلا) هم همین‌طور. ورود پولشان ولی پنل می‌گیرد،
   هم‌شکل ورود پول به درآمد ثابت. */
const NO_VOLUME = new Set(["value_retail","value_lev","value_goldfund",
                           "mv_usd","usd_rate","gold18","mv_gold","m2","pe"]);

/* دوره‌های میانگین برای نمای جاری. خالی یعنی هیچ میانگینی. */
/* کلید حافظهٔ دوره‌های میانگین.
   هر بازهٔ نسبت نقدینگی حافظهٔ خودش را دارد: اگر روی ماهانه دوره را عوض
   کردید، برگشتن به روزانه دوره‌های روزانه را برمی‌گرداند.

   ⚠ این تابع جدا شد چون یک بار خواندن و نوشتن از دو کلید مختلف انجام
     می‌شد — خواندن از «ratio:d» و نوشتن روی «ratio» — و نتیجه‌اش این بود
     که در تب نسبت نقدینگی هر چه در کادر میانگین می‌نوشتید بی‌اثر بود و
     عددها روی پیش‌فرض می‌ماندند. حالا هر دو از همین‌جا می‌آیند. */
function maKey(){
  const V=view();
  return V.resample ? `${state.view}:${state.ratioStep}` : state.view;
}
function maDefaults(){
  const V=view();
  return ((V.resample ? ratioStep().ema : V.ema) || []).slice();
}
function maPeriods(){
  const id = maKey();
  if(!(id in state.ma)) state.ma[id] = maDefaults();
  return state.ma[id];
}

/* ارزش معاملات خرد ستونی رسم می‌شود نه خطی، و خالص ورود پول هم ستونِ
   باریک‌ترِ داخلِ همان ستون. هر دو روی یک مقیاس‌اند، پس ستون رنگی واقعاً
   می‌گوید چه کسری از گردش آن روز، ورود یا خروج پول خالص بوده — در میانه
   حدود ۶٪ و در صدک نود حدود ۲۰٪.
   فقط وقتی که همین یک سری رسم می‌شود؛ در حالت مقایسه خطی می‌ماند تا با
   سری دیگر قابل تطبیق باشد. */
const BAR_SERIES = "value_retail";
const BAR_FLOW   = "flow_retail";
const barKey = keys => keys.length===1 && keys[0]===BAR_SERIES;

/* چه چیزی در این نما رسم می‌شود */
function plan(){
  const V=view();
  if(V.sheet) return {keys:[state.key], indexed:false, ma:null, panel:"none"};
  /* نمودار ستونی صنعت: همان دو ستونِ تودرتو، ولی سریِ بیرونی و درونی
     کلیدِ همان صنعت‌اند نه ارزش معاملات خرد بازار. */
  if(V.indBars){
    const c=state.ind;
    if(!c) return {keys:[], indexed:false, ma:null, panel:"none"};
    return {keys:[indKey(c,"value")], indexed:false, ma:maPeriods(),
            maKind:state.maKind, panel:"none",
            bars:true, barFlow:indKey(c,"flow")};
  }
  if(V.lines) return {keys:V.lines, indexed:false, ma:maPeriods(),
                      maKind:state.maKind, panel:V.panel, dual:!!V.dual};
  if(V.resample) return {keys:[ratioKey()], indexed:false, ma:maPeriods(),
                         maKind:state.maKind, panel:V.panel, hole:ratioStep().hole,
                         labels:frame().labels || null};
  if(!V.free) return {keys:[V.key], indexed:false, ma:maPeriods(),
                      maKind:state.maKind, panel:V.panel, bars:barKey([V.key]),
                      hole:seriesHole([V.key]), barFlow:BAR_FLOW};
  const keys = state.cmpMode && state.compare.length ? state.compare : [state.key];
  const indexed = keys.length>1;
  const showVol = !keys.every(k => NO_VOLUME.has(k));
  return {keys, indexed, bars:barKey(keys), barFlow:BAR_FLOW,
          ma: indexed ? null : maPeriods(), maKind:state.maKind,
          hole: seriesHole(keys),
          panel: showVol ? "volume" : "none"};
}

/* سری‌ها هم‌طول نیستند: ارزش بازار روزهایی داده دارد که شاخص ندارد و برعکس.
   اگر برای هر نقطهٔ خالی قلم را برداریم، خط خط‌چین‌خط‌چین می‌شود. پس حفره‌های
   کوتاه (چند ردیف) وصل می‌شوند و فقط حفره‌های واقعی — مثل نبودِ سه‌سالهٔ داده —
   خط را می‌شکنند. */
const MAX_HOLE = 6;
/* hole را صدازننده می‌تواند بزرگ‌تر کند: سری هفتگی هر پنج ردیف یک نقطه
   دارد و ماهانه هر بیست ردیف، پس با حفرهٔ شش‌تایی خط‌خطی می‌شدند. */
/* سریِ ماهانه روی محورِ روز معاملاتی هر ماه یک نقطه دارد و بینشان بیست
   ردیف خالی است. با حفرهٔ پیش‌فرضِ شش‌تایی، خط هیچ‌وقت وصل نمی‌شود و
   هفتادوهشت نقطه مثل هفتادوهشت نقطهٔ جدا دیده می‌شوند — دقیقاً همان
   چیزی که اولین بار سرِ «نرخ بدون ریسک» دیدیم. حفره از خودِ تعریف سری
   می‌آید تا این دانش یک جا بماند، نه پخشِ شرط‌های موردی در کد ترسیم. */
function seriesHole(keys){
  let h = 0;
  for(const k of keys || []) h = Math.max(h, fa(k)?.hole || 0);
  return h || undefined;
}

function strokeSeries(a, L, yAt, hole){
  const H = hole || MAX_HOLE;
  ctx.beginPath();
  let prev = -1;
  for(let i=state.i0;i<=state.i1;i++){
    const v=a[i]; if(v==null) continue;
    const x=xAt(i,L), y=yAt(v);
    if(prev<0 || i-prev>H) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    prev=i;
  }
  ctx.stroke();
}

/* ---------- ترسیم ---------- */
function draw(){
  if(view().sheet) return;
  const L=layout(), V=view(), PL=plan();
  const muted=css("--muted"), line=css("--line"), soft=css("--line-soft"), surf=css("--surface");
  const S=PAL();
  const up=css("--up"), down=css("--down");

  ctx.clearRect(0,0,W,H);
  ctx.textBaseline="middle";
  ctx.font='11px Vazirmatn,system-ui,sans-serif';

  const {keys, indexed}=PL;
  /* تا صنعت انتخاب نشده (یا فایلش نیامده) چیزی برای رسم نیست */
  if(!keys.length) return;

  /* سری‌های آمادهٔ رسم */
  const plot = keys.map((k,idx)=>{
    let a=FS(k)||[];
    if(indexed){
      let base=null;
      for(let i=state.i0;i<=state.i1;i++){ if(a[i]!=null){base=a[i];break;} }
      a = base ? a.map(v=>v==null?null:v/base*100) : a;
    }
    return {k, a, color:S[idx%3], meta:fa(k) || {n:k, dec:0}};
  });

  /* میانگین‌ها — قبل از محاسبهٔ بازهٔ عمودی، تا از کادر بیرون نزنند */
  const mas = (!indexed && PL.ma && PL.ma.length)
    ? PL.ma.slice(0,MAX_MA).map((p,j)=>({
        p, a:(PL.maKind==="ema"?ema:movingAvg)(plot[0].a,p),
        color:S[(j+1)%S.length]}))
    : [];

  /* بازهٔ عمودی پنل اصلی.
     در نمای دومحوره سری دوم در این حساب نمی‌آید؛ محور خودش را دارد. */
  const dual = !!PL.dual && plot.length>1;
  const span = arrs => {
    let l=Infinity,h=-Infinity;
    for(const a of arrs) for(let i=state.i0;i<=state.i1;i++){
      const v=a[i]; if(v==null)continue; if(v<l)l=v; if(v>h)h=v;
    }
    if(!isFinite(l)) return [0,1];
    if(l===h){l-=1;h+=1;}
    const pd=(h-l)*0.08; return [l-pd,h+pd];
  };
  /* اندیکاتورهای روی نمودار اصلی — قبل از حساب بازهٔ عمودی، وگرنه نوار
     پایینیِ VWAP از کف کادر می‌زد بیرون. */
  const OV = overlays(PL);
  const ovArrs = [];
  if(OV.vwap) ovArrs.push(OV.vwap.mid, OV.vwap.up, OV.vwap.dn);
  if(OV.lrc)  ovArrs.push(OV.lrc.a);
  if(OV.lrc2) ovArrs.push(OV.lrc2.a);

  let [lo,hi]=span(dual ? [plot[0].a, ...mas.map(m=>m.a), ...ovArrs]
                        : [...plot.map(p=>p.a), ...mas.map(m=>m.a), ...ovArrs]);
  /* ستون از کفِ صفر بلند می‌شود، پس محور هم باید از صفر شروع کند —
     وگرنه بلندی ستون‌ها نسبت به هم دروغ می‌گوید. */
  if(PL.bars) lo = 0;
  const yAt = v => L.mainBot - (v-lo)/(hi-lo)*(L.mainBot-L.mainTop);
  const [lo2,hi2] = dual ? span([plot[1].a]) : [0,1];
  const yAt2 = v => L.mainBot - (v-lo2)/(hi2-lo2)*(L.mainBot-L.mainTop);
  const yOf = idx => (dual && idx===1) ? yAt2 : yAt;

  /* شبکه + برچسب محور عمودی.
     شبکه «مربعی» است: فاصلهٔ خطوط افقی و عمودی هر دو حدود CELL پیکسل،
     پس خانه‌ها تقریباً مربع درمی‌آیند و چشم شیب را درست می‌خواند.
     خطوط افقی روی عددهای گِرد می‌نشینند (ticks)، پس دقیقاً CELL نیستند؛
     تعدادشان از ارتفاع حساب می‌شود و بعد ticks نزدیک‌ترین عدد گرد را
     می‌دهد. خطوط عمودی از لبهٔ راست — جایی که تازه‌ترین داده است —
     شمرده می‌شوند تا «حالا» همیشه روی خط باشد. */
  const CELL = W<560 ? 34 : 42;
  ctx.strokeStyle=soft; ctx.lineWidth=1;

  ctx.save();
  ctx.beginPath();
  for(let x=L.x1; x>L.x0+2; x-=CELL){
    const xx=Math.round(x)+.5;
    ctx.moveTo(xx, L.mainTop); ctx.lineTo(xx, L.bottom);
  }
  ctx.stroke();
  ctx.restore();

  ctx.fillStyle=muted; ctx.textAlign="left";
  const dec = indexed ? 0 : plot[0].meta.dec;
  const nRows = Math.max(3, Math.round((L.mainBot-L.mainTop)/CELL));
  let widest=0;
  for(const t of ticks(lo,hi,nRows)){
    const y=Math.round(yAt(t))+.5;
    if(y<L.mainTop||y>L.mainBot) continue;
    const lab = indexed ? t.toFixed(0) : nice(t,dec);
    widest = Math.max(widest, ctx.measureText(lab).width);
    ctx.beginPath(); ctx.moveTo(L.x0,y); ctx.lineTo(L.x1,y); ctx.stroke();
    ctx.fillText(lab, L.x1+7, y);
  }
  /* اگر برچسب‌ها در ستون فعلی جا نمی‌شوند، ستون را پهن کن و یک بار دوباره بکش */
  const want = Math.max(W<560?52:62, Math.ceil(widest)+12);
  if(!relaying && Math.abs(want-GUTTER)>1){
    GUTTER = want; relaying = true;
    try { draw(); } finally { relaying = false; }
    return;
  }

  /* خط صفر برای سری‌های دوعلامته */
  if(!indexed && plot[0].meta.signed && lo<0 && hi>0){
    const y=Math.round(yAt(0))+.5;
    ctx.strokeStyle=css("--edge"); ctx.beginPath();
    ctx.moveTo(L.x0,y); ctx.lineTo(L.x1,y); ctx.stroke();
  }

  /* علامت تعطیلی بازار */
  ctx.save(); ctx.setLineDash([2,4]); ctx.strokeStyle=line;
  for(let i=Math.max(1,state.i0);i<=state.i1;i++){
    if(gapDays(i) > 10 * frame().per){
      const x=Math.round(xAt(i-0.5,L))+.5;
      ctx.beginPath(); ctx.moveTo(x,L.mainTop); ctx.lineTo(x,L.bottom); ctx.stroke();
    }
  }
  ctx.restore();

  /* ---- پنل پایین ---- */
  const slot=(L.x1-L.x0)/Math.max(1,(state.i1-state.i0+1));
  const bw=Math.max(1, slot-2);            // ۲ پیکسل فاصلهٔ سطح بین میله‌ها
  const rad=bw>=6?3:0;

  if(PL.panel==="volume" && L.hasPanel){
    /* ارزش معاملات، رنگ بر اساس جهت جریان پول */
    const vol=DATA.value_retail, flow=DATA.flow_retail;
    let vmax=0; for(let i=state.i0;i<=state.i1;i++) if(vol[i]!=null&&vol[i]>vmax) vmax=vol[i];
    if(vmax>0){
      for(let i=state.i0;i<=state.i1;i++){
        const v=vol[i]; if(v==null) continue;
        const h=(v/vmax)*(L.panelBot-L.panelTop);
        const f=flow[i];
        ctx.fillStyle = f==null ? css("--edge") : (f>=0?up:down);
        ctx.globalAlpha=.4;
        ctx.fillRect(xAt(i,L)-bw/2, L.panelBot-h, bw, h);
      }
      ctx.globalAlpha=1;
      ctx.fillStyle=muted; ctx.textAlign="right";
      ctx.font='10px Vazirmatn,system-ui,sans-serif';
      if(W>=560) ctx.fillText("ارزش معاملات خرد", L.x1-6, L.panelTop+7);
      ctx.font='11px Vazirmatn,system-ui,sans-serif';
    }
  }

  if(PL.panel==="flow" && L.hasPanel){
    /* خالص ورود پول حقیقی — میلهٔ دوسویه حول خط صفر */
    const flow=DATA.flow_retail;
    let flo=0, fhi=0;
    for(let i=state.i0;i<=state.i1;i++){
      const v=flow[i]; if(v==null) continue;
      if(v<flo)flo=v; if(v>fhi)fhi=v;
    }
    if(flo===0&&fhi===0){flo=-1;fhi=1;}
    const padf=(fhi-flo)*0.06; flo-=padf; fhi+=padf;
    const fy = v => L.panelBot - (v-flo)/(fhi-flo)*(L.panelBot-L.panelTop);
    const zy = fy(0);

    for(let i=state.i0;i<=state.i1;i++){
      const v=flow[i]; if(v==null) continue;
      const y=fy(v), top=Math.min(y,zy), h=Math.max(1,Math.abs(y-zy));
      ctx.fillStyle = v>=0?up:down;
      ctx.globalAlpha=.9;
      if(rad){ roundRectPath(xAt(i,L)-bw/2, top, bw, h, rad); ctx.fill(); }
      else ctx.fillRect(xAt(i,L)-bw/2, top, bw, h);
    }
    ctx.globalAlpha=1;
    /* خط صفر */
    ctx.strokeStyle=css("--edge"); ctx.lineWidth=1;
    ctx.beginPath(); ctx.moveTo(L.x0,Math.round(zy)+.5); ctx.lineTo(L.x1,Math.round(zy)+.5); ctx.stroke();
    /* بیشینه و کمینهٔ پنل روی محور راست */
    ctx.fillStyle=muted; ctx.textAlign="left"; ctx.font='10px Vazirmatn,system-ui,sans-serif';
    const ftop=fhi-padf, fbot=flo+padf;
    const yTop=Math.max(L.panelTop+6, fy(ftop)), yBot=Math.min(L.panelBot-6, fy(fbot));
    ctx.fillText(nice(ftop,0), L.x1+7, yTop);
    ctx.fillText(nice(fbot,0), L.x1+7, yBot);
    if(Math.abs(zy-yTop)>11 && Math.abs(zy-yBot)>11) ctx.fillText("0", L.x1+7, zy);
    ctx.textAlign="right";
    if(W>=560) ctx.fillText("خالص ورود پول حقیقی", L.x1-6, L.panelTop+7);
    ctx.font='11px Vazirmatn,system-ui,sans-serif';
  }

  /* ---- پنل RSI ---- */
  if(L.hasRsi){
    const period = rsiPeriod();
    const r = rsiOf(plot[0].a, period);
    const ry = v => L.rsiBot - (v/100)*(L.rsiBot-L.rsiTop);

    /* نوار ۳۰ تا ۷۰: جایی که هیچ سیگنالی نیست */
    ctx.save(); ctx.globalAlpha=.05; ctx.fillStyle=css("--ink");
    ctx.fillRect(L.x0, ry(70), L.x1-L.x0, ry(30)-ry(70)); ctx.restore();

    ctx.save(); ctx.setLineDash([3,3]); ctx.strokeStyle=css("--edge"); ctx.lineWidth=1;
    for(const lv of [30,70]){
      const y=Math.round(ry(lv))+.5;
      ctx.beginPath(); ctx.moveTo(L.x0,y); ctx.lineTo(L.x1,y); ctx.stroke();
    }
    ctx.restore();

    ctx.strokeStyle=S[3]; ctx.lineWidth=1.5;
    ctx.lineJoin="round"; ctx.lineCap="round";
    strokeSeries(r, L, ry);

    ctx.fillStyle=muted; ctx.textAlign="left";
    ctx.font='10px Vazirmatn,system-ui,sans-serif';
    for(const lv of [30,70]) ctx.fillText(String(lv), L.x1+7, ry(lv));
    ctx.textAlign="right";
    if(W>=560) ctx.fillText(`RSI ${pnum(period)}`, L.x1-6, L.rsiTop+7);
    ctx.font='11px Vazirmatn,system-ui,sans-serif';

    /* خط جداکننده بالای پنل */
    ctx.strokeStyle=line; ctx.lineWidth=1;
    ctx.beginPath();
    ctx.moveTo(L.x0,Math.round(L.rsiTop-7)+.5); ctx.lineTo(L.x1,Math.round(L.rsiTop-7)+.5);
    ctx.stroke();

    window.__rsi = {a:r, period};
  } else window.__rsi = null;

  /* ---- میانگین‌های متحرک ---- */
  for(const m of mas){
    ctx.strokeStyle=m.color; ctx.lineWidth=1.5;
    ctx.lineJoin="round"; ctx.lineCap="round";
    strokeSeries(m.a, L, yAt, PL.hole);
  }

  /* ---- VWAP و منحنی رگرسیون ----
     نوارها اول می‌آیند و کم‌رنگ، تا خط قیمت رویشان بنشیند نه زیرشان.
     VWAP در آغاز هر دوره صفر می‌شود، پس خطش باید همان‌جا بشکند — با
     hole=1 هر گسست یک قلم‌برداشتن است. */
  if(OV.vwap){
    const cv = css("--s5");
    ctx.save();
    ctx.globalAlpha=.42; ctx.setLineDash([4,3]); ctx.lineWidth=1.2; ctx.strokeStyle=cv;
    strokeSeries(OV.vwap.up, L, yAt, 1);
    strokeSeries(OV.vwap.dn, L, yAt, 1);
    ctx.restore();
    ctx.strokeStyle=cv; ctx.lineWidth=1.8;
    ctx.lineJoin="round"; ctx.lineCap="round";
    strokeSeries(OV.vwap.mid, L, yAt, 1);
  }
  if(OV.lrc){
    ctx.strokeStyle=css("--s4"); ctx.lineWidth=1.8;
    ctx.lineJoin="round"; ctx.lineCap="round";
    strokeSeries(OV.lrc.a, L, yAt, PL.hole);
  }
  if(OV.lrc2){
    ctx.strokeStyle=css("--s6"); ctx.lineWidth=1.8;
    ctx.lineJoin="round"; ctx.lineCap="round";
    strokeSeries(OV.lrc2.a, L, yAt, PL.hole);
    /* تقاطع‌ها: حلقهٔ توخالی روی نقطهٔ تغییر علامت. توخالی است تا خط
       زیرش دیده شود و معلوم بماند کدام از کدام رد شده. رنگ جهت را
       می‌گوید: سبز یعنی پنجرهٔ کوتاه‌تر از پایین به بالا رفته. */
    const short = OV.lrc.win <= OV.lrc2.win ? OV.lrc.a : OV.lrc2.a;
    const long  = OV.lrc.win <= OV.lrc2.win ? OV.lrc2.a : OV.lrc.a;
    const xs = crossings(short, long, state.i0, state.i1);
    /* روی کل تاریخچه دویست‌وپنجاه تقاطع در دید است و حلقه‌ها یک نوار
       توپُر می‌سازند که هیچ نمی‌گوید. از یک حدی به بالا کشیده نمی‌شوند و
       لجند می‌گوید چندتاست و برای دیدنشان باید بزرگ‌نمایی کرد. خودِ
       فهرست سر جایش می‌ماند، پس راهنمای شناور هنوز تقاطع را می‌گوید. */
    window.__crossHidden = xs.length > MAX_CROSS_MARKS ? xs.length : 0;
    if(!window.__crossHidden){
      ctx.save(); ctx.lineWidth=2;
      for(const c of xs){
        const x=xAt(c.i,L), y=yAt((short[c.i]+long[c.i])/2);
        ctx.strokeStyle = c.up ? up : down;
        ctx.fillStyle = surf;
        ctx.beginPath(); ctx.arc(x,y,4.5,0,7); ctx.fill(); ctx.stroke();
      }
      ctx.restore();
    }
    window.__cross = xs;
  } else { window.__cross = null; window.__crossHidden = 0; }

  /* ---- خطوط اصلی ---- */
  plot.forEach((p,pi)=>{
    if(PL.bars && pi===0){
      const slotW=(L.x1-L.x0)/Math.max(1,(state.i1-state.i0+1));
      const wOut=Math.max(1, slotW-2);
      const wIn=Math.max(1, wOut*0.46);
      const rr=wOut>=6?2:0;
      const zero=yAt(0);
      const fl=FS(PL.barFlow||BAR_FLOW)||[];
      for(let i=state.i0;i<=state.i1;i++){
        const v=p.a[i]; if(v==null) continue;
        const x=xAt(i,L), yv=yAt(v), h=Math.max(1, zero-yv);
        ctx.fillStyle=css("--ink"); ctx.globalAlpha=.8;
        if(rr){ roundRectPath(x-wOut/2, yv, wOut, h, rr); ctx.fill(); }
        else ctx.fillRect(x-wOut/2, yv, wOut, h);
        const f=fl[i];
        if(f!=null && f!==0){
          /* ستون داخلی از همان کف صفر بالا می‌آید و رنگش جهت را می‌گوید.
             قدرمطلق گرفته می‌شود چون خروج پول هم باید دیده شود، نه اینکه
             زیر خط صفر برود و از کادر بیرون بزند. */
          const fh=Math.max(1, zero-yAt(Math.abs(f)));
          ctx.fillStyle = f>0?up:down; ctx.globalAlpha=1;
          ctx.fillRect(x-wIn/2, zero-fh, wIn, Math.min(fh,h));
        }
      }
      ctx.globalAlpha=1;
      return;
    }
    const Y = yOf(pi);
    ctx.strokeStyle=p.color; ctx.lineWidth=2;
    ctx.lineJoin="round"; ctx.lineCap="round";
    strokeSeries(p.a, L, Y, PL.hole);

    let last=null; for(let i=state.i1;i>=state.i0;i--){ if(p.a[i]!=null){last=i;break;} }
    if(last!=null){
      const x=xAt(last,L), y=Y(p.a[last]);
      ctx.fillStyle=p.color; ctx.beginPath(); ctx.arc(x,y,3,0,7); ctx.fill();
      /* برچسب انتهای خط فقط وقتی جا دارد؛ وگرنه راهنمای بالای نمودار کافی است */
      if(indexed || plot.length>1){
        ctx.textAlign="right";
        const w=ctx.measureText(p.meta.n).width;
        if(x-10-w > L.x0+4) ctx.fillText(p.meta.n, x-10, y);
      }
    }
  });

  /* محور عمودی دوم — داخل کادر و به رنگ خودِ سری، تا معلوم باشد این
     عددها مال کدام خط‌اند. بیرونِ کادر جا نبود: ستون راست برای محور
     اول است و چپ هم حاشیهٔ صفحه. */
  if(dual){
    ctx.save();
    ctx.fillStyle=plot[1].color; ctx.textAlign="left";
    ctx.font='10px Vazirmatn,system-ui,sans-serif';
    for(const tk of ticks(lo2,hi2,4)){
      const y=Math.round(yAt2(tk))+.5;
      if(y<L.mainTop+8||y>L.mainBot-2) continue;
      ctx.fillText(nice(tk, plot[1].meta.dec), L.x0+6, y);
    }
    ctx.restore();
    ctx.font='11px Vazirmatn,system-ui,sans-serif';
  }

  /* برچسب محور افقی.
     در بازهٔ هفتگی و ماهانه، برچسب‌ها روی خودِ نقاط نمونه می‌نشینند و
     نام ماه را می‌نویسند («مهر»، «هفته دوم مهر») نه «۱۴۰۵/۰۷». چون
     این برچسب‌ها پهن‌اند، به‌جای گامِ ثابت، هر کدام را فقط وقتی
     می‌نویسیم که با برچسب قبلی برخورد نکند. */
  ctx.fillStyle=muted; ctx.textAlign="center";
  if(PL.labels){
    let right = -1e9, lastYear = null;
    for(let i=state.i0;i<=state.i1;i++){
      const rec = PL.labels[i];
      if(!rec) continue;
      const txt = stepLabel(rec, rec.y !== lastYear);
      const half = ctx.measureText(txt).width/2;
      const x = xAt(i,L);
      if(x-half < L.x0+4 || x+half > L.x1-4) continue;
      if(x-half < right + 10) continue;
      ctx.fillText(txt, x, L.bottom+13);
      right = x+half; lastYear = rec.y;
    }
  } else {
    const nLab=W<560?3:(W<820?4:6);
    const span=state.i1-state.i0, step=Math.max(1,Math.round(span/nLab));
    let prev="";
    for(let i=state.i0;i<=state.i1;i+=step){
      const d=FD(i), lab=`${d.slice(0,4)}/${d.slice(4,6)}`;
      if(lab===prev) continue; prev=lab;
      const x=xAt(i,L);
      if(x>L.x0+18 && x<L.x1-18) ctx.fillText(lab, x, L.bottom+13);
    }
  }

  /* نشانگر متقاطع */
  if(state.hover>=state.i0 && state.hover<=state.i1){
    const x=Math.round(xAt(state.hover,L))+.5;
    ctx.save(); ctx.setLineDash([3,3]); ctx.strokeStyle=css("--edge");
    ctx.beginPath(); ctx.moveTo(x,L.mainTop); ctx.lineTo(x,L.bottom); ctx.stroke();
    ctx.restore();
    for(const p of plot){
      const v=p.a[state.hover]; if(v==null) continue;
      const y=yAt(v);
      ctx.fillStyle=surf; ctx.strokeStyle=p.color; ctx.lineWidth=2;
      ctx.beginPath(); ctx.arc(x,y,4,0,7); ctx.fill(); ctx.stroke();
    }
  }

  /* خط جداکنندهٔ پنل‌ها */
  if(L.hasPanel){
    ctx.strokeStyle=line; ctx.lineWidth=1;
    ctx.beginPath();
    ctx.moveTo(L.x0,Math.round(L.panelTop-7)+.5); ctx.lineTo(L.x1,Math.round(L.panelTop-7)+.5);
    ctx.stroke();
  }

  window.__mas = mas;      // برای راهنمای شناور
  window.__ov = OV;
  /* شمارش تقاطع‌ها تازه همین‌جا معلوم شد، ولی لجند قبل از رسم ساخته
     می‌شود. اگر وضعیت عوض شده باشد یک بار دیگر ساخته می‌شود — syncChips
     خودش draw صدا نمی‌زند، پس حلقه نمی‌شود. */
  if(window.__crossShown !== window.__crossHidden){
    window.__crossShown = window.__crossHidden;
    syncChips();
  }
  updateQuote(indexed);
}

/* ---------- سربرگ عددی ---------- */
function updateQuote(indexed){
  const V=view(), k=state.key, a=FS(k)||[], m=fa(k)||{n:k, u:"", dec:0};
  let last=null; for(let i=FN()-1;i>=0;i--){ if(a[i]!=null){last=i;break;} }
  document.getElementById("title").textContent =
    (V.free && state.cmpMode && state.compare.length>1) ? "مقایسه سری‌ها (پایه ۱۰۰)"
    : (V.indBars ? indTitle() : (V.title || m.n || ""));
  if(last==null) return;
  let prev=null; for(let i=last-1;i>=0;i--){ if(a[i]!=null){prev=i;break;} }
  const v=a[last], p=prev!=null?a[prev]:null;
  document.getElementById("qval").textContent=niceK(v,k);
  const chg=document.getElementById("qchg");
  if(p!=null && p!==0){
    const d=v-p, pc=d/Math.abs(p)*100;
    chg.textContent=`${d>=0?"+":"−"}${niceK(Math.abs(d),k)} (${d>=0?"+":"−"}${Math.abs(pc).toFixed(2)}٪)`;
    chg.className="chg "+(d>=0?"up":"down");
  } else { chg.textContent=""; chg.className="chg"; }
  document.getElementById("qasof").textContent=`${jDate(FD(last))} · ${m.u||""}`;
  document.getElementById("count").textContent=
    `${state.i1-state.i0+1} ${frame().unit} از ${FN()} · `
    + `${jDate(FD(state.i0))} تا ${jDate(FD(state.i1))}`;
}

/* ---------- راهنمای شناور ---------- */
function showTip(px,py){
  const i=state.hover;
  if(i<0){ tip.style.opacity=0; return; }
  const PL=plan(), S=PAL();
  let html=`<div class="d">${jDate(FD(i))}</div>`;

  if(view().lines){
    /* هر سریِ این نما با مقدار و واحدش، و درصد تغییرش نسبت به نقطهٔ
       دادهٔ قبلی (که معمولاً روز قبل است؛ روز تعطیل در میان باشد،
       آخرین روزِ دارای داده). */
    PL.keys.forEach((k,idx)=>{
      const m=fa(k)||{n:k}, a=FS(k), v=a?a[i]:null;
      if(v==null) return;
      html+=`<div class="r"><span class="dot" style="background:${S[idx%3]}"></span>`+
            `<span class="n">${m.n}</span>`+
            `<span class="v">${nice(v, m.dec||0)}`
            + (m.u?`<i class="u"> ${m.u}</i>`:"") + pctSince(a,i) + `</span></div>`;
    });
    tip.innerHTML=html;
    tip.style.opacity=1;
    const r0=tip.getBoundingClientRect();
    let x0=px+14; if(x0+r0.width>W-6) x0=px-r0.width-14;
    let y0=py-r0.height/2; y0=Math.max(4,Math.min(H-r0.height-4,y0));
    tip.style.left=x0+"px"; tip.style.top=y0+"px";
    return;
  }

  /* مقدار از *قاب فعال* خوانده می‌شود نه از DATA: سری‌های هفتگی و
     ماهانهٔ نسبت نقدینگی اصلاً در DATA نیستند و قاب خودشان را دارند.
     پیش از این `DATA[k][i]` بود و روی آن دو بازه راهنما را می‌شکست. */
  PL.keys.forEach((k,idx)=>{
    const m=fa(k)||{n:k}, a=FS(k), v=a?a[i]:null;
    if(v==null) return;
    html+=`<div class="r"><span class="dot" style="background:${S[idx%3]}"></span>`+
          `<span class="n">${m.n}</span><span class="v">${niceK(v,k)}`
          + pctSince(a,i) + `</span></div>`;
  });
  const R=window.__rsi;
  if(R && R.a[i]!=null){
    html+=`<div class="r"><span class="dot" style="background:${S[3]}"></span>`+
          `<span class="n">RSI ${pnum(R.period)}</span>`+
          `<span class="v">${R.a[i].toFixed(1)}</span></div>`;
  }
  for(const m of (window.__mas||[])){
    if(m.a[i]==null) continue;
    html+=`<div class="r"><span class="dot" style="background:${m.color}"></span>`+
          `<span class="n">${(PL.maKind==="ema"?"EMA ":"MA ")+pnum(m.p)}</span>`+
          `<span class="v">${niceK(m.a[i],PL.keys[0])}</span></div>`;
  }
  const OV = window.__ov || {};
  if(OV.vwap && OV.vwap.mid[i]!=null){
    const nm = (VWAP_ANCHORS.find(x=>x.id===OV.vwap.anchor)||{}).n || "";
    const v = OV.vwap.mid[i], k = PL.keys[0];
    html+=`<div class="r"><span class="dot" style="background:${css("--s5")}"></span>`+
          `<span class="n">VWAP ${nm}</span><span class="v">${niceK(v,k)}</span></div>`;
    if(OV.vwap.up[i]!=null)
      html+=`<div class="r"><span class="dot" style="background:${css("--s5")};opacity:.35"></span>`+
            `<span class="n">نوار ±${pnum(OV.vwap.k)}σ</span>`+
            `<span class="v">${niceK(OV.vwap.dn[i],k)} … ${niceK(OV.vwap.up[i],k)}</span></div>`;
    /* فاصلهٔ قیمت از VWAP بر حسب انحراف معیار — همان چیزی که آدم با چشم
       از پهنای نوار حدس می‌زند، این‌جا عددش هست. */
    const p = (FS(k)||[])[i], sd = OV.vwap.up[i]!=null ? (OV.vwap.up[i]-v)/OV.vwap.k : 0;
    if(p!=null && sd>0){
      const z = (p - v)/sd;
      html+=`<div class="r"><span class="dot" style="background:var(--edge)"></span>`+
            `<span class="n">فاصله از VWAP</span>`+
            `<span class="v">${z>=0?"+":"−"}${Math.abs(z).toFixed(2)}σ</span></div>`;
    }
  }
  if(OV.lrc && OV.lrc.a[i]!=null){
    html+=`<div class="r"><span class="dot" style="background:${css("--s4")}"></span>`+
          `<span class="n">LRC ${pnum(OV.lrc.win)}</span>`+
          `<span class="v">${niceK(OV.lrc.a[i],PL.keys[0])}</span></div>`;
  }
  if(OV.lrc2 && OV.lrc2.a[i]!=null){
    html+=`<div class="r"><span class="dot" style="background:${css("--s6")}"></span>`+
          `<span class="n">LRC ${pnum(OV.lrc2.win)}</span>`+
          `<span class="v">${niceK(OV.lrc2.a[i],PL.keys[0])}</span></div>`;
    /* اگر همین روز تقاطع بوده، بگو — وگرنه حلقهٔ روی نمودار بی‌توضیح است */
    const hit = (window.__cross||[]).find(c=>c.i===i);
    if(hit)
      html+=`<div class="r"><span class="dot" style="background:${hit.up?css("--up"):css("--down")}"></span>`+
            `<span class="n">تقاطع</span>`+
            `<span class="v">${hit.up ? "کوتاه از پایین به بالا" : "کوتاه از بالا به پایین"}</span></div>`;
  }
  /* ورود/خروج پول: در نمای بازار «ورود پول حقیقی» بازار، و در نمای
     ارزش معاملات صنایع همان سری برای همان صنعت. */
  const fKey = PL.barFlow || BAR_FLOW, fArr = FS(fKey);
  if((PL.panel==="flow" || PL.bars) && !PL.keys.includes(fKey)
     && fArr && fArr[i]!=null){
    const f=fArr[i], vv=(FS(PL.bars ? PL.keys[0] : BAR_SERIES)||[])[i];
    const fn=(fa(fKey)||{}).n || "ورود پول";
    html+=`<div class="r"><span class="dot" style="background:${f>=0?css("--up"):css("--down")}"></span>`+
          `<span class="n">${f>=0?fn:fn.replace("ورود","خروج")}</span>`+
          `<span class="v">${nice(Math.abs(f),0)}`
          + (vv ? `<i class="u"> ${(Math.abs(f)/vv*100).toFixed(1)}٪ گردش</i>` : "")
          + `</span></div>`;
  }
  if(PL.panel==="volume" && !PL.keys.includes("value_retail") && DATA.value_retail[i]!=null)
    html+=`<div class="r"><span class="dot" style="background:${css("--edge")}"></span>`+
          `<span class="n">ارزش معاملات</span><span class="v">${nice(DATA.value_retail[i],0)}</span></div>`;
  tip.innerHTML=html;
  tip.style.opacity=1;
  const r=tip.getBoundingClientRect();
  let x=px+14; if(x+r.width>W-6) x=px-r.width-14;
  let y=py-r.height/2; y=Math.max(4,Math.min(H-r.height-4,y));
  tip.style.left=x+"px"; tip.style.top=y+"px";
}

/* ---------- تعامل ---------- */
function clampView(){
  const minSpan=12;
  if(state.i1-state.i0<minSpan){
    const c=(state.i0+state.i1)/2;
    state.i0=Math.round(c-minSpan/2); state.i1=state.i0+minSpan;
  }
  if(state.i0<0){ state.i1-=state.i0; state.i0=0; }
  const n=FN();
  if(state.i1>n-1){ state.i0-=(state.i1-(n-1)); state.i1=n-1; }
  state.i0=Math.max(0,Math.round(state.i0)); state.i1=Math.min(n-1,Math.round(state.i1));
}
let drag=null;
stage.addEventListener("pointerdown",e=>{
  stage.setPointerCapture(e.pointerId);
  drag={x:e.offsetX, i0:state.i0, i1:state.i1};
});
stage.addEventListener("pointermove",e=>{
  const L=layout();
  if(drag){
    const bars=(e.offsetX-drag.x)/(L.x1-L.x0)*(drag.i1-drag.i0);
    state.i0=drag.i0+bars; state.i1=drag.i1+bars;
    clampView(); draw(); return;
  }
  const i=Math.round(iAt(e.offsetX,L));
  state.hover=(i>=state.i0&&i<=state.i1)?i:-1;
  draw(); showTip(e.offsetX,e.offsetY);
});
const endDrag=()=>{ drag=null; };
stage.addEventListener("pointerup",endDrag);
stage.addEventListener("pointercancel",endDrag);
stage.addEventListener("pointerleave",()=>{ drag=null; state.hover=-1; tip.style.opacity=0; draw(); });
stage.addEventListener("wheel",e=>{
  e.preventDefault();
  const L=layout(), anchor=iAt(e.offsetX,L);
  const f=e.deltaY>0?1.12:1/1.12;
  state.i0=anchor-(anchor-state.i0)*f;
  state.i1=anchor+(state.i1-anchor)*f;
  clampView(); draw();
},{passive:false});
stage.addEventListener("dblclick",()=>{ state.i0=0; state.i1=FN()-1; draw(); });

/* ---------- کنترل‌ها ---------- */
const viewsRow=document.getElementById("views");
VIEWS.forEach(v=>{
  const b=document.createElement("button");
  b.type="button"; b.textContent=v.tab; b.dataset.v=v.id;
  b.setAttribute("aria-pressed", v.id===state.view?"true":"false");
  b.addEventListener("click",()=>setView(v.id));
  viewsRow.appendChild(b);
});

const seriesRow=document.getElementById("series");
/* سری‌هایی با hide:true چیپ نمی‌گیرند — اجزای ارزش بازار و نسبت نقدینگی
   تب اختصاصی خودشان را دارند و اینجا فقط شلوغی می‌سازند. */
SERIES.filter(s=>!s.hide).forEach(s=>{
  const b=document.createElement("button");
  b.className="chip"; b.type="button"; b.dataset.k=s.k;
  b.innerHTML=`<span class="dot" style="background:var(--s1)"></span>${s.n}`;
  b.setAttribute("aria-pressed", s.k===state.key ? "true":"false");
  b.addEventListener("click",()=>{
    if(state.cmpMode){
      const i=state.compare.indexOf(s.k);
      if(i>=0) state.compare.splice(i,1);
      else if(state.compare.length<3) state.compare.push(s.k);
      if(state.compare.length) state.key=state.compare[0];
    } else {
      state.key=s.k; state.compare=[s.k];
    }
    syncChips(); draw();
  });
  seriesRow.appendChild(b);
});

const rangeRow=document.getElementById("ranges");
RANGES.forEach((r,idx)=>{
  const b=document.createElement("button");
  b.type="button"; b.textContent=r.n; b.dataset.d=r.d;
  b.setAttribute("aria-pressed", r.d===250 ? "true":"false");
  b.addEventListener("click",()=>{ applyRange(r.d); markRange(idx); draw(); });
  rangeRow.appendChild(b);
});
function markRange(idx){
  rangeRow.querySelectorAll("button").forEach((x,j)=>x.setAttribute("aria-pressed", j===idx?"true":"false"));
}
/* بازه به آخرین روزی ختم می‌شود که سری جاری داده دارد، نه آخرین روز جدول.
   سری‌ها هم‌طول نیستند — ارزش بازار تا امروز می‌آید، شاخص‌ها چند روز عقب‌ترند —
   و بدون این، سمت راست نمودار خالی می‌ماند. */
/* بازه‌ها به «روز معاملاتی» تعریف شده‌اند (۲۵۰ ≈ یک سال). روی قاب
   هفتگی و ماهانه بر طول دورهٔ همان قاب تقسیم می‌شوند، وگرنه «۱ سال»
   روی نمودار ماهانه می‌شد دویست‌وپنجاه ماه. */
function applyRange(d){
  const keys = (state.cmpMode && state.compare.length) ? state.compare : [state.key];
  const end = Math.max(...keys.map(lastValid));
  d = d ? Math.max(8, Math.round(d / frame().per)) : 0;
  state.i1=end;
  state.i0 = d ? Math.max(0,end-d+1) : 0;
  clampView();
}

function setView(id){
  state.view=id;
  const V=view();
  const isSheet = !!V.sheet;
  const isFlow = !!V.flow;
  stage.hidden = isSheet;
  sheetEl.hidden = !isSheet || isFlow;
  flowEl.hidden = !isFlow;
  document.getElementById("rangeRow").hidden = isSheet;
  document.querySelector(".foot").hidden = isSheet;
  document.getElementById("title").textContent = V.title || "";
  indPick.hidden = indPickLabel.hidden = !V.ind;
  viewsRow.querySelectorAll("button").forEach(b=>
    b.setAttribute("aria-pressed", b.dataset.v===id?"true":"false"));
  if(isSheet){
    syncChips(); syncMaRow(); syncRsiRow(); syncOvRow();
    if(isFlow){ ensureFlow(); return; }  // ensureFlow خودش پنل را می‌سازد
    if(V.ind){ ensureInd(); return; }   // ensureInd خودش جدول را می‌سازد
    renderSheet();
    return;
  }
  /* نمودار صنعت تا فایلش نیاید نمی‌تواند رسم شود، پس بقیهٔ کار را
     ensureIndChart بعد از گرفتن داده انجام می‌دهد. */
  if(V.indBars){ ensureIndChart(); return; }
  if(!V.free){
    state.key = V.resample ? ratioKey() : V.key;
    state.compare=[state.key]; state.cmpMode=false;
  }
  applyRange(V.free?0:250);
  markRange(V.free?5:3);
  syncChips(); syncMaRow(); syncRsiRow(); syncOvRow(); draw();
}

document.getElementById("cmp").addEventListener("click",e=>{
  state.cmpMode=!state.cmpMode;
  if(state.cmpMode && state.compare.length<2){
    state.compare=[state.key, state.key==="index_total"?"index_ew":"index_total"];
  }
  e.currentTarget.setAttribute("aria-pressed", state.cmpMode?"true":"false");
  syncChips(); draw();
});

const legendRow=document.getElementById("legend");
function syncChips(){
  const V=view(), S=PAL();
  if(V.sheet){
    seriesRow.hidden = legendRow.hidden = true;
    pickRow.hidden = true;
    document.getElementById("cmp").hidden = true;
    maRow.hidden = true;
    document.querySelector(".quote").hidden = true;
    if(V.ind) indChipState();
    return;
  }
  document.querySelector(".quote").hidden = false;
  const free=!!V.free;

  /* در نمای کلی کشویی کار می‌کند؛ چیپ‌ها فقط در حالت مقایسه برمی‌گردند
     چون آن‌جا باید دو-سه سری با هم انتخاب شوند. */
  const pickMode = free && !state.cmpMode;
  const indMode  = !!V.indBars;
  seriesRow.hidden = !free || pickMode;
  pickRow.hidden = !(pickMode || V.resample || indMode);
  serPick.hidden = serPickLabel.hidden = !pickMode;
  indChartPick.hidden = indChartLabel.hidden = !indMode;
  if(indMode && state.ind) indChartPick.value = state.ind;
  if(pickMode && serPick.value !== state.key) serPick.value = state.key;
  syncStepRow();
  document.getElementById("cmp").hidden = !free;

  seriesRow.querySelectorAll(".chip").forEach(b=>{
    const k=b.dataset.k;
    const on = state.cmpMode ? state.compare.includes(k) : k===state.key;
    b.setAttribute("aria-pressed", on?"true":"false");
    const idx = state.cmpMode ? state.compare.indexOf(k) : 0;
    b.querySelector(".dot").style.background = on ? S[Math.max(0,idx)%3] : "var(--edge)";
  });

  /* در نمای کلی لجند معمولاً حذف است، چون چیپ‌ها خودشان می‌گویند چه رسم
     شده. ولی وقتی اندیکاتوری روشن است دو خط رنگی اضافه روی نمودار هست
     که چیپ‌ها توضیحشان نمی‌دهند — آن‌وقت لجند برمی‌گردد. */
  const ovAny = !!lrcOn() || (!!vwapOn() && !!weightKey(plan().keys[0]));
  legendRow.hidden = free && !ovAny;
  if(free && !ovAny) return;
  /* لجند کامل نوشته می‌شود: نام بلندِ سری (اگر داشته باشد) به‌علاوهٔ
     واحدش، و میانگین‌ها با عبارت فارسی به‌جای «EMA 28». نام چیپ‌ها کوتاه
     است چون باید در یک خط جا شود؛ لجند این محدودیت را ندارد. */
  /* واحد با خط تیره می‌آید نه پرانتز: بعضی نام‌های کامل خودشان پرانتز
     دارند («ارزش کل بازار (بورس + فرابورس)») و دو پرانتز پشت هم بد
     خوانده می‌شد. */
  const fullName = k => { const s=fa(k)||{}; return (s.fn||s.n||k) + (s.u?` — ${s.u}`:""); };
  const maName = p => (state.maKind==="ema" ? "میانگین نمایی " : "میانگین ساده ")
                      + pnum(p) + (V.resample && state.ratioStep!=="d" ? " دوره‌ای" : " روزه");
  const items=[]; const note=V.note;
  const P=plan();
  if(V.lines){
    V.lines.forEach((k,j)=>items.push([S[j%3], fullName(k), "line"]));
  } else {
    const mainKey = V.resample ? ratioKey() : (P.keys[0] || V.key || "");
    /* در حالت ستونی سری اصلی خط نیست؛ خودش پایین‌تر به‌شکل ستون معرفی
       می‌شود و این‌جا فقط دو بار یک نام می‌شد. */
    if(!P.bars) items.push([S[0], fullName(mainKey), "line"]);
    maPeriods().forEach((p,j)=>items.push([S[(j+1)%3], maName(p), "line"]));
  }
  if(P.bars){
    /* نام از خودِ سری خوانده می‌شود، پس در تب صنایع می‌نویسد «ارزش
       معاملات — فلزات اساسی» نه «ارزش معاملات خرد». */
    /* این‌جا نام کوتاه می‌آید نه نام کامل: نام صنعت بالای نمودار نوشته
       شده و واحد هم کنار عدد سربرگ است، پس «ارزش معاملات — صندوق طلا —
       میلیارد تومان — ستون بیرونی» سه خط تیره می‌شد. */
    const inN  =(fa(P.barFlow)||{}).n || "ورود پول";
    const outN =(fa(P.keys[0])||{}).n || "ارزش معاملات";
    items.push([css("--ink"), `${outN} — ستون بیرونی`, "box"]);
    items.push([css("--up"),  `${inN} — ستون داخلی`, "box"]);
    items.push([css("--down"), `${inN.replace("ورود","خروج")} — ستون داخلی`, "box"]);
  } else if(V.panel==="flow"){
    items.push([css("--up"),"ورود پول (مثبت)","box"]);
    items.push([css("--down"),"خروج پول (منفی)","box"]);
  }
  /* اندیکاتورها، اگر روشن باشند */
  const vw = vwapOn(), wk = vw && weightKey(P.keys[0]);
  if(vw && wk){
    const an = (VWAP_ANCHORS.find(x=>x.id===vw.anchor)||{}).n || "";
    items.push([css("--s5"),
      `VWAP ${an} — میانگین وزنیِ قیمت به ${(fa(wk)||{}).n || "ارزش معاملات"}`, "line"]);
    items.push([css("--s5"), `نوار ±${pnum(vw.k)} انحراف معیار وزنی`, "line"]);
  }
  const lw = lrcOn();
  if(lw){
    items.push([css("--s4"), `منحنی رگرسیون خطی — پنجرهٔ ${pnum(lw.a)} روزه`, "line"]);
    if(lw.b && lw.b !== lw.a){
      items.push([css("--s6"), `منحنی رگرسیون خطی — پنجرهٔ ${pnum(lw.b)} روزه`, "line"]);
      if(window.__crossHidden)
        items.push([css("--edge"),
          `${pnum(window.__crossHidden)} تقاطع در این بازه — برای دیدن نشانه‌ها بزرگ‌نمایی کنید`, "box"]);
      else {
        items.push([css("--up"), "تقاطع رو به بالا", "box"]);
        items.push([css("--down"), "تقاطع رو به پایین", "box"]);
      }
    }
  }
  legendRow.innerHTML = items.map(([c,n,kind])=>
    `<span class="it"><span class="sw${kind==="box"?" box":""}" style="background:${c}"></span>${n}</span>`
  ).join("") + (note?`<span class="note">${note}</span>`:"");


}



/* ================= جدول داده‌ها =================
   ۷٬۷۲۱ ردیف در DOM مرورگر را می‌خواباند، پس فقط ردیف‌های داخل دید ساخته
   می‌شوند و بقیه با یک فاصله‌گذارِ ارتفاع‌دار شبیه‌سازی می‌شوند. */
const SHEET_COLS = SERIES.filter(s => DATA[s.k]);
const ROW_H = 27;

/* جدول دو ارباب دارد: تب «جدول» که همهٔ سری‌های بازار را می‌دهد و تب
   «صنایع» که سیزده ستونِ یک صنعت را. پس ستون‌ها و ردیف‌ها تابع‌اند نه
   ثابت، و سرستون هر بار از نو نوشته می‌شود. */
function curCols(){
  const V = view();
  if(V.ind) return indCols();
  return SHEET_COLS;
}
function curRows(){
  const V = view();
  if(V.ind) return indRows();
  return SHEET_ROWS;
}
const sheetEl = document.getElementById("sheet");
const scrollEl = document.getElementById("sheetScroll");
const bodyEl = document.getElementById("sheetBody");
const headEl = document.getElementById("sheetHead");

/* جدیدترین روز بالا — چیزی که معمولاً دنبالش هستید */
const SHEET_ROWS = Array.from({length:N}, (_,i)=>N-1-i);

const countEl = document.getElementById("sheetCount");

function renderSheet(){
  const cols = curCols(), rows = curRows();
  headEl.innerHTML = "<tr><th>تاریخ</th>" + cols.map(c =>
    `<th>${c.n}<span class="unit">${c.u||"—"}</span></th>`).join("") + "</tr>";
  countEl.textContent = rows.length
    ? `${rows.length.toLocaleString("en-US")} روز · `
      + `${jDate(DATA.d[rows[rows.length-1]])} تا ${jDate(DATA.d[rows[0]])}`
    : "دادهٔ این صنعت هنوز نیامده";

  const top = scrollEl.scrollTop, h = scrollEl.clientHeight;
  const first = Math.max(0, Math.floor(top/ROW_H) - 8);
  const last  = Math.min(rows.length, Math.ceil((top+h)/ROW_H) + 8);
  const pad = i => `<tr style="height:${i*ROW_H}px"><td colspan="${cols.length+1}"></td></tr>`;
  let html = first ? pad(first) : "";
  for(let r=first;r<last;r++){
    const i = rows[r];
    html += `<tr><td>${jDate(DATA.d[i])}</td>` + cols.map(c=>{
      const a = DATA[c.k], v = a ? a[i] : null;
      return v==null ? '<td class="none">—</td>' : `<td>${nice(v, c.dec)}</td>`;
    }).join("") + "</tr>";
  }
  const restRows = rows.length - last;
  if(restRows>0) html += pad(restRows);
  bodyEl.innerHTML = html;
}
scrollEl.addEventListener("scroll", ()=>{ const V=view(); if(V.sheet && !V.flow) renderSheet(); });

/* پریدن به یک تاریخ */
document.getElementById("jump").addEventListener("input", e=>{
  const q = e.target.value.replace(/[^0-9]/g,"");
  if(q.length<4) return;
  /* تاریخ تایپ‌شده ممکن است اصلاً روز معاملاتی نباشد؛ پس نزدیک‌ترین روزِ
     همان تاریخ یا قبل از آن پیدا می‌شود. ردیف‌ها نزولی‌اند، پس اولین
     تاریخی که کوچک‌تر یا مساوی باشد همان است. */
  const key = (q + "00000000").slice(0,8);
  const rows = curRows();
  let hit = rows.findIndex(i => DATA.d[i] <= (q.length>=8 ? q : key.slice(0,q.length)+"99999999".slice(q.length)));
  if(hit<0) hit = rows.length-1;
  scrollEl.scrollTop = hit*ROW_H;
  renderSheet();
});

/* خروجی CSV — با BOM تا اکسل فارسی را درست بخواند.
   صفحه در دو جا اجرا می‌شود: روی گیت‌هاب (لینک دانلود معمولی کار می‌کند) و
   داخل نمایشگر Artifact (که لینک دانلود را نمی‌پذیرد و قابلیت downloads دارد).
   پس اول مسیر Artifact امتحان می‌شود و اگر نبود، مسیر مرورگر. */
function buildCsv(){
  const cols = curCols(), rows = curRows();
  const head = ["تاریخ", ...cols.map(c=>`${c.n} (${c.u||"-"})`)].join(",");
  const lines = [head];
  /* به ترتیب تاریخ صعودی بیرون می‌رود، برعکس جدول — اکسل و نمودارسازها
     این‌طور را می‌خواهند. */
  for(let r=rows.length-1;r>=0;r--){
    const i = rows[r];
    lines.push([DATA.d[i], ...cols.map(c=>{
      const a=DATA[c.k], v=a?a[i]:null; return v==null ? "" : v;
    })].join(","));
  }
  return "\uFEFF" + lines.join("\n");
}

async function saveCsv(filename, text){
  const dl = window.claude?.use ? await window.claude.use("downloads") : null;
  if(dl){
    try { await dl.save({filename, data:text}); }
    catch(err){ if(err?.code && err.code!=="declined") console.warn("downloads:", err.code); }
    return;
  }
  const a=document.createElement("a");
  a.href=URL.createObjectURL(new Blob([text],{type:"text/csv;charset=utf-8"}));
  a.download=filename; a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}

const csvBtn = document.getElementById("csv");
csvBtn.addEventListener("click", async ()=>{
  const V = view();
  const filename = (V.ind && state.ind)
    ? `bourse_ind${state.ind}_${DATA.d[N-1]}.csv`
    : `bourse_${DATA.d[N-1]}.csv`;
  csvBtn.disabled = true;
  try{ await saveCsv(filename, buildCsv()); }
  finally { csvBtn.disabled=false; }
});



/* ================= میانگین‌های متحرک دلخواه ================= */
const maRow   = document.getElementById("maRow");
const maInput = document.getElementById("maInput");
const maKindRow = document.getElementById("maKind");
const maSwatches = document.getElementById("maSwatches");

const pnumList = a => a.map(pnum).join("، ");

function readPeriods(txt){
  /* «۵۰، ۲۰۰» یا «50 200» یا «50,200» — همه قبول */
  const out=[];
  for(const tok of norm(txt).split(/[^0-9]+/)){
    if(!tok) continue;
    const n=parseInt(tok,10);
    if(n>=2 && n<=400 && !out.includes(n)) out.push(n);
    if(out.length>=MAX_MA) break;
  }
  return out;
}
/* ارقام فارسی -> انگلیسی، تا تایپ فارسی هم کار کند */
function norm(t){
  const FA="۰۱۲۳۴۵۶۷۸۹", AR="٠١٢٣٤٥٦٧٨٩";
  return [...String(t)].map(ch=>{
    const i=FA.indexOf(ch); if(i>=0) return i;
    const j=AR.indexOf(ch); if(j>=0) return j;
    return ch;
  }).join("");
}

function syncMaRow(){
  const V=view();
  if(V.sheet){ maRow.hidden=true; return; }
  rsiBtn.hidden = false;
  const indexed = state.cmpMode && state.compare.length>1 && V.free;
  maRow.hidden = indexed;
  if(indexed) return;

  const ps = maPeriods();
  if(document.activeElement !== maInput) maInput.value = pnumList(ps);
  const def = maDefaults();
  maInput.placeholder = pnumList(def.length ? def : (fa(state.key)?.ma) || [50,200]);
  maKindRow.querySelectorAll("button").forEach(b=>
    b.setAttribute("aria-pressed", b.dataset.k===state.maKind ? "true":"false"));
  const S=PAL();
  /* رنگ به‌تنهایی نمی‌گوید کدام دوره کدام است — عدد کنارش می‌آید */
  maSwatches.innerHTML = ps.slice(0,MAX_MA).map((p,j)=>
    `<span class="it"><i style="background:${S[(j+1)%S.length]}"></i>${pnum(p)}</span>`).join("");
}

function applyPeriods(){
  /* کادر خالی یعنی «برگرد به پیش‌فرض همین نما»، نه «هیچ میانگینی» —
     وگرنه پاک‌کردن کادر نمودار را بی‌میانگین می‌کرد و راه برگشتی نبود. */
  const txt = norm(maInput.value).trim();
  state.ma[maKey()] = txt ? readPeriods(txt) : maDefaults();
  syncMaRow(); syncChips(); draw();
}
maInput.addEventListener("change", applyPeriods);
maInput.addEventListener("blur", applyPeriods);
maInput.addEventListener("keydown", e=>{ if(e.key==="Enter"){ e.preventDefault(); maInput.blur(); }});
maKindRow.addEventListener("click", e=>{
  const b=e.target.closest("button"); if(!b) return;
  state.maKind=b.dataset.k; syncMaRow(); syncChips(); draw();
});

/* ================= RSI ================= */
const rsiBtn = document.getElementById("rsiBtn");
const rsiInput = document.getElementById("rsiInput");
const rsiDot = document.getElementById("rsiDot");
const RSI_DEFAULT = 14;

function syncRsiRow(){
  const p = rsiPeriod();
  const on = p != null;
  rsiBtn.setAttribute("aria-pressed", on?"true":"false");
  rsiDot.style.background = on ? PAL()[3] : "var(--edge)";
  rsiInput.hidden = !on;
  if(on && document.activeElement !== rsiInput) rsiInput.value = pnum(p);
}
rsiBtn.addEventListener("click", ()=>{
  state.rsi[state.view] = rsiPeriod()==null ? RSI_DEFAULT : null;
  syncRsiRow(); draw();
});
function applyRsi(){
  const n = readPeriods(rsiInput.value)[0];
  state.rsi[state.view] = n || RSI_DEFAULT;
  syncRsiRow(); draw();
}
rsiInput.addEventListener("change", applyRsi);
rsiInput.addEventListener("blur", applyRsi);
rsiInput.addEventListener("keydown", e=>{ if(e.key==="Enter"){ e.preventDefault(); rsiInput.blur(); }});

/* ================= نوار اندیکاتورها ================= */
const ovRow      = document.getElementById("ovRow");
const vwapBtn    = document.getElementById("vwapBtn");
const vwapDot    = document.getElementById("vwapDot");
const vwapAnchor = document.getElementById("vwapAnchor");
const vwapK      = document.getElementById("vwapK");
const lrcBtn     = document.getElementById("lrcBtn");
const lrcDot     = document.getElementById("lrcDot");
const lrcWin     = document.getElementById("lrcWin");
const lrcWin2    = document.getElementById("lrcWin2");
const ovNote     = document.getElementById("ovNote");

VWAP_ANCHORS.forEach(a=>{
  const o=document.createElement("option"); o.value=a.id; o.textContent=a.n;
  vwapAnchor.appendChild(o);
});
LRC_WINS.forEach(w=>{
  const o=document.createElement("option"); o.value=w.id; o.textContent=w.n;
  lrcWin.appendChild(o);
});
/* منحنی دوم اختیاری است: گزینهٔ خالی یعنی خاموش، و تا وقتی خاموش است
   تقاطعی هم در کار نیست. */
{
  const o=document.createElement("option"); o.value=""; o.textContent="— منحنی دوم —";
  lrcWin2.appendChild(o);
  LRC_WINS.forEach(w=>{
    const x=document.createElement("option"); x.value=w.id; x.textContent=w.n;
    lrcWin2.appendChild(x);
  });
}

function syncOvRow(){
  const V=view();
  if(V.sheet){ ovRow.hidden=true; return; }
  const indexed = state.cmpMode && state.compare.length>1 && V.free;
  ovRow.hidden = indexed;
  if(indexed) return;

  const key = plan().keys[0];
  const wk  = weightKey(key);
  /* VWAP بدون حجم معنی ندارد. به‌جای اینکه دکمه کار کند و خطی نیاید،
     خاموش و خاکستری می‌ماند و کنارش می‌نویسد چرا. */
  vwapBtn.disabled = !wk;
  vwapBtn.style.opacity = wk ? "" : ".45";
  vwapBtn.title = wk ? `وزن: ${(fa(wk)||{}).n||wk}` : "برای این سری ارزش معاملاتی نداریم";

  const v = vwapOn();
  const on = !!v && !!wk;
  vwapBtn.setAttribute("aria-pressed", on?"true":"false");
  vwapDot.style.background = on ? css("--s5") : "var(--edge)";
  vwapAnchor.hidden = vwapK.hidden = !on;
  if(on){
    vwapAnchor.value = v.anchor;
    if(document.activeElement !== vwapK) vwapK.value = pnum(v.k);
  }

  const w = lrcOn();
  lrcBtn.setAttribute("aria-pressed", w?"true":"false");
  lrcDot.style.background = w ? css("--s4") : "var(--edge)";
  lrcWin.hidden = lrcWin2.hidden = !w;
  if(w){
    lrcWin.value = String(w.a);
    lrcWin2.value = w.b ? String(w.b) : "";
  }

  ovNote.textContent = on ? `وزن: ${(fa(wk)||{}).n||""}` : "";
}

vwapBtn.addEventListener("click", ()=>{
  if(vwapBtn.disabled) return;
  state.vwap[state.view] = vwapOn() ? null
    : {anchor:"m", k:VWAP_K_DEFAULT};
  syncOvRow(); syncChips(); draw();
});
vwapAnchor.addEventListener("change", ()=>{
  const v = vwapOn(); if(!v) return;
  state.vwap[state.view] = {anchor:vwapAnchor.value, k:v.k};
  syncOvRow(); syncChips(); draw();
});
function applyVwapK(){
  const v = vwapOn(); if(!v) return;
  /* ضریب اعشاری هم قبول است («۱٫۵»)، ولی readPeriods فقط صحیح می‌دهد */
  const t = norm(vwapK.value).replace(/[٫،]/g, ".").replace(/[^0-9.]/g,"");
  let k = parseFloat(t);
  if(!isFinite(k) || k<=0 || k>6) k = VWAP_K_DEFAULT;
  state.vwap[state.view] = {anchor:v.anchor, k:+k.toFixed(2)};
  syncOvRow(); syncChips(); draw();
}
vwapK.addEventListener("change", applyVwapK);
vwapK.addEventListener("blur", applyVwapK);
vwapK.addEventListener("keydown", e=>{ if(e.key==="Enter"){ e.preventDefault(); vwapK.blur(); }});

lrcBtn.addEventListener("click", ()=>{
  /* بار اول با دو پنجره روشن می‌شود (۲۱ و ۶۳) تا تقاطع‌ها از همان اول
     دیده شوند؛ با یک منحنی تنها چیزی برای تقاطع نیست. */
  state.lrc[state.view] = lrcOn() ? null : {a:21, b:63};
  syncOvRow(); syncChips(); draw();
});
function applyLrc(){
  const w = lrcOn(); if(!w) return;
  const a = +lrcWin.value || 63;
  const b = lrcWin2.value ? +lrcWin2.value : null;
  state.lrc[state.view] = {a, b: (b && b !== a) ? b : null};
  syncOvRow(); syncChips(); draw();
}
lrcWin.addEventListener("change", applyLrc);
lrcWin2.addEventListener("change", applyLrc);

/* ================= تمام‌صفحه ================= */
const fsBtn = document.getElementById("fs");
fsBtn.addEventListener("click", async ()=>{
  try{
    if(document.fullscreenElement) await document.exitFullscreen();
    else await document.documentElement.requestFullscreen();
  }catch(err){ /* بعضی مرورگرها اجازه نمی‌دهند — دکمه بی‌اثر می‌ماند */ }
});
document.addEventListener("fullscreenchange", ()=>{
  const on = !!document.fullscreenElement;
  fsBtn.textContent = on ? "خروج از تمام‌صفحه" : "تمام‌صفحه";
  fsBtn.setAttribute("aria-pressed", on?"true":"false");
  requestAnimationFrame(resize);
});
document.addEventListener("keydown", e=>{
  if(e.key==="f" && !/input|textarea/i.test(e.target.tagName)) fsBtn.click();
});


/* ================= نمونه‌برداری نسبت نقدینگی =================
   از همان سری روزانه ساخته می‌شود: آخرین مقدار هر هفته و هر ماه، روی
   همان ردیفِ محور. داده‌ای اضافه نمی‌خواهد و در data.json هم نمی‌رود.

   مرز هفته شنبه است (آغاز هفتهٔ بازار). از تاریخ میلادیِ همان ردیف
   (`DATA.t`) حساب می‌شود، نه از تاریخ شمسی، چون شمارهٔ هفتهٔ شمسی
   دردسر دارد و روزِ هفته همان است.
   ------------------------------------------------------------ */
const J_MONTHS = ["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور",
                  "مهر","آبان","آذر","دی","بهمن","اسفند"];
const ORDINALS = ["اول","دوم","سوم","چهارم","پنجم","ششم"];

/* ================= نسبت نقدینگی: هفتگی و ماهانه =================
   این دو نمودار محورِ روزانه را *ندارند*. اول یک جدول چهارشنبه‌ها ساخته
   می‌شود و نمودار هفتگی روی همان کشیده می‌شود — یک ستون به ازای هر
   هفته، نه به ازای هر روز معاملاتی. بعد از همان جدول، چهارشنبهٔ آخر هر
   ماه نگه داشته می‌شود و نمودار ماهانه روی آن کشیده می‌شود.

   قبلاً هر دو روی محور روزانه بودند و هر نقطه چهار یا بیست ستونِ خالی
   فاصله داشت: خط شکسته می‌شد، برچسب‌های محور جا نمی‌شدند، و میانگینِ
   «۸ دوره‌ای» در واقع ۸ *روز* بود نه ۸ هفته. حالا هر قاب محور خودش را
   دارد، پس EMA ۸ یعنی هشت هفته و EMA ۱۲ یعنی دوازده ماه.

   چهارشنبهٔ تعطیل: مقدار روز قبلش برداشته می‌شود (و اگر آن هم نبود،
   روز قبل‌ترش — تا ده روز عقب). هفته‌ای که هیچ دادهٔ نزدیکی ندارد —
   مثل تعطیلی بلندِ اسفند ۱۴۰۴ — اصلاً ستون نمی‌گیرد.
   ------------------------------------------------------------ */
const FRAMES = {};
FRAMES.day = {id:"day", d:DATA.d, t:DATA.t, n:N, s:DATA, per:1, unit:"روز معاملاتی"};

(function buildRatioFrames(){
  const src = DATA.ratio;
  if(!src) return;

  const byGreg = new Map();
  for(let i=0;i<N;i++) byGreg.set(String(DATA.t[i]), i);

  let first=-1, last=-1;
  for(let i=0;i<N;i++){ if(src[i]!=null){ if(first<0) first=i; last=i; } }
  if(first<0) return;

  const toDate = i => { const g=String(DATA.t[i]);
    return new Date(+g.slice(0,4), +g.slice(4,6)-1, +g.slice(6,8)); };
  const stamp = dt => `${dt.getFullYear()}`
    + String(dt.getMonth()+1).padStart(2,"0")
    + String(dt.getDate()).padStart(2,"0");

  const end = toDate(last);
  const cur = toDate(first);
  while(cur.getDay() !== 3) cur.setDate(cur.getDate()+1);   // ۳ = چهارشنبه

  /* ---- جدول چهارشنبه‌ها ---- */
  const wk = {d:[], t:[], v:[], src:[]};
  let prev = -1;
  for(; cur <= end; cur.setDate(cur.getDate()+7)){
    let hit = -1;
    const probe = new Date(cur);
    for(let back=0; back<10; back++){
      const i = byGreg.get(stamp(probe));
      if(i != null && src[i] != null){ hit = i; break; }
      probe.setDate(probe.getDate()-1);
    }
    if(hit < 0 || hit === prev) continue;   // تکراری یعنی هفتهٔ بی‌داده
    prev = hit;
    wk.d.push(DATA.d[hit]);
    wk.t.push(DATA.t[hit]);
    wk.v.push(src[hit]);
    wk.src.push(DATA.d[hit] === DATA.d[hit] ? stamp(cur) : null);
  }
  if(!wk.d.length) return;

  /* ---- چهارشنبهٔ آخر هر ماه ---- */
  const keep = [];
  for(let i=0;i<wk.d.length;i++){
    const m = wk.d[i].slice(0,6);
    if(i+1 === wk.d.length || wk.d[i+1].slice(0,6) !== m) keep.push(i);
  }

  /* ---- برچسب‌ها: «هفته دوم مهر» و «مهر» ---- */
  const labW = [], perMonth = {};
  for(let i=0;i<wk.d.length;i++){
    const d = wk.d[i], mo = d.slice(0,6);
    perMonth[mo] = (perMonth[mo] || 0) + 1;
    labW.push({y:+d.slice(0,4), mo:+d.slice(4,6), w:perMonth[mo]});
  }
  const labM = keep.map(i => ({y:labW[i].y, mo:labW[i].mo, w:0}));

  FRAMES.w = {
    id:"w", d:wk.d, t:wk.t, n:wk.d.length, per:5, unit:"هفته",
    s:{ratio_w: wk.v}, labels:labW,
  };
  FRAMES.m = {
    id:"m", d:keep.map(i=>wk.d[i]), t:keep.map(i=>wk.t[i]), n:keep.length, per:21, unit:"ماه",
    s:{ratio_m: keep.map(i=>wk.v[i])}, labels:labM,
  };

  const base = fa("ratio") || {};
  EXTRA.push({k:"ratio_w", n:base.n, u:base.u, dec:base.dec, ma:[8,26],
              fn:"ارزش کل بازار ÷ نقدینگی M2 — چهارشنبهٔ هر هفته"});
  EXTRA.push({k:"ratio_m", n:base.n, u:base.u, dec:base.dec, ma:[6,12],
              fn:"ارزش کل بازار ÷ نقدینگی M2 — چهارشنبهٔ آخر هر ماه"});
})();

/* قابِ فعال: نماهای عادی روزانه‌اند، نسبت نقدینگیِ هفتگی و ماهانه قاب
   خودشان را دارند. اگر ساخته نشده باشند (نبودِ سری نسبت) به روزانه
   برمی‌گردد. */
function frame(){
  const V = view();
  if(V.resample && FRAMES[state.ratioStep]) return FRAMES[state.ratioStep];
  return FRAMES.day;
}
const FN = () => frame().n;
const FD = i => frame().d[i];
const FS = k => frame().s[k];

/* متن برچسب محور. سال فقط وقتی می‌آید که عوض شده باشد، وگرنه محور از
   تکرار «۱۴۰۵» پر می‌شد. */
function stepLabel(rec, showYear){
  const mo = J_MONTHS[rec.mo-1] || rec.mo;
  const head = rec.w ? `هفته ${ORDINALS[rec.w-1] || rec.w} ` : "";
  return head + mo + (showYear ? " " + pnum(rec.y) : "");
}

/* ---- کشویی انتخاب سری در نمای کلی ---- */
const pickRow = document.getElementById("pickRow");
const serPick = document.getElementById("serPick");
const serPickLabel = document.querySelector('label[for="serPick"]');
SERIES.filter(s=>!s.hide && DATA[s.k]).forEach(s=>{
  const o=document.createElement("option");
  o.value=s.k; o.textContent=s.n;
  serPick.appendChild(o);
});
serPick.addEventListener("change", ()=>{
  state.key = serPick.value; state.compare=[state.key];
  syncChips(); syncMaRow(); syncRsiRow(); syncOvRow(); draw();
});

/* ---- کلیدهای روزانه/هفتگی/ماهانه در تب نسبت نقدینگی ---- */
const stepRow = document.getElementById("stepRow");
RATIO_STEPS.forEach(s=>{
  const b=document.createElement("button");
  b.type="button"; b.textContent=s.n; b.dataset.s=s.id;
  b.addEventListener("click",()=>{
    state.ratioStep = s.id;
    state.key = ratioKey(); state.compare=[state.key];
    /* قابِ تازه کوتاه‌تر است (۸٬۰۴۷ روز → ۳۱۸ هفته → ۷۵ ماه)، پس بازهٔ
       دید باید دوباره روی آن نشانده شود. بی این، i0/i1 بیرون از قاب
       می‌ماندند و تاریخِ ردیفِ ناموجود خوانده می‌شد. */
    const on = rangeRow.querySelector('button[aria-pressed="true"]');
    applyRange(on ? +on.dataset.d : 0);
    syncChips(); syncMaRow(); syncRsiRow(); syncOvRow(); draw();
  });
  stepRow.appendChild(b);
});
function syncStepRow(){
  const V=view();
  stepRow.hidden = !V.resample;
  stepRow.querySelectorAll("button").forEach(b=>
    b.setAttribute("aria-pressed", b.dataset.s===state.ratioStep ? "true":"false"));
}

/* ================= دیده‌بان صنایع =================
   فقط جدول. هر صنعت یک زیرتب، و سیزده ستونش کنار هم.

   داده‌اش در data.json نیست: هر صنعت یک فایل `ind/<کد>.json` دارد که فقط
   با کلیک‌شدن زیرتبش گرفته می‌شود. دلیلش حجم است — چهل‌وهشت صنعت ×
   سیزده سری، اگر همه را داخل data.json می‌ریختیم هر بازکردن صفحه چند
   مگابایت می‌کشید، حتی برای دیدن شاخص کل.

   فایل هر صنعت تُنُک است: `i` فهرست شمارهٔ ردیف روی محور اصلی، و هر سری
   به همان طول. اینجا به آرایهٔ هم‌طولِ محور باز می‌شود و زیر کلید
   `ind_<کد>_<سری>` در DATA می‌نشیند، پس جدول هیچ نمی‌داند که این ستون
   صنعتی است.
   ------------------------------------------------- */
const IND = (DATA.ind && DATA.ind.codes) ? DATA.ind : {dir:null, codes:[], metrics:[]};
const indKey = (c,m) => `ind_${c}_${m}`;
const indLoaded = new Set();
let indBusy = null;

/* انتخاب صنعت کشویی است و داخل نوار بالای خودِ جدول می‌نشیند، کنار
   «برو به تاریخ». نوار چیپ بود و عوض شد: با شصت‌ویک گزینه سه ردیف
   می‌شد و بالای جدول را می‌خورد. */
const indPick = document.getElementById("indPick");
const indPickLabel = document.getElementById("indPickLabel");
/* همان فهرست، این بار بالای نمودار ستونی. دو کشویی جداست چون یکی داخل
   نوار جدول می‌نشیند و دیگری داخل نوار کنترل‌ها؛ مقدارشان هم‌گام می‌شود
   پس عوض‌کردن صنعت در یک تب، تب دیگر را هم همان‌جا نگه می‌دارد. */
const indChartPick = document.getElementById("indChartPick");
const indChartLabel = document.getElementById("indChartLabel");

/* تب‌های صنایع بی‌داده نمایش داده نمی‌شوند — مثل صفحهٔ تک‌فایلیِ محلی که
   نمی‌تواند کنار خودش فایل بخواند. */
const indBlind = !IND.dir || !IND.codes.length;
for(const id of ["ind","indval","flow"]){
  const b = viewsRow.querySelector(`button[data-v="${id}"]`);
  if(b && indBlind) b.hidden = true;
}

IND.codes.forEach(c=>{
  for(const sel of [indPick, indChartPick]){
    const o=document.createElement("option");
    o.value=c.c; o.textContent=c.n;
    o.title=`${c.d} روز · ${c.f} تا ${c.l}`;
    sel.appendChild(o);
  }
});
indPick.addEventListener("change", ()=>pickInd(indPick.value));
indChartPick.addEventListener("change", ()=>{
  state.ind = String(indChartPick.value);
  ensureIndChart();
});

function indChipState(){
  if(state.ind){ indPick.value = state.ind; indChartPick.value = state.ind; }
}

/* ستون‌های جدولِ صنعتِ انتخاب‌شده. ستونی که داده‌اش نیامده هم می‌ماند و
   «—» نشان می‌دهد: شش سری (سفارش‌ها، برآیند، بازدهی، درصدها) فقط از
   برداشت روزانه می‌آیند و در اکسلِ تاریخچه نیستند، پس تا امروز خالی‌اند.
   حذفشان یعنی ستون‌ها بین صنایع جابه‌جا شوند. */
function indCols(){
  if(!state.ind) return [];
  return IND.metrics.map(m=>({k:indKey(state.ind,m.k), n:m.n, u:m.u, dec:m.dec}));
}

/* فقط روزهایی که این صنعت داده دارد، جدیدترین بالا. بی این فیلتر جدول
   هشت هزار ردیف می‌شود که بیشترش خالی است. */
function indRows(){
  if(!state.ind) return [];
  const keys = IND.metrics.map(m=>DATA[indKey(state.ind,m.k)]).filter(Boolean);
  if(!keys.length) return [];
  const out=[];
  for(let i=N-1;i>=0;i--){
    for(const a of keys){ if(a[i]!=null){ out.push(i); break; } }
  }
  return out;
}

const titleEl = document.getElementById("title");

/* فایل صنعت را می‌گیرد و به ستون‌های هم‌طولِ محور باز می‌کند. */
function loadInd(code){
  code = String(code);
  if(indLoaded.has(code)) return Promise.resolve(true);
  if(indBusy===code) return Promise.resolve(false);
  indBusy=code;
  return fetch(`${IND.dir}/${code}.json?v=${DATA.d[DATA.d.length-1]}`)
    .then(r=>{ if(!r.ok) throw new Error("HTTP "+r.status); return r.json(); })
    .then(j=>{
      const idx=j.i||[];
      IND.metrics.forEach(m=>{
        const col=j[m.k];
        if(!col) return;
        const a=new Array(N).fill(null);
        for(let p=0;p<idx.length;p++){
          const i=idx[p];
          if(i>=0 && i<N) a[i]=col[p];
        }
        DATA[indKey(code,m.k)]=a;
      });
      indLoaded.add(code); indBusy=null;
      return true;
    })
    .catch(e=>{
      indBusy=null;
      titleEl.textContent = `صنایع — دادهٔ این صنعت نیامد (${e.message})`;
      return false;
    });
}

function showInd(code){
  state.ind = code;
  const c = IND.codes.find(x=>x.c===code);
  titleEl.textContent = c ? `صنایع — ${c.n}` : "دیده‌بان صنایع";
  scrollEl.scrollTop = 0;
  indChipState();
  renderSheet();
}

function pickInd(code){
  code = String(code);
  if(indLoaded.has(code)){ showInd(code); return; }
  titleEl.textContent = "صنایع — در حال گرفتن داده…";
  loadInd(code).then(okq=>{ if(okq) showInd(code); });
}

/* اولین بار صنعت اول، بارهای بعد همان صنعتی که قبلاً می‌دیدید. */
function ensureInd(){
  if(!IND.codes.length) return;
  pickInd(state.ind || IND.codes[0].c);
}

/* ---- نمودار ستونیِ ارزش معاملات صنعت ----
   سریِ بیرونی `ind_<کد>_value` و درونی `ind_<کد>_flow`؛ هر دو از همان
   فایلی می‌آیند که جدول صنایع هم از آن می‌خورد، پس عوض‌کردن تب چیزی را
   دوباره نمی‌گیرد. */
function indTitle(){
  const c = IND.codes.find(x=>String(x.c)===String(state.ind));
  return c ? `ارزش معاملات — ${c.n}` : "ارزش معاملات صنایع";
}

function applyIndChart(){
  state.key = indKey(state.ind, "value");
  state.compare=[state.key]; state.cmpMode=false;
  indChipState();
  /* بازهٔ پیش‌فرض یک سال، مثل بقیهٔ نماهای تک‌سری. برای صنعتی که فقط
     چند ماه داده دارد، applyRange خودش تا آخرین روزِ دارای داده عقب
     می‌آید. */
  applyRange(250); markRange(3);
  syncChips(); syncMaRow(); syncRsiRow(); syncOvRow(); draw();
}

function ensureIndChart(){
  if(!IND.codes.length) return;
  const code = String(state.ind || IND.codes[0].c);
  state.ind = code;
  if(indLoaded.has(code)){ applyIndChart(); return; }
  titleEl.textContent = "ارزش معاملات — در حال گرفتن داده…";
  loadInd(code).then(ok=>{ if(ok) applyIndChart(); });
}

/* قالب وب کل این فایل را داخل یک تابع می‌پیچد، پس از کنسول مرورگر (و از
   تست‌های خودکار) هیچ‌کدام از این‌ها دیده نمی‌شد. چیز تازه‌ای لو نمی‌دهد —
   همهٔ داده‌اش همان data.json کنار صفحه است. */
window.__dbg = {state, DATA, FRAMES, plan, view, fa, frame, IND};

/* ---------- راه‌اندازی ---------- */
new ResizeObserver(resize).observe(stage);
matchMedia("(prefers-color-scheme:dark)").addEventListener("change",()=>{syncChips();draw();});
new MutationObserver(()=>{syncChips();draw();}).observe(
  document.documentElement,{attributes:true,attributeFilter:["data-theme"]});
document.fonts?.ready?.then(draw);
state.compare=[state.key];
syncChips();
syncMaRow();
syncRsiRow();
syncOvRow();
resize();


/* ================= جمع ورود پول بین دو تاریخ =================

   چرا یک تبِ جداگانه و نه یک عدد گوشهٔ نمودار: سؤال «از اول مهر تا
   حالا چقدر پول حقیقی وارد شد» روی نمودار فقط برای کل بازار جا
   می‌شود، در حالی که همان سؤال برای هر صنعت و هر سبد صندوق هم
   پرسیده می‌شود.

   سه بخشِ مستقل، نه یک فهرستِ درهم: کل بازار، صنایع، صندوق‌ها. هیچ‌کدام
   قرار نیست جمعِ دیگری باشد — هر کدام جمعِ خودش در همان بازه است. اولین
   نسخه هر سه را در یک جدول ریخته بود و شبیه یک تفکیکِ کل بازار دیده
   می‌شد؛ نبود. */

const flowEl    = document.getElementById("flow");
const flowFrom  = document.getElementById("flowFrom");
const flowTo    = document.getElementById("flowTo");
const flowQuick = document.getElementById("flowQuick");
const flowCount = document.getElementById("flowCount");
const flowCards = document.getElementById("flowCards");
const flowNote  = document.getElementById("flowNote");
const flowTables= document.getElementById("flowTables");
const flowCsvBtn= document.getElementById("flowCsv");

/* کارت بالا فقط یکی است: کل بازار. صندوق‌ها جدول خودشان را دارند و
   تکرارشان این‌جا همان درهم‌ریختگیِ نسخهٔ اول را برمی‌گرداند. */
const FLOW_MARKET = [
  {k:"flow_retail", n:"کل بازار", s:"سهام، حق تقدم و صندوق سهامی"},
];

/* کد صنعت عددی است و کد سبد صندوق نه — همین تفکیکشان می‌کند. */
const isFundCode = c => !/^\d+$/.test(String(c));

/* دکمه‌های میان‌بر. عددها «روز معاملاتی»اند نه روز تقویمی، چون محور
   همین است: ۲۲ روز معاملاتی ≈ یک ماه. */
const FLOW_QUICK = [
  {n:"۱م", d:22}, {n:"۳م", d:64}, {n:"۶م", d:128}, {n:"۱س", d:250},
  {n:"از ابتدای سال", ytd:true}, {n:"همه", all:true},
];

let FLOW = null;            // {کد صنعت: {i:[ردیف محور], f:[ورود پول]}}
let flowState = "cold";     // cold | loading | ready | error
let flowErrMsg = "";

const HEMAT = 1000;         // ۱ همت = ۱۰۰۰ میلیارد تومان

const normJ = s => {
  const t = String(s||"").replace(/[^0-9۰-۹٠-٩]/g, "")
    .replace(/[۰-۹]/g, c=>"۰۱۲۳۴۵۶۷۸۹".indexOf(c))
    .replace(/[٠-٩]/g, c=>"٠١٢٣٤٥٦٧٨٩".indexOf(c));
  return t.length===8 ? t : "";
};

/* بازهٔ انتخاب‌شده به شمارهٔ ردیف روی محور. تاریخی که روز معاملاتی نبوده
   به نزدیک‌ترین روزِ *داخل* بازه می‌چسبد، نه بیرونش. */
function flowRange(){
  const a = normJ(flowFrom.value), b = normJ(flowTo.value);
  let i0 = 0, i1 = N-1;
  if(a){ i0 = DATA.d.findIndex(d => d >= a); if(i0 < 0) i0 = N; }
  if(b){ i1 = -1; for(let i=N-1;i>=0;i--){ if(DATA.d[i] <= b){ i1 = i; break; } } }
  return {i0, i1, ok: i0 <= i1 && i0 < N && i1 >= 0};
}

function setFlowRange(i0, i1){
  flowFrom.value = DATA.d[Math.max(0, Math.min(N-1, i0))];
  flowTo.value   = DATA.d[Math.max(0, Math.min(N-1, i1))];
}

function sumSeries(arr, i0, i1){
  let s = 0, n = 0;
  if(!arr) return {s:null, n:0};
  for(let i=i0;i<=i1;i++){
    const v = arr[i];
    if(v==null || Number.isNaN(v)) continue;
    s += v; n++;
  }
  return {s: n ? s : null, n};
}

/* جمع یک صنعت از همان آرایهٔ تُنُک — بدون باز کردنش روی کل محور. */
function sumInd(code, i0, i1){
  const o = FLOW && FLOW[code];
  if(!o) return {s:null, n:0};
  let s = 0, n = 0;
  for(let p=0;p<o.i.length;p++){
    const i = o.i[p];
    if(i < i0) continue;
    if(i > i1) break;
    s += o.f[p]; n++;
  }
  return {s: n ? s : null, n};
}

const flowSign = v => v==null ? "" : (v > 0 ? "pos" : (v < 0 ? "neg" : ""));

function flowBig(v){
  if(v==null) return "—";
  return nice(v, Math.abs(v) >= 100 ? 0 : 1);
}

function ensureFlow(){
  if(flowState === "ready"){ renderFlow(); return; }
  if(flowState === "loading") return;
  if(!IND.flow){ flowState = "error"; flowErrMsg = "فهرست صنایع در این نسخه نیست."; renderFlow(); return; }
  flowState = "loading";
  renderFlow();
  fetch(`${IND.flow}?v=${DATA.d[N-1]}`)
    .then(r => { if(!r.ok) throw new Error("HTTP "+r.status); return r.json(); })
    .then(j => { FLOW = j; flowState = "ready"; renderFlow(); })
    .catch(e => { flowState = "error"; flowErrMsg = e.message; renderFlow(); });
}

function renderFlow(){
  const R = flowRange();
  if(!R.ok){
    flowCount.textContent = "بازه خالی است";
    flowCards.innerHTML = ""; flowTables.innerHTML = "";
    flowNote.textContent = "تاریخ شروع باید پیش از تاریخ پایان باشد.";
    return;
  }
  const {i0, i1} = R;
  flowCount.textContent =
    `${jDate(DATA.d[i0])} تا ${jDate(DATA.d[i1])} · ${fmt(i1-i0+1,0)} روز معاملاتی`;

  const full = i1 - i0 + 1;

  /* کارت بالا: کل بازار */
  flowCards.innerHTML = FLOW_MARKET.map(m => {
    const {s, n} = sumSeries(DATA[m.k], i0, i1);
    const hem = (s!=null && Math.abs(s) >= HEMAT)
      ? ` · ${nice(s/HEMAT, 1)} همت` : "";
    return `<div class="flow-card">
      <div class="k">${m.n} — ${m.s}</div>
      <div class="v ${flowSign(s)}">${flowBig(s)}<span class="u">میلیارد تومان</span></div>
      <div class="s">${n ? fmt(n,0)+" روز داده از "+fmt(full,0)+hem : "داده‌ای در این بازه نیست"}</div>
    </div>`;
  }).join("");

  if(flowState === "loading"){
    flowNote.textContent = "صنایع و صندوق‌ها در حال آمدن است…";
    flowTables.innerHTML = "";
    return;
  }
  if(flowState === "error"){
    flowNote.textContent = `صنایع و صندوق‌ها نیامدند (${flowErrMsg}).`;
    flowTables.innerHTML = "";
    return;
  }

  flowNote.textContent = "هر عدد، جمعِ خودِ آن ردیف در همین بازه است — "
    + "نه سهمی از کل بازار. سه بخش مستقل‌اند و جمعشان روی هم معنی ندارد.";

  const all = IND.codes.map(c => {
    const {s, n} = sumInd(String(c.c), i0, i1);
    return {c:String(c.c), n:c.n, s, days:n};
  }).filter(r => r.s != null);

  flowTables.innerHTML =
      flowTable("صنایع", all.filter(r => !isFundCode(r.c)), full)
    + flowTable("صندوق‌ها", all.filter(r =>  isFundCode(r.c)), full);
}

/* یک جدول برای یک دسته. مقیاس میله در هر جدول از بزرگ‌ترینِ *همان*
   دسته می‌آید: اگر مشترک بود، صندوق طلا همهٔ صنعت‌ها را صاف می‌کرد. */
function flowTable(title, rows, full){
  if(!rows.length){
    return `<div class="flow-head">${title}</div>`
      + `<div class="flow-note">در این بازه داده‌ای ندارد.</div>`;
  }
  rows = rows.slice().sort((a,b) => b.s - a.s);
  const max = rows.reduce((a,r)=>Math.max(a, Math.abs(r.s)), 0) || 1;
  const body = rows.map(r => {
    const w = Math.abs(r.s) / max * 50;
    /* میلهٔ دوطرفه: خط صفر وسط، مثبت یک طرف و منفی طرف دیگر، تا بدون
       خواندن عدد هم معلوم باشد کدام پول گرفته و کدام داده. */
    const side = r.s >= 0
      ? `inset-inline-start:50%; width:${w}%; background:var(--up)`
      : `inset-inline-end:50%; width:${w}%; background:var(--down)`;
    const short = r.days < full;
    return `<tr>
      <td>${r.n}</td>
      <td class="${flowSign(r.s)}">${flowBig(r.s)}</td>
      <td class="bar"><div class="bar-wrap"><span class="zero" style="inset-inline-start:50%"></span><i style="${side}"></i></div></td>
      <td class="${short ? "none" : ""}"${short
        ? ` title="فقط ${fmt(r.days,0)} روز از ${fmt(full,0)} روزِ بازه داده دارد."` : ""
        }>${fmt(r.days,0)}</td></tr>`;
  }).join("");
  return `<div class="flow-head">${title}<span>${fmt(rows.length,0)} ردیف</span></div>`
    + `<table><thead><tr>
        <th>${title === "صندوق‌ها" ? "سبد صندوق" : "صنعت"}</th>
        <th>مجموع ورود پول حقیقی<span class="unit">میلیارد تومان</span></th>
        <th>اندازه نسبت به بزرگ‌ترینِ همین بخش</th>
        <th>روز داده<span class="unit">از ${fmt(full,0)} روز بازه</span></th>
      </tr></thead><tbody>${body}</tbody></table>`;
}

FLOW_QUICK.forEach(q => {
  const b = document.createElement("button");
  b.textContent = q.n;
  b.addEventListener("click", () => {
    if(q.all) setFlowRange(0, N-1);
    else if(q.ytd){
      const y = DATA.d[N-1].slice(0,4);
      let i = DATA.d.findIndex(d => d.slice(0,4) === y);
      setFlowRange(i < 0 ? 0 : i, N-1);
    } else setFlowRange(N-q.d, N-1);
    renderFlow();
  });
  flowQuick.appendChild(b);
});

for(const el of [flowFrom, flowTo]){
  el.addEventListener("change", renderFlow);
  el.addEventListener("keydown", e => { if(e.key === "Enter") renderFlow(); });
}

flowCsvBtn.addEventListener("click", () => {
  const R = flowRange();
  if(!R.ok) return;
  const {i0, i1} = R;
  const lines = ["بخش,نام,مجموع ورود پول حقیقی (میلیارد تومان),روز داده"];
  for(const m of FLOW_MARKET){
    const {s, n} = sumSeries(DATA[m.k], i0, i1);
    lines.push(`کل بازار,${m.n},${s==null?"":s.toFixed(1)},${n}`);
  }
  if(flowState === "ready"){
    for(const c of IND.codes){
      const {s, n} = sumInd(String(c.c), i0, i1);
      if(s == null) continue;
      lines.push(`${isFundCode(c.c) ? "صندوق‌ها" : "صنایع"},${c.n},${s.toFixed(1)},${n}`);
    }
  }
  saveCsv(`bourse_flow_${DATA.d[i0]}_${DATA.d[i1]}.csv`, "﻿" + lines.join("\n"));
});

/* بازهٔ پیش‌فرض: یک ماه معاملاتی. */
setFlowRange(N-22, N-1);

/* برای تست‌های خودکار: همان توابع جمع، بدون عبور از DOM. */
window.__dbg.flow = {
  range: flowRange, setRange: setFlowRange, render: renderFlow,
  sumSeries, sumInd, ensure: ensureFlow,
  get data(){ return FLOW; }, get status(){ return flowState; },
};
