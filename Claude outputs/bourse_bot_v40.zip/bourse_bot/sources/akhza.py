# -*- coding: utf-8 -*-
"""
نرخ بهرهٔ بدون ریسک — از بازده تا سررسید اسناد خزانهٔ اسلامی (اخزا).

── چرا این‌طور و نه یک عدد آماده
   هیچ منبع عمومی‌ای که از این‌جا در دسترس باشد «نرخ بدون ریسک» را
   به‌صورت یک سری آماده نمی‌دهد. بورس‌ویو چارتش را دارد ولی پشت لاگین
   است و خروجی نمی‌دهد. اخزا ولی اوراق بدون کوپن است: فقط قیمت امروز و
   تاریخ سررسید لازم است و بازده خودش درمی‌آید.

       r = (ارزش اسمی ÷ قیمت) ^ (۳۶۵ ÷ روز تا سررسید) − ۱

   ارزش اسمی هر ورقه یک میلیون ریال است و کوپنی هم پرداخت نمی‌شود، پس
   این فرمول دقیق است، نه تقریب.

── تاریخ سررسید از کجا
   از خودِ نام کامل نماد. چارتیکس در `description` همان چیزی را می‌دهد
   که TSETMC دارد:

       اخزا501  →  اسنادخزانه-م1بودجه05-080225

   شش رقم آخر، تاریخ سررسید است: ۱۴۰۸/۰۲/۲۵. هیچ جدول دستیِ سررسید
   لازم نیست و ورقهٔ تازه خودش با نام خودش می‌آید.

── چرا میانه و نه میانگین
   هر روز ده تا پانزده ورقه در بازارند و منحنی بازده دارند: روز آخر
   ۱۴۰۵/۰۸/۰۶ از ۴۰.۶٪ (۳۱۳ روز تا سررسید) تا ۴۴.۷٪ (۹۲۹ روز) پخش
   بودند. میانه نمایندهٔ پایدارِ همین پخش است و یک ورقهٔ کم‌معامله یا
   قیمت پرتِ یک روز، جابه‌جایش نمی‌کند.

── چرا ماهانه
   عدد روزانه‌اش هست و حساب می‌شود، ولی سری‌ای که نگه می‌داریم ماهانه
   است: نوسان روزانهٔ بازده اخزا بیشتر از آن است که روند چندساله را
   نشان دهد، و خودِ نرخ بهره هم چیزی نیست که روزانه نگاهش کنند.
   مقدار هر ماه، میانهٔ روزهای همان ماه است و روی **اولین روز معاملاتیِ
   آن ماه** می‌نشیند — کلیدی که وسط ماه جابه‌جا نمی‌شود، پس هر برداشت
   همان ردیف را تازه می‌کند نه این‌که ردیف تازه بسازد.
"""
import datetime
import json
import re
import statistics
import urllib.parse

import jdatetime

from .common import get

SEARCH = "https://chartix.ir/api/symbols/search?q="
HISTORY = "https://market.chartix.ir/symbol/history"

FACE = 1_000_000.0            # ارزش اسمی هر ورقه، ریال

# پرس‌وجوهای جست‌وجو: هر کدام ده نتیجه می‌دهد، پس برای دیدن همهٔ ورقه‌ها
# باید چند بار با پیشوندهای مختلف پرسید. تکراری‌ها خودشان حذف می‌شوند.
QUERIES = ["اخزا"] + [f"اخزا{i}" for i in range(10)]

# بازهٔ معقول روز تا سررسید. زیر بیست روز بازده بی‌معنی و پرنوسان است
# (مخرج توان کوچک می‌شود و یک ریال اختلاف قیمت، چند درصد بازده)، و
# بالای ۱۵۰۰ روز ورقه‌ای نداریم.
MIN_DAYS, MAX_DAYS = 20, 1500
# بازهٔ باورپذیر خودِ بازده؛ بیرونش یعنی قیمت یا سررسید غلط خوانده شده.
MIN_RATE, MAX_RATE = 0.05, 1.5
MIN_BONDS = 2                 # کمتر از این، میانه معنی ندارد

MAT_RE = re.compile(r"-(\d{6})\s*$")


def maturity(desc):
    """'اسنادخزانه-م1بودجه05-080225' → date(1408/02/25 میلادی). نشد → None."""
    m = MAT_RE.search(str(desc or "").strip())
    if not m:
        return None
    s = m.group(1)
    try:
        return jdatetime.date(1400 + int(s[:2]), int(s[2:4]), int(s[4:])).togregorian()
    except (ValueError, TypeError):
        return None


def ytm(price, days):
    """بازده سالانهٔ ساده‌شده تا سررسید. ورودی نامعقول → None."""
    if not price or price <= 0 or days < MIN_DAYS or days > MAX_DAYS:
        return None
    r = (FACE / price) ** (365.0 / days) - 1
    return r if MIN_RATE < r < MAX_RATE else None


def day_of(ts):
    return datetime.datetime.fromtimestamp(int(ts), datetime.timezone.utc).date()


def daily_rates(bonds):
    """
    bonds: [(تاریخ سررسید، [کندل، …]), …] → {روز میلادی: میانهٔ بازده}

    کندل‌های چند تایم‌فریم را می‌شود با هم داد؛ روزهای تکراری در یک
    سبد می‌افتند و میانه از همه گرفته می‌شود.
    """
    per = {}
    for mat, candles in bonds:
        if not mat or not isinstance(candles, list):
            continue
        for c in candles:
            if not isinstance(c, dict):
                continue
            try:
                g = day_of(c.get("time"))
            except (ValueError, TypeError, OSError, OverflowError):
                continue
            r = ytm(c.get("close"), (mat - g).days)
            if r is not None:
                per.setdefault(g, []).append(r)
    return {g: statistics.median(v) for g, v in per.items() if len(v) >= MIN_BONDS}


def monthly(rates):
    """{روز میلادی: نرخ} → {«۱۴۰۵۰۸»: میانهٔ آن ماه شمسی}"""
    by = {}
    for g, r in rates.items():
        by.setdefault(jdatetime.date.fromgregorian(date=g).strftime("%Y%m"),
                      []).append(r)
    return {ym: statistics.median(v) for ym, v in by.items()}


def place(months, trading_days):
    """
    {ماه: نرخ} → [(تاریخ شمسیِ روز، نرخ), …]، مرتب.

    ⚠ چرا این قدم لازم است و یک بار جا افتاد: محور نمودار «روز معاملاتی
    بورس» است، و کندل‌های هفتگی/ماهانهٔ چارتیکس روی روزهایی می‌نشینند که
    لزوماً روز معاملاتی نیستند. نسخهٔ اول، مقدار هر ماه را روی *اولین
    روزِ دارای کندل* می‌گذاشت و نتیجه این شد که از ۷۹ ماه فقط ۵۰ تا روی
    نمودار دیده شدند — بقیه بی‌صدا افتادند چون تاریخشان روی محور نبود.

    پس مقدار هر ماه روی **اولین روز معاملاتیِ همان ماه** می‌نشیند؛ کلیدی
    که وسط ماه جابه‌جا نمی‌شود. ماهی که بازار اصلاً باز نبوده جا می‌ماند
    و این درست است: روی نمودار جایی ندارد.

    trading_days: فهرست مرتبِ روزهای معاملاتی (تاریخ شمسی هشت‌رقمی).
    """
    first = {}
    for d in trading_days or ():
        first.setdefault(str(d)[:6], str(d))
    return sorted((first[ym], r) for ym, r in months.items() if ym in first)


def symbols(session=None):
    """{نماد: (نام، توضیح)} — همهٔ اخزاهایی که چارتیکس می‌شناسد."""
    out = {}
    for q in QUERIES:
        try:
            body = get(SEARCH + urllib.parse.quote(q), session)
            data = json.loads(body)
        except Exception:                           # noqa: BLE001
            continue
        items = data if isinstance(data, list) else (data.get("data") or [])
        for it in items:
            if not isinstance(it, dict):
                continue
            name = it.get("name") or ""
            if name.startswith("اخزا") and it.get("ticker"):
                out[it["ticker"]] = (name, it.get("description") or "")
    return out


def fetch(session=None, trading_days=None, tfs=("1D",)):
    """
    خروجی: (rows, notes) — rows = [(date_j, "rfr", درصد, src_ref), …]

    فقط تایم‌فریم روزانه گرفته می‌شود (۱۳۰ کندل ≈ شش ماه)، که برای
    به‌روز نگه‌داشتن ماه جاری و چند ماه عقب‌تر بس است. تاریخچهٔ کامل
    یک بار در `data/rfr.csv` آمده و مهاجرت واردش می‌کند.

    trading_days: روزهای معاملاتی از دیتابیس، برای نشاندن مقدار هر ماه
    روی روزی که واقعاً روی محور هست (توضیح در `place`).
    """
    syms = symbols(session)
    if not syms:
        return [], ["اخزا: فهرست نمادها از چارتیکس نیامد."]

    notes, bonds, skipped = [], [], []
    for ticker, (name, desc) in syms.items():
        mat = maturity(desc)
        if mat is None:
            skipped.append(name)
            continue
        for tf in tfs:
            try:
                body = get(f"{HISTORY}?ticker={ticker}&tf={tf}", session)
                candles = json.loads(body)
            except Exception:                       # noqa: BLE001
                continue
            if isinstance(candles, list) and candles:
                bonds.append((mat, candles))
    if skipped:
        notes.append("اخزا: سررسید این نمادها خوانده نشد — "
                     + "، ".join(sorted(skipped)[:5]))
    if not bonds:
        return [], notes + ["اخزا: هیچ تاریخچهٔ قیمتی نیامد."]

    months = monthly(daily_rates(bonds))
    if not months:
        return [], notes + ["اخزا: قیمت‌ها آمدند ولی بازدهی درنیامد — "
                            "ارزش اسمی یا قالب سررسید عوض شده؟"]
    placed = place(months, trading_days)
    if not placed:
        return [], notes + ["اخزا: بازده حساب شد ولی هیچ ماهی روز معاملاتی "
                            "نداشت که رویش بنشیند."]
    rows = [(d, "rfr", round(r * 100, 4), f"chartix/اخزا ({len(syms)} ورقه)")
            for d, r in placed]
    return rows, notes
