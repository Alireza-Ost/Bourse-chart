# -*- coding: utf-8 -*-
"""
چهار سنجهٔ وضعیت بازار، برای گزارش روزانهٔ ربات.

    python3 signals.py            چاپ گزارش
    python3 signals.py --json     همان چیز، ماشین‌خوان

هر سنجه جداگانه خوانده می‌شود و هیچ‌کدام جای دیگری را نمی‌گیرد:

 ۱. روند   — کلید دوحالتهٔ لوندِ–تیمرمان روی شاخص اسمی.
 ۲. چرخه   — چند ماه از آخرین درهٔ تأییدشده گذشته.
 ۳. ارزش   — صدک «ارزش بازار ÷ نقدینگی» نسبت به تاریخ خودش.
 ۴. انباشت — سهم ورود پول حقیقی از ارزش معاملات، + انبساط ارزش.

⚠ این‌ها **توصیف وضعیت‌اند، نه توصیهٔ خرید و فروش**. روی داده‌های
۱۳۹۵ تا ۱۴۰۵ سنجیده شده‌اند و بازهٔ اطمینانشان پهن است.

── چرا این عددها
   آستانهٔ ۱۵٪/۱۰٪ روند: کمتر از این، نوسان معمولی کلید را می‌زند؛
   بیشتر از این، برگشت دیر فهمیده می‌شود. روی هر دو نیمهٔ نمونه
   جواب داد (اختلاف بازده یک‌ساله ‎+۴۰.۴ و ‎+۱۴.۸ واحد).

   آستانهٔ ۴٪ انباشت: پنجک بالای توزیع. میانهٔ بازده ۱۲۶ روز بعدش
   ‎+۴۲.۳٪ بوده در برابر خط پایهٔ ‎+۱۴.۱٪، و ۸۷٪ مواقع مثبت.

   ⚠ RSI و تقاطع میانگین‌ها عمداً این‌جا نیستند: هر دو آزموده شدند و
   نتیجه را **بدتر** کردند. از ۳۵۵ روز انباشت فقط ۱۳ روز RSI زیر ۵۰
   داشته‌اند — در این بازار پول حقیقی در قدرت می‌آید، نه در ضعف.
"""
import bisect
import datetime
import sys

import jdatetime

# ---- پارامترها، همه در یک جا ------------------------------------------
TREND_DOWN, TREND_UP = 0.15, 0.10      # آستانهٔ چرخش کلید روند
ACC_SHARE = 0.04                       # سهم ورود پول پنج‌روزه از ارزش معاملات
ACC_WINDOW = 5                         # طول پنجرهٔ جریان
VALUE_MA = 20                          # میانگین ارزش معاملات
PCT_MIN_HIST = 250                     # کمتر از این، صدک معنی ندارد
RICH_PCT = 0.80                        # از این صدک بالاتر: گران
CLUSTER_GAP = 10                       # فاصلهٔ حداکثرِ دو روز انباشت در یک خوشه
TREND_SINCE = "13900101"               # کلید روند از این‌جا راه می‌افتد


def _load(con, series, since=None):
    q = "SELECT date_j, value FROM observations WHERE series=?"
    a = [series]
    if since:
        q += " AND date_j>=?"
        a.append(since)
    return {d: v for d, v in con.execute(q + " ORDER BY date_j", a)}


def _pct_of_last(series):
    """صدکِ آخرین مقدار نسبت به گذشتهٔ خودش. کم‌داده → None."""
    ks = sorted(series)
    if len(ks) < PCT_MIN_HIST + 1:
        return None
    hist = sorted(series[d] for d in ks[:-1])
    return bisect.bisect_left(hist, series[ks[-1]]) / len(hist)


def trend(con):
    """حالت روند، و این‌که تا چرخش چقدر فاصله هست."""
    idx = _load(con, "index_total", TREND_SINCE)
    days = sorted(idx)
    if len(days) < 50:
        return None
    state, ref, since = 1, idx[days[0]], 0
    for i, d in enumerate(days):
        v = idx[d]
        if state == 1:
            ref = max(ref, v)
            if v <= ref * (1 - TREND_DOWN):
                state, ref, since = 0, v, i
        else:
            ref = min(ref, v)
            if v >= ref * (1 + TREND_UP):
                state, ref, since = 1, v, i
    seg = [idx[d] for d in days[since:]]
    now = seg[-1]
    if state == 1:
        edge = max(seg)
        flip = edge * (1 - TREND_DOWN)
        edge_day = days[since + seg.index(edge)]
    else:
        edge = min(seg)
        flip = edge * (1 + TREND_UP)
        edge_day = days[since + seg.index(edge)]
    return {"state": "مثبت" if state else "منفی",
            "since": days[since], "since_value": idx[days[since]],
            "edge": edge, "edge_day": edge_day, "now": now,
            "from_edge": now / edge - 1, "flip": flip,
            "to_flip": flip / now - 1, "days": len(seg)}


def valuation(con):
    """گران است یا ارزان — صدک نسبت ارزش بازار به نقدینگی، و P/E."""
    out = {}
    for key, name in (("ratio", "نسبت ارزش بازار به نقدینگی"),
                      ("pe_market", "P/E کل بازار")):
        s = _load(con, key)
        if not s:
            continue
        ks = sorted(s)
        out[key] = {"name": name, "date": ks[-1], "value": s[ks[-1]],
                    "pct": _pct_of_last(s)}
    return out


def _accum_inputs(con):
    flow = _load(con, "flow_retail")
    val = _load(con, "value_retail")
    idx = _load(con, "index_total")
    days = sorted(d for d in flow if d in val and d in idx)
    return days, flow, val, idx


def accumulation(con):
    """امروز روز انباشت هست یا نه، و چرا."""
    days, flow, val, _ = _accum_inputs(con)
    if len(days) < VALUE_MA + ACC_WINDOW:
        return None
    w = days[-ACC_WINDOW:]
    f5 = sum(flow[d] for d in w)
    v5 = sum(val[d] for d in w)
    v20 = sum(val[d] for d in days[-VALUE_MA:]) / VALUE_MA
    today = val[days[-1]]
    share = f5 / v5 if v5 else None
    return {"date": days[-1], "flow5": f5, "value5": v5, "share": share,
            "value": today, "value_ma": v20,
            "expansion": today / v20 if v20 else None,
            "flow_ok": share is not None and share > ACC_SHARE,
            "value_ok": v20 and today > v20,
            "is_accum": bool(share is not None and share > ACC_SHARE
                             and v20 and today > v20)}


def support_levels(con, limit=4):
    """
    سطح هر خوشهٔ انباشت = میانگین شاخص با وزن ارزش معاملات.

    یعنی قیمتی که پول واقعاً آن‌جا وارد شده. خوشه‌ای که بالای قیمت
    امروز بیفتد عملاً مقاومت است نه حمایت، و همان‌طور برچسب می‌خورد.
    """
    days, flow, val, idx = _accum_inputs(con)
    if len(days) < VALUE_MA + ACC_WINDOW:
        return []
    vv = [val[d] for d in days]
    run, acc = 0.0, []
    for i in range(len(days)):
        run += vv[i]
        if i >= VALUE_MA:
            run -= vv[i - VALUE_MA]
        if i < VALUE_MA - 1 or i < ACC_WINDOW - 1:
            continue
        ma = run / VALUE_MA
        v5 = sum(vv[i - ACC_WINDOW + 1:i + 1])
        if not v5 or not ma:
            continue
        share = sum(flow[days[j]] for j in range(i - ACC_WINDOW + 1, i + 1)) / v5
        if share > ACC_SHARE and vv[i] > ma:
            acc.append(i)
    clusters = []
    for i in acc:
        if clusters and i - clusters[-1][-1] <= CLUSTER_GAP:
            clusters[-1].append(i)
        else:
            clusters.append([i])
    now = idx[days[-1]]
    out = []
    for c in clusters[-limit:]:
        w = sum(vv[i] for i in c)
        lvl = sum(idx[days[i]] * vv[i] for i in c) / w
        out.append({"from": days[c[0]], "to": days[c[-1]], "days": len(c),
                    "level": lvl, "vs_now": lvl / now - 1,
                    "kind": "مقاومت" if lvl > now else "حمایت"})
    return out


def _j(d):
    return f"{d[:4]}/{d[4:6]}/{d[6:]}"


def report(con):
    """متن فارسی برای تلگرام."""
    L = []
    t = trend(con)
    if t:
        arrow = "🟢" if t["state"] == "مثبت" else "🔴"
        L.append(f"{arrow} <b>روند: {t['state']}</b> — از {_j(t['since'])}")
        edge = "سقف" if t["state"] == "مثبت" else "کف"
        L.append(f"   {edge} {t['edge']:,.0f} ({_j(t['edge_day'])}) · "
                 f"حالا {t['from_edge']:+.1%}")
        L.append(f"   چرخش در {t['flip']:,.0f} — {abs(t['to_flip']):.1%} فاصله")

    v = valuation(con)
    r = v.get("ratio")
    if r and r["pct"] is not None:
        tag = "گران" if r["pct"] >= RICH_PCT else (
            "ارزان" if r["pct"] <= 1 - RICH_PCT else "میانه")
        L.append(f"\n📏 <b>ارزش‌گذاری: {tag}</b> — صدک {r['pct']:.0%}")
        pe = v.get("pe_market")
        if pe and pe["pct"] is not None:
            L.append(f"   P/E {pe['value']:.2f} (صدک {pe['pct']:.0%}"
                     f"{'، ' + _j(pe['date']) if pe['date'] else ''})")

    a = accumulation(con)
    if a and a["share"] is not None:
        mark = "✅" if a["is_accum"] else "➖"
        L.append(f"\n{mark} <b>جریان پول</b> — سهم {a['share']:+.1%} "
                 f"(شرط +{ACC_SHARE:.0%})")
        L.append(f"   ورود پول ۵ روزه {a['flow5']:+,.0f} میلیارد تومان")
        L.append(f"   ارزش معاملات {a['expansion']:.2f} برابر میانگین ۲۰ روزه")
        if a["is_accum"]:
            L.append("   <b>امروز روز انباشت است.</b>")

    lv = support_levels(con)
    if lv:
        L.append("\n🎯 <b>سطوح انباشت</b>")
        for s in lv:
            L.append(f"   {s['level']:,.0f} — {s['kind']} "
                     f"({s['vs_now']:+.1%}) · {_j(s['from'])}")

    if t and a:
        L.append("")
        if t["state"] == "مثبت" and a["is_accum"]:
            L.append("<b>خلاصه:</b> روند مثبت و پول در حال ورود.")
        elif t["state"] == "مثبت":
            L.append("<b>خلاصه:</b> روند هنوز مثبت، ولی جریان پول همراهش نیست.")
        elif a["is_accum"]:
            L.append("<b>خلاصه:</b> روند منفی ولی پول دارد برمی‌گردد.")
        else:
            L.append("<b>خلاصه:</b> روند منفی و پول در حال خروج.")
    L.append("\n<i>توصیف وضعیت است، نه توصیهٔ خرید و فروش.</i>")
    return "\n".join(L)


def main():
    from store import connect
    con = connect()
    if "--json" in sys.argv:
        import json
        print(json.dumps({"trend": trend(con), "valuation": valuation(con),
                          "accumulation": accumulation(con),
                          "levels": support_levels(con)},
                         ensure_ascii=False, indent=1, default=str))
    else:
        import re
        print(re.sub(r"</?[bi]>", "", report(con)))
    con.close()


if __name__ == "__main__":
    main()
