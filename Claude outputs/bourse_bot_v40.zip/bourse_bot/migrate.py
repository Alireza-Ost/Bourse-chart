# -*- coding: utf-8 -*-
"""
مهاجرت‌های خودکار — چیزهایی که باید یک بار روی دیتابیسِ موجود اجرا شوند.

هر بار که ربات بالا می‌آید صدا زده می‌شود و اگر کاری لازم نباشد ساکت است.
دلیل وجودش: دیتابیس شما بیرون از پوشهٔ پروژه است (تا با به‌روزرسانی کد پاک
نشود)، پس دیتابیسِ اولیهٔ همراه نسخهٔ تازه به دستتان نمی‌رسد. هر سری تازه‌ای
که بعداً اضافه شود، از این مسیر وارد دیتابیسِ خودتان می‌شود.

هر سری جداگانه بررسی می‌شود، نه همه با هم — وگرنه اضافه‌شدن سری چهارم به
دیتابیسی که سه سری اول را دارد نادیده گرفته می‌شود.
"""
from config import BASE

CHARTIX_DIR = BASE / "data" / "chartix"

# کلید سری -> (نام فایل، مقسوم‌علیه واحد، برچسب)
CHARTIX = [
    ("mv_tse", "mv_tse.csv", "RIAL_PER_HEMAT", "ارزش بازار بورس"),
    ("mv_ifb", "mv_ifb.csv", "RIAL_PER_HEMAT", "ارزش بازار فرابورس"),
    ("mv_usd", "mv_usd.csv", "USD_PER_BILLION", "ارزش دلاری بازار"),
    ("gold18", "gold18.csv", "ONE",             "طلای ۱۸ عیار"),
]


def ensure_market_value(con, log=print):
    """هر سری چارتیکسی که در دیتابیس نیست را از CSV همراه پروژه وارد می‌کند."""
    import import_chartix as ix
    DIVISORS = {"RIAL_PER_HEMAT": ix.RIAL_PER_HEMAT,
                "USD_PER_BILLION": ix.USD_PER_BILLION,
                "ONE": 1.0}

    todo = []
    for series, fname, div, label in CHARTIX:
        have = con.execute("SELECT COUNT(*) FROM observations WHERE series=?",
                           (series,)).fetchone()[0]
        if have or not (CHARTIX_DIR / fname).exists():
            continue
        todo.append((series, fname, DIVISORS[div], label))
    if not todo:
        return False

    log("سری‌های تازه پیدا شد — از فایل‌های همراه پروژه اضافه می‌شود…")

    # اگر ارزش بازار بورس/فرابورس تازه می‌آید، ردیف‌های «ارزش بازار» از منابع
    # ضعیف‌تر باید بروند: اختلاف سطحشان حدود ۸٪ است و سری را پله‌دار می‌کند.
    if any(t[0] in ("mv_tse", "mv_ifb") for t in todo):
        con.execute("DELETE FROM observations WHERE series IN ('mv','ratio') "
                    "AND source IN ('xlsx_seed','json_restore','unknown')")
        con.commit()

    touched = set()
    for series, fname, divisor, label in todo:
        rows = ix.load(con, CHARTIX_DIR / fname, series, divisor, label)
        touched |= set(rows)

    from store import derive_totals
    derive_totals(con, touched)
    log("انجام شد.")
    return True


def ensure_usd_rate(con, log=print):
    """
    نرخ دلار را از تاریخچه بازسازی می‌کند: ارزش بازار (همت) ÷ ارزش دلاری
    (میلیارد دلار) × ۱۰^۳ = تومان به ازای هر دلار. همان نرخی که خود چارتیکس
    برای ساختن سری دلاری استفاده کرده، پس «ضمنی» است نه یک منبع مستقل.
    """
    from store import upsert
    have = con.execute(
        "SELECT COUNT(*) FROM observations WHERE series='usd_rate'").fetchone()[0]
    if have:
        return False
    mv = dict(con.execute("SELECT date_j, value FROM observations WHERE series='mv'"))
    usd = dict(con.execute("SELECT date_j, value FROM observations WHERE series='mv_usd'"))
    shared = sorted(set(mv) & set(usd))
    if not shared:
        return False
    for date_j in shared:
        if usd[date_j]:
            upsert(con, date_j, "usd_rate", mv[date_j] * 1e3 / usd[date_j],
                   "chartix", "ارزش بازار ÷ ارزش دلاری")
    log(f"نرخ دلار برای {len(shared)} روز ساخته شد ({shared[0]} → {shared[-1]}).")
    return True


def ensure_m2_months(con, log=print):
    """
    مهاجرت نقدینگی به مدل ماهانه.

    تا دیروز نرخ رشد فرضی مستقیم روی روزها نوشته می‌شد (منبع m2_estimate) و
    اصلاحش دردسر بود. حالا *ورودی* ذخیره می‌شود نه خروجی. این تابع نرخ
    ماه‌هایی که قبلاً برآورد شده بودند را از روی خود داده بازسازی می‌کند تا
    چیزی که الان می‌بینید عوض نشود و از این به بعد قابل اصلاح باشد.
    """
    import m2
    m2.ensure(con)
    if con.execute("SELECT COUNT(*) FROM m2_months").fetchone()[0]:
        return False

    rows = con.execute(
        "SELECT date_j, value FROM observations WHERE series='m2' "
        "AND source='m2_estimate' ORDER BY date_j").fetchall()
    if not rows:
        return False

    anchor = m2.base_anchor(con)
    if not anchor:
        return False
    prev = anchor[1]
    for date_j, value in rows:
        if prev:
            m2.set_month(con, date_j[:6], "rate", (value / prev - 1) * 100,
                         "منتقل‌شده از برآورد قبلی")
        prev = value
    log(f"نقدینگی به مدل ماهانه منتقل شد ({len(rows)} ماه). "
        "با /m2months ببینیدش، با /m2real رقم واقعی بانک مرکزی را بنویسید.")
    m2.rebuild(con)
    return True


PE_CSV = BASE / "data" / "pe_mofid.csv"


def ensure_pe_market(con, log=print):
    """
    P/E کل بازار از «داده‌های کلان» کارگزاری مفید — ۳٬۹۹۷ روز از
    ۱۳۸۸/۱۰/۱۲ تا امروز.

    تا پیش از این فقط ۱۰۳ روز P/E داشتیم (۱۴۰۰/۱۱ تا ۱۴۰۱/۰۵) که از
    اکسل اولیه آمده بود. هیچ منبع رایگان دیگری تاریخچهٔ P/E *کل بازار*
    نداشت؛ آنچه بقیه می‌فروختند P/E تک‌تک نمادها بود.

    ⚠ همهٔ روزها از مفید نوشته می‌شوند، حتی آن‌هایی که از قبل P/E دارند.
      اولش فقط جای خالی را پر می‌کرد و ۱۰۳ روزِ اکسل اولیه (۱۴۰۰/۱۱ تا
      ۱۴۰۱/۰۵) دست‌نخورده می‌ماند؛ ولی تعریفشان با مفید یکی نبود —
      به‌طور میانه ۱٬۴٪ و تا ۲۲٬۶٪ اختلاف داشتند. یک سری که وسطش تعریف
      عوض شود بدتر از سری‌ای است که یک منبع دارد، پس همه یکدست شدند.
    """
    import csv
    if not PE_CSV.exists():
        return False
    have = dict(con.execute(
        "SELECT date_j, value FROM observations WHERE series='pe_market'"))
    rows = list(csv.DictReader(open(PE_CSV, encoding="utf-8")))
    todo = [(r["date_j"], float(r["pe_market"])) for r in rows
            if abs(have.get(r["date_j"], -1) - float(r["pe_market"])) > 1e-9]
    if not todo:
        return False

    from store import upsert
    n = 0
    for date_j, value in todo:
        if upsert(con, date_j, "pe_market", value, "mofid",
                  "bourseview.emofid.com · p2e-ttm").split(":")[0] \
                in ("inserted", "updated"):
            n += 1
    log(f"P/E کل بازار: {n} روز از مفید نوشته شد "
        f"({todo[0][0]} تا {todo[-1][0]}).")
    return True


TA_CSV = BASE / "data" / "tradersarena.csv"
TA_SERIES = ["value_retail", "flow_retail", "sarane_buy", "sarane_sell",
             "index_total", "index_ew"]


def ensure_tradersarena(con, log=print):
    """
    سوابق بازار تریدرزآرنا — ۲٬۴۷۵ روز معاملاتی از ۱۳۹۵/۰۱/۰۷ تا ۱۴۰۵/۰۷/۲۲.

    این همان خروجی اکسلِ اشتراک طلایی است که به CSV تبدیل شده (واحدها هم
    تبدیل شده‌اند: ستون‌های اکسل تومان‌اند، اینجا میلیارد و میلیون تومان).

    ⚠ فقط جای خالی پر می‌شود. هیچ روزی که از قبل در دیتابیس عدد دارد
      عوض نمی‌شود — نه اینکه از قلم افتاده باشد، عمدی است:

      • شاخص کل و هم‌وزن: در ۱٬۴۳۷ روز مشترک، *صفر* اختلاف. یکی‌اند.
      • ارزش معاملات و ورود پول: تعریفشان کامل یکی نیست. نسبت میانه
        ۱٬۰۰۵ ولی چارک‌ها ۰٬۹۶ تا ۱٬۰۹، و هرچه عقب‌تر فاصله بیشتر
        (۱۳۹۹/۰۳/۱۰: ۹٬۴۰۰ مقابل ۸٬۴۷۸). اگر نیمی از روزها از این منبع
        و نیمی از آن باشد سری حدود ۱۳۹۹ یک پلهٔ دیدنی پیدا می‌کند. پس
        روزهای موجود دست‌نخورده می‌مانند و فقط خلأها پر می‌شوند.
      • سرانهٔ خرید و فروش: کلاً تازه است، ۲٬۴۷۵ روز.

      اگر خواستید یک سری *یکدست* از تریدرزآرنا شود (یعنی روزهای موجود هم
      بازنویسی شوند) این را دستی بزنید:
          python import_tradersarena.py <اکسل> --overwrite value_retail
    """
    import csv
    if not TA_CSV.exists():
        return False
    have = {s: {r[0] for r in con.execute(
        "SELECT date_j FROM observations WHERE series=?", (s,))} for s in TA_SERIES}
    rows = list(csv.DictReader(open(TA_CSV, encoding="utf-8")))
    todo = []
    for r in rows:
        d = r["date_j"]
        for s in TA_SERIES:
            v = r.get(s, "")
            if v != "" and d not in have[s]:
                todo.append((d, s, float(v)))
    if not todo:
        return False

    from store import upsert
    n, per = 0, {}
    for date_j, series, value in todo:
        if upsert(con, date_j, series, value, "tradersarena",
                  "tradersarena.ir · سوابق بازار").split(":")[0] \
                in ("inserted", "updated"):
            n += 1
            per[series] = per.get(series, 0) + 1
    log(f"سوابق بازار تریدرزآرنا: {n} مقدار تازه اضافه شد — "
        + "، ".join(f"{s} {c}" for s, c in sorted(per.items(), key=lambda x: -x[1]))
        + ". روزهای موجود دست نخورد.")
    return True


#  نام فایل  ->  (برچسب، سری‌ها)
# هر سبد یک فایل، هر فایل دو سری. اضافه‌کردن سبد تازه (نقره، پنجاه شرکت
# بزرگ، …) یک سطر اینجا و یک سطر در SERIES است و بس.
TA_BASKETS = [
    ("tradersarena_fixed.csv",    "صندوق درآمد ثابت", ["value_fixed", "flow_fixed"]),
    ("tradersarena_lev.csv",      "صندوق اهرمی",      ["value_lev", "flow_lev"]),
    ("tradersarena_goldfund.csv", "صندوق طلا",        ["value_goldfund", "flow_goldfund"]),
]

TAF_CSV = BASE / "data" / "tradersarena_fixed.csv"   # نام قدیمی، برای سازگاری
TAF_SERIES = ["value_fixed", "flow_fixed"]


def ensure_tradersarena_fixed(con, log=print):
    """
    سبدهای صندوق از خروجی‌های اختصاصی تریدرزآرنا — هر سبد فایل خودش:

        صندوق درآمد ثابت   ۲٬۵۲۵ روز   ۱۳۹۵/۰۱/۰۷ → ۱۴۰۵/۰۷/۲۲
        صندوق اهرمی        ۱٬۰۸۵ روز   ۱۴۰۰/۰۹/۲۹ → ۱۴۰۵/۰۷/۲۲
        صندوق طلا          ۱٬۹۴۴ روز   ۱۳۹۶/۰۳/۲۰ → ۱۴۰۵/۰۷/۲۲

    ⚠ اهرمی زیرمجموعهٔ «ارزش معاملات خرد» است (صندوق سهامی است) و طلا
      بیرون آن. جمعشان با ارزش معاملات خرد معنی ندارد؛ جدا دیده می‌شوند.

    دربارهٔ درآمد ثابت: تا پیش از این این دو سری فقط از *تفاضل* جدول
    type=0 و type=1 ساخته می‌شد و تاریخچه نداشت. دو روش را روی
    ۱۴۰۵/۰۷/۱۲ سنجیدم:

    تا پیش از این، این دو سری فقط از *تفاضل* دو جدول type=0 و type=1
    ساخته می‌شد و برای همین هیچ تاریخچه‌ای نداشت. حالا خود منبع رقم را
    جدا می‌دهد. دو روش را روی ۱۴۰۵/۰۷/۱۲ سنجیدم:

        ارزش معاملات   تفاضل ۴۸٬۱۶۵٫۳   مستقیم ۴۸٬۱۶۲٫۶   (۰٫۰۱٪)
        ورود پول       تفاضل  ۳٬۹۲۶٫۸   مستقیم  ۳٬۹۲۴٫۰   (۰٫۰۷٪)

        ارزش معاملات   تفاضل ۴۸٬۱۶۵٫۳   مستقیم ۴۸٬۱۶۲٫۶   (۰٫۰۱٪)
        ورود پول       تفاضل  ۳٬۹۲۶٫۸   مستقیم  ۳٬۹۲۴٫۰   (۰٫۰۷٪)

    یعنی هر دو درست‌اند، ولی مستقیم بهتر است: خطای تفاضلِ دو عدد بزرگ را
    ندارد و یک فایل کمتر می‌خواهد.

    ⚠ فایل درآمد ثابت ۵۰ روز بیشتر از جدول اصلی دارد: روزهایی که بورس
      بسته بود ولی صندوق‌ها معامله می‌شدند (تیر ۱۴۰۴ و بازهٔ تعطیلی
      ۱۴۰۴/۱۲ به بعد). آن روزها در دیتابیس می‌نشینند ولی روی محور نمودار
      نمی‌آیند، چون محور تقویمش را از شاخص کل می‌گیرد.

    مثل بقیه، فقط جای خالی پر می‌شود.
    """
    import csv
    from store import upsert
    did = False
    for fname, label, series_list in TA_BASKETS:
        path = BASE / "data" / fname
        if not path.exists():
            continue
        have = {s: {r[0] for r in con.execute(
            "SELECT date_j FROM observations WHERE series=?", (s,))}
            for s in series_list}
        todo = []
        for r in csv.DictReader(open(path, encoding="utf-8")):
            for s in series_list:
                v = r.get(s, "")
                if v != "" and r["date_j"] not in have[s]:
                    todo.append((r["date_j"], s, float(v)))
        if not todo:
            continue

        n, per = 0, {}
        for date_j, s, value in todo:
            if upsert(con, date_j, s, value, "tradersarena",
                      f"tradersarena.ir · {label}").split(":")[0] \
                    in ("inserted", "updated"):
                n += 1
                per[s] = per.get(s, 0) + 1
        log(f"{label}: {n} مقدار تازه اضافه شد — "
            + "، ".join(f"{s} {c}" for s, c in sorted(per.items())) + ".")
        did = True
    return did


# سبدهای صندوق دو جا زندگی می‌کنند: به‌عنوان سری بازار در observations
# (`value_fixed`، `flow_fixed`، …) و به‌عنوان یک «صنعت» در industry_obs.
# جدولِ اول قدیمی‌تر است و درآمد ثابت فقط در همان وارد شده بود، پس در
# فهرست صنایع نبود. این نگاشت همان رقم‌ها را به جدول صنایع هم می‌رساند.
BASKET_AS_IND = [
    ("fixed-income-funds", {"value": "value_fixed",
                            "flow":  "flow_fixed"}),
    ("leveraged-funds",    {"value": "value_lev",
                            "flow":  "flow_lev"}),
    ("gold-funds",         {"value": "value_goldfund",
                            "flow":  "flow_goldfund"}),
]


def ensure_basket_industries(con, log=print):
    """
    سبدهای صندوق را در جدول صنایع هم بنشان.

    چرا لازم شد: «صندوق درآمد ثابت» از همان روز اول به‌صورت دو سریِ بازار
    وارد شده بود (`value_fixed` و `flow_fixed`، ۲٬۵۲۵ روز از ۱۳۹۵/۰۱/۰۷)،
    ولی جدول صنایع چند ماه بعد ساخته شد و هیچ‌وقت کسی این دو را به آن
    نرساند. نتیجه این بود که اهرمی و طلا و زعفران در فهرست صنایع بودند و
    درآمد ثابت — که از همهٔ آن‌ها بزرگ‌تر است — نبود.

    رقم‌ها دوباره از منبع گرفته نمی‌شوند؛ همان ردیف‌های موجود کپی می‌شوند،
    با همان منبعِ اصلی‌شان تا نردبان اولویت دست‌نخورده بماند. فقط جای خالی
    پر می‌شود (`only_new`)، پس اگر اکسل یا API همان روز را با هفت سری
    کامل‌تر داده باشد، دست به آن نمی‌خورد.

    برعکسش را نمی‌کنیم: ردیف صنعتی به سری بازار تبدیل نمی‌شود، چون
    تعریف «ارزش معاملات صنعت» و «ارزش معاملات سبد» همیشه یکی نیست و
    سری بازار منبع رسمی خودش را دارد.
    """
    from store import upsert_ind
    total, per_ind = 0, []
    for ind, mapping in BASKET_AS_IND:
        n = 0
        for metric, series in mapping.items():
            have = {r[0] for r in con.execute(
                "SELECT date_j FROM industry_obs WHERE ind=? AND metric=?",
                (ind, metric))}
            rows = con.execute(
                "SELECT date_j, value, source FROM observations WHERE series=?",
                (series,)).fetchall()
            for date_j, value, source in rows:
                if date_j in have:
                    continue
                if upsert_ind(con, date_j, ind, metric, value, source,
                              f"{series} → صنایع", only_new=True) == "inserted":
                    n += 1
        if n:
            per_ind.append((ind, n))
            total += n
    if total:
        con.commit()
        log("سبدهای صندوق در فهرست صنایع: "
            + "، ".join(f"{i} {c}" for i, c in per_ind) + ".")
    return total > 0


def ensure_basket_from_industries(con, log=print):
    """
    عکسِ `ensure_basket_industries`: سری بازار را از ردیف صنعتی پر کن.

    چرا این یکی هم لازم شد: برداشت روزانه سبدها را از صفحهٔ اول
    تریدرزآرنا می‌گیرد که **فقط یک روز** می‌دهد، ولی صفحهٔ سوابق صنایع
    ده روز می‌دهد. پس اگر کامپیوتر چند روز خاموش بماند، ردیف صنعتیِ
    «صندوق اهرمی» پر می‌شود و سری بازارِ `value_lev` خالی می‌ماند — در
    نموداری که هر دو را نشان می‌دهد، یکی ادامه دارد و دیگری وسط راه
    می‌بُرد.

    چرا این‌جا مجاز است در حالی که قاعدهٔ کلی «صنعت به بازار نه» است:
    این سه سبد همان ردیف‌اند، نه دو تعریف نزدیک. روی روزهای مشترک
    (۱۴۰۵/۰۷/۱۹ تا ۰۷/۲۲) هر چهار سری تا دو رقم اعشار **عیناً** یکی
    درآمدند — ۱۱٬۹۹۳٫۰۷ و ۹٬۷۵۰٫۲۶ و ۴٬۸۷۳٫۲۳ و ۱۱۷٫۸ — چون هر دو از
    همان جدول تریدرزآرنا می‌آیند. برای صنعت‌های واقعی چنین چیزی ثابت
    نشده و همان قاعدهٔ کلی سر جایش است.

    فقط جای خالی پر می‌شود، و فقط از ردیفی که منبعش تریدرزآرناست.
    """
    from store import upsert
    n, per = 0, []
    for ind, mapping in BASKET_AS_IND:
        c = 0
        for metric, series in mapping.items():
            have = {r[0] for r in con.execute(
                "SELECT date_j FROM observations WHERE series=?", (series,))}
            rows = con.execute(
                "SELECT date_j, value, source FROM industry_obs "
                "WHERE ind=? AND metric=?", (ind, metric)).fetchall()
            for date_j, value, source in rows:
                if date_j in have or source != "tradersarena":
                    continue
                if upsert(con, date_j, series, value, source,
                          f"صنایع → {series}").split(":")[0] == "inserted":
                    c += 1
        if c:
            per.append((ind, c))
            n += c
    if n:
        con.commit()
        log("سبدهای صندوق از جدول صنایع: "
            + "، ".join(f"{i} {c}" for i, c in per) + ".")
    return n > 0


IND_BUNDLE = BASE / "data" / "industries.csv.gz"
EXTRA_BUNDLE = BASE / "data" / "market_extra.csv"


def ensure_industry_bundle(con, log=print):
    """
    جدول صنایع از فایل همراهِ کد — `data/industries.csv.gz`.

    چرا لازم است: اکسل‌های صنایع را در گفت‌وگو می‌فرستید و همان‌جا وارد
    می‌شوند، ولی آن دیتابیس روی کامپیوتر شما نیست. بقیهٔ منابع این مشکل را
    نداشتند چون فایل خامشان در زیپ است (`data/tradersarena*.csv`،
    `data/chartix/*.csv`، `data/pe_mofid.csv`) و مهاجرت‌های بالا از روی
    همان‌ها دیتابیس شما را پر می‌کنند. این فایل همان نقش را برای صنایع
    بازی می‌کند. با `export_bundle.py` ساخته می‌شود.

    قالبش پیوت‌شده است: یک ردیف برای هر (تاریخ، صنعت) و یک ستون برای هر
    سری — ۸۶ هزار ردیف به‌جای ۵۸۸ هزار.

    ⚠ فقط جای خالی پر می‌شود (`only_new=True`). ردیفی که برداشت روزانهٔ
      خودتان نوشته یا از اکسل تازه‌تری آمده دست نمی‌خورد، حتی اگر عددش با
      این فایل فرق داشته باشد.
    """
    import csv
    import gzip
    from store import upsert_ind
    if not IND_BUNDLE.exists():
        return False

    have = {(r[0], r[1], r[2]) for r in con.execute(
        "SELECT date_j, ind, metric FROM industry_obs")}
    n, seen_ind = 0, set()
    with gzip.open(IND_BUNDLE, "rt", encoding="utf-8", newline="") as fh:
        rd = csv.DictReader(fh)
        metrics = [c for c in (rd.fieldnames or [])
                   if c not in ("date_j", "ind", "source")]
        for row in rd:
            date_j, ind = row["date_j"], row["ind"]
            src = row.get("source") or "tradersarena"
            for m in metrics:
                v = row.get(m, "")
                if v == "" or (date_j, ind, m) in have:
                    continue
                if upsert_ind(con, date_j, ind, m, float(v), src,
                              "industries.csv.gz", only_new=True) == "inserted":
                    n += 1
                    seen_ind.add(ind)
    if n:
        con.commit()
        log(f"صنایع از فایل همراه: {n:,} مقدار تازه روی {len(seen_ind)} صنعت.")
    return n > 0


def ensure_market_extra(con, log=print):
    """
    سری‌های بازاری که فایل خام ندارند — `data/market_extra.csv`.

    سه منبع این‌جا می‌آیند:

        m2_file       نقدینگی ۱۳۹۰ تا ۱۴۰۱ از اکسلی که فرستادید
        json_restore  چند روزی که فقط روی صفحهٔ منتشرشده مانده بود
        manual        ورودی‌های دستی (۱۴۰۵/۰۷/۱۴ و ارزش دلاری محاسبه‌شده)

    منبع و ارجاع هر ردیف از فایل خوانده می‌شود، نه ثابت — پس نردبان
    اولویت همان‌طور کار می‌کند که این‌جا کرده بود. باز هم فقط جای خالی.
    """
    import csv
    from store import upsert, derive_totals
    if not EXTRA_BUNDLE.exists():
        return False

    have = {(r[0], r[1]) for r in con.execute(
        "SELECT date_j, series FROM observations")}
    n, per, skipped, touched = 0, {}, [], set()
    with open(EXTRA_BUNDLE, encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh):
            key = (row["date_j"], row["series"])
            if key in have or row["value"] == "":
                continue
            # `upsert` پارامتر only_new ندارد؛ لازم هم نیست — ردیف‌هایی که
            # از قبل هستند بالاتر کنار گذاشته شدند، پس این‌جا هر چه می‌رسد
            # جای خالی است.
            res = upsert(con, row["date_j"], row["series"], float(row["value"]),
                         row["source"], row.get("src_ref", ""))
            if res.split(":")[0] == "inserted":
                n += 1
                touched.add(row["date_j"])
                per[row["series"]] = per.get(row["series"], 0) + 1
            elif res.startswith("rejected"):
                skipped.append(f"{row['date_j']} {row['series']}: {res[10:]}")
    if n:
        # نقدینگیِ تازه یعنی «نسبت ارزش بازار به نقدینگی» آن روزها باید از
        # نو حساب شود، وگرنه عدد تازه در جدول می‌نشیند ولی نمودار نسبت
        # همان خلأ قبلی را دارد.
        derive_totals(con, touched)
        con.commit()
        log("سری‌های بی‌فایل: " + "، ".join(f"{s} {c}" for s, c in sorted(per.items())) + ".")
    if skipped:
        log(f"  {len(skipped)} مقدار اعتبارسنجی را رد نکرد — "
            + skipped[0] + (" …" if len(skipped) > 1 else ""))
    return n > 0


IDX_CSV = BASE / "data" / "chartix" / "index_total.csv"


def ensure_index_history(con, log=print):
    """
    تاریخچهٔ شاخص کل از CSV چارتیکس — ۸٬۰۳۰ روز از ۱۳۷۱/۱۲/۱۵ تا ۱۴۰۵/۰۷/۰۱.

    این دو منبع را روی ۲٬۴۵۸ روز مشترک مقایسه کردم: نسبت میانه دقیقاً
    ۱٬۰۰۰۰۰ و بیشترین انحراف ۰٬۰۶٪ — یعنی عیناً یک سری‌اند، نه دو تعریف.
    پس پرکردن خلأ با این هیچ پله‌ای نمی‌سازد (برعکس ارزش معاملات).

    ⚠ مثل بقیه، فقط جای خالی پر می‌شود.
    """
    import csv
    if not IDX_CSV.exists():
        return False
    have = {r[0] for r in con.execute(
        "SELECT date_j FROM observations WHERE series='index_total'")}
    todo = [(r["date_j"], float(r["index_total"]))
            for r in csv.DictReader(open(IDX_CSV, encoding="utf-8"))
            if r["date_j"] not in have]
    if not todo:
        return False

    from store import upsert
    n = 0
    for date_j, value in todo:
        if upsert(con, date_j, "index_total", value, "chartix",
                  "chartix.ir · CSV شاخص کل").split(":")[0] \
                in ("inserted", "updated"):
            n += 1
    log(f"شاخص کل: {n} روز تازه اضافه شد ({todo[0][0]} تا {todo[-1][0]}). "
        f"{len(have)} روز قبلی دست نخورد.")
    return True


# ردیف‌هایی که باگ علامت یونیکدی خراب کرده بود — دست‌خوانده از خودِ
# tradersarena.ir/market/history در ۱۴۰۵/۰۸/۰۵. (روز، ورود پولِ type=1،
# ورود پولِ type=0). صندوق درآمد ثابت = type0 − type1، همان قاعدهٔ
# همیشگی، پس همان‌جا حساب می‌شود نه این‌که عدد سومی اینجا بنویسم.
FLOW_SIGN_FIX = [
    ("14050722",  -402.6,  2400.0),
    ("14050725", -7976.9, -6623.5),
    ("14050726", -2817.6, -3789.1),
    ("14050727",  3309.8,  3788.4),
    ("14050728",   358.2, -2905.2),
    ("14050729", -4108.0, -1448.9),
    ("14050802", -8121.7, -7708.1),
    ("14050803", -2194.4,   449.4),
    ("14050804",   990.7,  2510.3),
    ("14050805", -7225.9, -6591.0),
]


def ensure_flow_sign_fix(con, log=print):
    """
    تنها جایی در کل برنامه که یک مقدارِ *موجود* را بازنویسی می‌کند.

    چرا لازم شد: تریدرزآرنا ستون فارسی‌رقم «ورود پول» را با U+2212
    می‌نویسد نه خط‌تیرهٔ اَسکی، و `num()` علامت را بی‌صدا می‌انداخت
    (توضیح کامل در sources/common.py). مقدارها درست بودند، فقط مثبت
    شده بودند — یعنی روزِ خروج پول، ورود پول ثبت می‌شد. ۱۴۰۵/۰۷/۲۹ و
    ۰۸/۰۲ و ۰۸/۰۳ همین‌طور بودند.

    حالا که `num()` درست شده، هر /fetch خودش این روزها را تصحیح می‌کند
    — *تا وقتی* در پنجرهٔ ۱۰روزهٔ سایت باشند. این مهاجرت همان تصحیح را
    بدون وابستگی به زمان و اینترنت انجام می‌دهد.

    سه قید سخت، تا به دادهٔ سالم دست نزند:
      ۱. فقط همین ۱۰ روز، فقط دو سری flow_retail و flow_fixed؛
      ۲. فقط ردیفی که منبعش خودِ tradersarena است (پارسیس و روزانه و
         اکسل، با اولویت بالاتر یا منبع مستقل، دست‌نخورده می‌مانند)؛
      ۳. فقط اگر مقدار ذخیره‌شده با مقدار درست فرق داشته باشد — پس اجرای
         دوم هیچ کاری نمی‌کند و لاگ هم ساکت است.
    """
    import datetime
    want = {}
    for date_j, f1, f0 in FLOW_SIGN_FIX:
        want[(date_j, "flow_retail")] = f1
        want[(date_j, "flow_fixed")] = round(f0 - f1, 4)

    todo = []
    for (date_j, series), value in want.items():
        r = con.execute("SELECT value, source FROM observations "
                        "WHERE date_j=? AND series=?", (date_j, series)).fetchone()
        if r is None or r[1] != "tradersarena":
            continue
        if abs(r[0] - value) < 0.05:
            continue
        todo.append((date_j, series, r[0], value))
    if not todo:
        return False

    now = datetime.datetime.now().isoformat(timespec="seconds")
    for date_j, series, _old, value in todo:
        con.execute("UPDATE observations SET value=?, ingested_at=? "
                    "WHERE date_j=? AND series=?", (value, now, date_j, series))

    # `flow_fixed` در جدول صنایع هم آینه شده (ensure_basket_industries).
    # آن‌جا قاعدهٔ only_new حاکم است، پس خودش تصحیح نمی‌شود و ردیف غلط
    # می‌ماند و تبِ صنایع عدد وارونه نشان می‌دهد. همان قید منبع این‌جا هم
    # اعمال می‌شود، فقط روی ردیفی که از همین سری آمده.
    mirror = 0
    for date_j, series, _old, value in todo:
        if series != "flow_fixed":
            continue
        r = con.execute("SELECT value, source FROM industry_obs WHERE date_j=? "
                        "AND ind='fixed-income-funds' AND metric='flow'",
                        (date_j,)).fetchone()
        if r is None or r[1] != "tradersarena" or abs(r[0] - value) < 0.05:
            continue
        con.execute("UPDATE industry_obs SET value=?, ingested_at=? WHERE date_j=? "
                    "AND ind='fixed-income-funds' AND metric='flow'",
                    (value, now, date_j))
        mirror += 1

    con.commit()
    log(f"علامت ورود پول: {len(todo)} ردیف تصحیح شد — " + "، ".join(
        f"{d} {s} {o:+,.1f}→{v:+,.1f}" for d, s, o, v in sorted(todo)))
    if mirror:
        log(f"  و {mirror} ردیف آینه‌شده در جدول صنایع (درآمد ثابت).")
    return True


RFR_CSV = BASE / "data" / "rfr.csv"


def ensure_rfr(con, log=print):
    """
    نرخ بهرهٔ بدون ریسک — ۷۹ ماه از ۱۳۹۹/۰۲ تا ۱۴۰۵/۰۸، همراه کد.

    برداشت روزانه فقط شش ماه آخر را می‌بیند (۱۳۰ کندل روزانهٔ چارتیکس)،
    پس تاریخچهٔ بلند از این فایل می‌آید. خودِ فایل با همان کدِ
    `sources/akhza.py` ساخته شده که برداشت روزانه هم با آن حساب می‌کند،
    نه یک محاسبهٔ جداگانه که با آن در برود.

    مثل بقیه فقط جای خالی پر می‌شود.
    """
    import csv
    if not RFR_CSV.exists():
        return False
    have = {r[0] for r in con.execute(
        "SELECT date_j FROM observations WHERE series='rfr'")}
    todo = []
    with open(RFR_CSV, encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            if r["date_j"] in have:
                continue
            try:
                todo.append((r["date_j"], float(r["rfr"])))
            except (TypeError, ValueError):
                continue
    if not todo:
        return False

    from store import upsert
    n = 0
    for date_j, value in todo:
        if upsert(con, date_j, "rfr", value, "akhza",
                  "بازده تا سررسید اسناد خزانه").split(":")[0] \
                in ("inserted", "updated"):
            n += 1
    log(f"نرخ بهره بدون ریسک: {n} ماه تازه ({todo[0][0]} تا {todo[-1][0]}). "
        f"{len(have)} ماه قبلی دست نخورد.")
    return True


FLOW_FIX = BASE / "data" / "flow_fix.csv"


def ensure_industry_flow_sign(con, log=print):
    """
    همتای `ensure_flow_sign_fix` برای جدول صنایع.

    چرا جدا لازم شد: باگ U+2212 دو پارسر عدد داشت، نه یکی.
    `sources.common.num` ورود پولِ *بازار* را خراب می‌کرد و
    `import_tradersarena.number` ورود پولِ *صنایع* را — همان تابعی که
    `backfill_industries` با آن صفحهٔ سوابق هر صنعت را می‌خواند.

    نکتهٔ مهم: برداشت روزانه از API صنایع می‌آید که عددش JSON است و
    علامتش سالم. پس فقط روزهایی خراب‌اند که کامپیوتر خاموش بوده و
    `backfill_industries` بعداً از روی HTML پرشان کرده. برای کسی که هر
    روز ربات را زده، این مهاجرت هیچ کاری نمی‌کند.

    `data/flow_fix.csv` مقدار درستِ ۱۰ روزِ پنجرهٔ سایت را دارد، خوانده‌شده
    از خودِ تریدرزآرنا با پارسر تصحیح‌شده. قید سخت: ردیف فقط وقتی عوض
    می‌شود که **قدر مطلقش با مقدار درست یکی باشد و علامتش فرق کند** —
    یعنی دقیقاً همان امضای این باگ. اگر عدد واقعاً چیز دیگری باشد
    (منبع بهتر، تجدیدنظر سایت) دست‌نخورده می‌ماند.
    """
    import csv
    import datetime
    if not FLOW_FIX.exists():
        return False
    want = {}
    with open(FLOW_FIX, encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            try:
                want[(r["date_j"], r["ind"])] = float(r["flow"])
            except (TypeError, ValueError):
                continue
    if not want:
        return False

    todo = []
    for (date_j, ind), good in want.items():
        r = con.execute("SELECT value, source FROM industry_obs WHERE date_j=? "
                        "AND ind=? AND metric='flow'", (date_j, ind)).fetchone()
        if r is None or r[1] != "tradersarena":
            continue
        cur = r[0]
        if cur == 0 or good == 0:
            continue
        if (cur > 0) == (good > 0):
            continue                       # علامتش درست است، کاری نداریم
        if abs(abs(cur) - abs(good)) > max(abs(good) * 0.005, 0.06):
            continue                       # عدد دیگری است، نه وارونهٔ همین
        todo.append((date_j, ind, cur, good))
    if not todo:
        return False

    now = datetime.datetime.now().isoformat(timespec="seconds")
    for date_j, ind, _cur, good in todo:
        con.execute("UPDATE industry_obs SET value=?, ingested_at=? WHERE date_j=? "
                    "AND ind=? AND metric='flow'", (good, now, date_j, ind))
    con.commit()
    days = sorted({d for d, _, _, _ in todo})
    log(f"علامت ورود پول صنایع: {len(todo)} ردیف تصحیح شد "
        f"({days[0]} تا {days[-1]}).")
    return True


def run_all(con, log=print):
    a = ensure_market_value(con, log)
    b = ensure_usd_rate(con, log)
    c = ensure_m2_months(con, log)
    d = ensure_pe_market(con, log)
    e = ensure_tradersarena(con, log)
    f = ensure_index_history(con, log)
    g = ensure_tradersarena_fixed(con, log)
    # داده‌هایی که فقط از اکسل آمده‌اند و فایل خام ندارند — قبل از
    # آینه‌کردن سبدها، تا اگر روزی سبدی هم از این مسیر آمد جا نماند.
    h = ensure_market_extra(con, log)
    i = ensure_industry_bundle(con, log)
    # بعد از اینها می‌آید، نه قبلشان: اول سری‌های سبد کامل شوند، بعد به
    # جدول صنایع آینه شوند — وگرنه روزهای تازهٔ همین اجرا جا می‌ماندند.
    j = ensure_basket_industries(con, log)
    # و عکسش، برای روزهایی که فقط از صفحهٔ سوابق صنایع آمده‌اند. بعد از j
    # می‌آید؛ هر دو فقط جای خالی را پر می‌کنند، پس به هم نمی‌خورند.
    k = ensure_basket_from_industries(con, log)
    # آخر از همه: تصحیح علامتِ ورود پول. بعد از e و g می‌آید تا اگر همین
    # اجرا آن روزها را تازه وارد کرده باشد، تصحیح رویشان بنشیند.
    m = ensure_flow_sign_fix(con, log)
    n = ensure_industry_flow_sign(con, log)
    o = ensure_rfr(con, log)
    return a or b or c or d or e or f or g or h or i or j or k or m or n or o
