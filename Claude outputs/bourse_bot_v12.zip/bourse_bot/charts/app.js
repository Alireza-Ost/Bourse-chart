/* ------------------------------------------------------------------ *
 *  نمای بازار سرمایه — نمودار خطی با جابه‌جایی و بزرگ‌نمایی
 *  محور افقی بر مبنای «روز معاملاتی» است نه روز تقویمی، پس تعطیلی بازار
 *  فاصلهٔ جعلی نمی‌سازد؛ روزهای شکاف با خط‌چین کم‌رنگ علامت می‌خورند.
 * ------------------------------------------------------------------ */
const SERIES = [
  {k:"index_total",  n:"شاخص کل",              u:"واحد",          ma:[50,200], dec:0},
  {k:"index_ew",     n:"شاخص هم‌وزن",           u:"واحد",          ma:[50,200], dec:0},
  {k:"value_retail", n:"ارزش معاملات خرد",      u:"میلیارد تومان", ma:[7,21],   dec:0},
  {k:"flow_retail",  n:"ورود پول حقیقی",        u:"میلیارد تومان", ma:[7,21],   dec:0, signed:true},
  {k:"mv",           n:"ارزش کل بازار",         u:"همت",           ma:[50,200], dec:0},
  {k:"mv_tse",       n:"ارزش بورس",             u:"همت",           ma:[50,200], dec:0, hide:true},
  {k:"mv_ifb",       n:"ارزش فرابورس",          u:"همت",           ma:[50,200], dec:0, hide:true},
  {k:"mv_usd",       n:"ارزش دلاری بازار",      u:"میلیارد دلار",  ma:[50,200], dec:1},
  {k:"gold18",       n:"طلای ۱۸ عیار",          u:"تومان بر گرم",  ma:[50,200], dec:0},
  {k:"mv_gold",      n:"ارزش بازار به طلا",     u:"تن طلا",        ma:[50,200], dec:0},
  {k:"pe",           n:"P/E کل بازار",          u:"",              ma:[50,200], dec:2, hide:true},
  {k:"m2",           n:"نقدینگی M2",            u:"همت",           ma:[50,200], dec:0},
  {k:"ratio",        n:"ارزش بازار به نقدینگی", u:"نسبت",          ma:[50,200], dec:3, hide:true},
];

/* هر «نما» یک چیدمان آماده است: سری اصلی، میانگین‌ها، و پنل پایین. */
const VIEWS = [
  {id:"explore", tab:"نمای کلی", free:true, panel:"volume"},
  {id:"ratio",   tab:"نسبت نقدینگی", key:"ratio", ema:[28,110], panel:"none",
   title:"نسبت ارزش بازار به نقدینگی",
   note:"ارزش بازار ÷ نقدینگی M2"},
  {id:"value",   tab:"ارزش معاملات", key:"value_retail", ema:[7,28], panel:"flow",
   title:"ارزش معاملات خرد",
   note:"پنل پایین: خالص ورود پول حقیقی هر روز"},
  {id:"mv",      tab:"ارزش بازار", key:"mv", lines:["mv_tse","mv_ifb","mv"],
   panel:"none", title:"ارزش بازار", note:"همت"},
  {id:"gold",    tab:"بازار به طلا", key:"mv_gold", ema:[28,110], panel:"none",
   title:"ارزش بازار بر حسب طلا",
   note:"ارزش کل بازار ÷ قیمت یک گرم طلای ۱۸ عیار — بر حسب تن"},
  {id:"sheet",   tab:"جدول", sheet:true, title:"جدول داده‌ها"},
];

const RANGES = [
  {n:"۱م", d:22}, {n:"۳م", d:65}, {n:"۶م", d:130},
  {n:"۱س", d:250}, {n:"۳س", d:750}, {n:"همه", d:0},
];
const N = DATA.d.length;

const state = {
  view:"explore",
  key:"index_total",
  compare:[],           // کلیدهای سری در حالت مقایسه
  showMA:false,
  cmpMode:false,
  i0:Math.max(0,N-250), i1:N-1,
  hover:-1,
};

/* ---------- ابزارها ---------- */
const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const fa  = k => SERIES.find(s=>s.k===k);
const view = () => VIEWS.find(v=>v.id===state.view);
const jDate = j => `${j.slice(0,4)}/${j.slice(4,6)}/${j.slice(6)}`;
const PD = "۰۱۲۳۴۵۶۷۸۹";
const pnum = s => String(s).replace(/[0-9]/g, d=>PD[+d]);
const fmt = (v,dec) => v==null ? "—"
  : v.toLocaleString("en-US",{minimumFractionDigits:dec??0,maximumFractionDigits:dec??0});
function nice(v,dec){
  if(v==null) return "—";
  if(v===0) v=0;                       // ‎-0 در JS وجود دارد و روی محور بد می‌نشیند
  if(v<0) return "\u200E\u2212"+nice(-v,dec);   // علامت منفی همیشه سمت چپِ عدد
  if(dec!=null) return fmt(v,dec);
  const a=Math.abs(v);
  if(a>=1000) return fmt(v,0);
  if(a>=10) return fmt(v,1);
  return fmt(v,2);
}
/* عدد سری جاری با تعداد رقم اعشار خودش */
const niceK = (v,k) => nice(v, fa(k)?.dec);

/* فاصلهٔ تقویمی بین دو روز معاملاتی، برای علامت‌زدن تعطیلی */
function gapDays(i){
  if(i<=0) return 0;
  const p=String(DATA.t[i-1]), c=String(DATA.t[i]);
  const dp=new Date(+p.slice(0,4),+p.slice(4,6)-1,+p.slice(6));
  const dc=new Date(+c.slice(0,4),+c.slice(4,6)-1,+c.slice(6));
  return Math.round((dc-dp)/864e5);
}
/* میانگین متحرک ساده */
function movingAvg(arr,win){
  const out=new Array(arr.length).fill(null);
  let sum=0, cnt=0; const q=[];
  for(let i=0;i<arr.length;i++){
    const v=arr[i];
    q.push(v); if(v!=null){sum+=v;cnt++;}
    if(q.length>win){const o=q.shift(); if(o!=null){sum-=o;cnt--;}}
    if(q.length===win && cnt>=Math.ceil(win*0.6)) out[i]=sum/cnt;
  }
  return out;
}
/* میانگین متحرک نمایی — روزهای بی‌داده رد می‌شوند، نه اینکه صفر حساب شوند.
   تا وقتی span مشاهدهٔ واقعی جمع نشده چیزی بیرون نمی‌دهد (دورهٔ گرم‌شدن). */
function ema(arr,span){
  const out=new Array(arr.length).fill(null);
  const k=2/(span+1);
  let prev=null, seen=0;
  for(let i=0;i<arr.length;i++){
    const v=arr[i];
    if(v==null) continue;
    prev = prev==null ? v : v*k + prev*(1-k);
    seen++;
    if(seen>=span) out[i]=prev;
  }
  return out;
}
/* آخرین روزی که این سری داده دارد */
function lastValid(k){
  const a=DATA[k]; if(!a) return N-1;
  for(let i=N-1;i>=0;i--) if(a[i]!=null) return i;
  return N-1;
}

/* ---------- بوم ---------- */
const stage=document.getElementById("stage"), cv=document.getElementById("cv");
const ctx=cv.getContext("2d"), tip=document.getElementById("tip");
let W=0,H=0,DPR=1;
const PAD={t:14,r:62,b:26,l:12};
/* پهنای ستون برچسب‌های محور عمودی. قیمت طلا هشت‌رقمی است و در ۶۲ پیکسل جا
   نمی‌شود؛ پس بعد از اندازه‌گیریِ پهن‌ترین برچسب، یک بار دوباره چیده می‌شود. */
let GUTTER = 62;
let relaying = false;
function pad(){ return {...PAD, r: Math.max(W<560?52:62, GUTTER)}; }
const PANEL_H=0.22;             // سهم پنل پایین از ارتفاع

function resize(){
  const r=stage.getBoundingClientRect();
  DPR=Math.min(window.devicePixelRatio||1,2);
  W=Math.max(1,r.width); H=Math.max(1,r.height);
  cv.width=Math.round(W*DPR); cv.height=Math.round(H*DPR);
  ctx.setTransform(DPR,0,0,DPR,0,0);
  draw();
}

/* ---------- چیدمان ---------- */
function layout(){
  const P=pad();
  const hasPanel = !view().sheet && view().panel!=="none";
  if(!hasPanel){
    return {x0:P.l, x1:W-P.r, mainTop:P.t, mainBot:H-P.b, panelTop:null, panelBot:H-P.b, hasPanel:false};
  }
  const panelTop = H-P.b-Math.round((H-P.t-P.b)*PANEL_H);
  return {
    x0:P.l, x1:W-P.r,
    mainTop:P.t, mainBot:panelTop-14,
    panelTop, panelBot:H-P.b, hasPanel:true,
  };
}
const xAt = (i,L) => L.x0 + (i-state.i0)/Math.max(1,(state.i1-state.i0)) * (L.x1-L.x0);
const iAt = (px,L) => state.i0 + (px-L.x0)/(L.x1-L.x0) * (state.i1-state.i0);

function ticks(lo,hi,n){
  const raw=(hi-lo)/n, mag=Math.pow(10,Math.floor(Math.log10(raw)));
  const step=[1,2,2.5,5,10].map(m=>m*mag).find(s=>s>=raw)||10*mag;
  const out=[]; for(let v=Math.ceil(lo/step)*step; v<=hi; v+=step) out.push(v);
  return out;
}
function roundRectPath(x,y,w,h,r){
  r=Math.min(r,Math.abs(w)/2,Math.abs(h)/2);
  ctx.beginPath();
  if(ctx.roundRect) ctx.roundRect(x,y,w,h,r);
  else ctx.rect(x,y,w,h);
}

/* چه چیزی در این نما رسم می‌شود */
function plan(){
  const V=view();
  if(V.sheet) return {keys:[state.key], indexed:false, ma:null, panel:"none"};
  if(V.lines) return {keys:V.lines, indexed:false, ma:null, panel:V.panel};
  if(!V.free) return {keys:[V.key], indexed:false, ma:V.ema, maKind:"ema", panel:V.panel};
  const keys = state.cmpMode && state.compare.length ? state.compare : [state.key];
  return {keys, indexed:keys.length>1,
          ma: state.showMA ? fa(state.key).ma : null, maKind:"sma", panel:"volume"};
}

/* سری‌ها هم‌طول نیستند: ارزش بازار روزهایی داده دارد که شاخص ندارد و برعکس.
   اگر برای هر نقطهٔ خالی قلم را برداریم، خط خط‌چین‌خط‌چین می‌شود. پس حفره‌های
   کوتاه (چند ردیف) وصل می‌شوند و فقط حفره‌های واقعی — مثل نبودِ سه‌سالهٔ داده —
   خط را می‌شکنند. */
const MAX_HOLE = 6;
function strokeSeries(a, L, yAt){
  ctx.beginPath();
  let prev = -1;
  for(let i=state.i0;i<=state.i1;i++){
    const v=a[i]; if(v==null) continue;
    const x=xAt(i,L), y=yAt(v);
    if(prev<0 || i-prev>MAX_HOLE) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    prev=i;
  }
  ctx.stroke();
}

/* ---------- ترسیم ---------- */
function draw(){
  if(view().sheet) return;
  const L=layout(), V=view(), PL=plan();
  const muted=css("--muted"), line=css("--line"), soft=css("--line-soft"), surf=css("--surface");
  const S=[css("--s1"),css("--s2"),css("--s3")];
  const up=css("--up"), down=css("--down");

  ctx.clearRect(0,0,W,H);
  ctx.textBaseline="middle";
  ctx.font='11px Vazirmatn,system-ui,sans-serif';

  const {keys, indexed}=PL;

  /* سری‌های آمادهٔ رسم */
  const plot = keys.map((k,idx)=>{
    let a=DATA[k];
    if(indexed){
      let base=null;
      for(let i=state.i0;i<=state.i1;i++){ if(a[i]!=null){base=a[i];break;} }
      a = base ? a.map(v=>v==null?null:v/base*100) : a;
    }
    return {k, a, color:S[idx%3], meta:fa(k)};
  });

  /* میانگین‌ها — قبل از محاسبهٔ بازهٔ عمودی، تا از کادر بیرون نزنند */
  const mas = (!indexed && PL.ma)
    ? PL.ma.map((p,j)=>({p, a:(PL.maKind==="ema"?ema:movingAvg)(plot[0].a,p), color:S[(j+1)%3]}))
    : [];

  /* بازهٔ عمودی پنل اصلی */
  const [lo,hi]=(()=>{
    let l=Infinity,h=-Infinity;
    const series=[...plot.map(p=>p.a), ...mas.map(m=>m.a)];
    for(const a of series) for(let i=state.i0;i<=state.i1;i++){
      const v=a[i]; if(v==null)continue; if(v<l)l=v; if(v>h)h=v;
    }
    if(!isFinite(l)) return [0,1];
    if(l===h){l-=1;h+=1;}
    const pd=(h-l)*0.08; return [l-pd,h+pd];
  })();
  const yAt = v => L.mainBot - (v-lo)/(hi-lo)*(L.mainBot-L.mainTop);

  /* شبکه + برچسب محور عمودی */
  ctx.strokeStyle=soft; ctx.lineWidth=1;
  ctx.fillStyle=muted; ctx.textAlign="left";
  const dec = indexed ? 0 : plot[0].meta.dec;
  let widest=0;
  for(const t of ticks(lo,hi,5)){
    const y=Math.round(yAt(t))+.5;
    if(y<L.mainTop||y>L.mainBot) continue;
    const lab = indexed ? t.toFixed(0) : nice(t,dec);
    widest = Math.max(widest, ctx.measureText(lab).width);
    ctx.beginPath(); ctx.moveTo(L.x0,y); ctx.lineTo(L.x1,y); ctx.stroke();
    ctx.fillText(lab, L.x1+7, y);
  }
  /* اگر برچسب‌ها در ستون فعلی جا نمی‌شوند، ستون را پهن کن و یک بار دوباره بکش */
  const want = Math.max(W<560?52:62, Math.ceil(widest)+12);
  if(!relaying && Math.abs(want-GUTTER)>1){
    GUTTER = want; relaying = true;
    try { draw(); } finally { relaying = false; }
    return;
  }

  /* خط صفر برای سری‌های دوعلامته */
  if(!indexed && plot[0].meta.signed && lo<0 && hi>0){
    const y=Math.round(yAt(0))+.5;
    ctx.strokeStyle=css("--edge"); ctx.beginPath();
    ctx.moveTo(L.x0,y); ctx.lineTo(L.x1,y); ctx.stroke();
  }

  /* علامت تعطیلی بازار */
  ctx.save(); ctx.setLineDash([2,4]); ctx.strokeStyle=line;
  for(let i=Math.max(1,state.i0);i<=state.i1;i++){
    if(gapDays(i)>10){
      const x=Math.round(xAt(i-0.5,L))+.5;
      ctx.beginPath(); ctx.moveTo(x,L.mainTop); ctx.lineTo(x,L.panelBot); ctx.stroke();
    }
  }
  ctx.restore();

  /* ---- پنل پایین ---- */
  const slot=(L.x1-L.x0)/Math.max(1,(state.i1-state.i0+1));
  const bw=Math.max(1, slot-2);            // ۲ پیکسل فاصلهٔ سطح بین میله‌ها
  const rad=bw>=6?3:0;

  if(PL.panel==="volume" && L.hasPanel){
    /* ارزش معاملات، رنگ بر اساس جهت جریان پول */
    const vol=DATA.value_retail, flow=DATA.flow_retail;
    let vmax=0; for(let i=state.i0;i<=state.i1;i++) if(vol[i]!=null&&vol[i]>vmax) vmax=vol[i];
    if(vmax>0){
      for(let i=state.i0;i<=state.i1;i++){
        const v=vol[i]; if(v==null) continue;
        const h=(v/vmax)*(L.panelBot-L.panelTop);
        const f=flow[i];
        ctx.fillStyle = f==null ? css("--edge") : (f>=0?up:down);
        ctx.globalAlpha=.4;
        ctx.fillRect(xAt(i,L)-bw/2, L.panelBot-h, bw, h);
      }
      ctx.globalAlpha=1;
      ctx.fillStyle=muted; ctx.textAlign="right";
      ctx.font='10px Vazirmatn,system-ui,sans-serif';
      if(W>=560) ctx.fillText("ارزش معاملات خرد", L.x1-6, L.panelTop+7);
      ctx.font='11px Vazirmatn,system-ui,sans-serif';
    }
  }

  if(PL.panel==="flow" && L.hasPanel){
    /* خالص ورود پول حقیقی — میلهٔ دوسویه حول خط صفر */
    const flow=DATA.flow_retail;
    let flo=0, fhi=0;
    for(let i=state.i0;i<=state.i1;i++){
      const v=flow[i]; if(v==null) continue;
      if(v<flo)flo=v; if(v>fhi)fhi=v;
    }
    if(flo===0&&fhi===0){flo=-1;fhi=1;}
    const padf=(fhi-flo)*0.06; flo-=padf; fhi+=padf;
    const fy = v => L.panelBot - (v-flo)/(fhi-flo)*(L.panelBot-L.panelTop);
    const zy = fy(0);

    for(let i=state.i0;i<=state.i1;i++){
      const v=flow[i]; if(v==null) continue;
      const y=fy(v), top=Math.min(y,zy), h=Math.max(1,Math.abs(y-zy));
      ctx.fillStyle = v>=0?up:down;
      ctx.globalAlpha=.9;
      if(rad){ roundRectPath(xAt(i,L)-bw/2, top, bw, h, rad); ctx.fill(); }
      else ctx.fillRect(xAt(i,L)-bw/2, top, bw, h);
    }
    ctx.globalAlpha=1;
    /* خط صفر */
    ctx.strokeStyle=css("--edge"); ctx.lineWidth=1;
    ctx.beginPath(); ctx.moveTo(L.x0,Math.round(zy)+.5); ctx.lineTo(L.x1,Math.round(zy)+.5); ctx.stroke();
    /* بیشینه و کمینهٔ پنل روی محور راست */
    ctx.fillStyle=muted; ctx.textAlign="left"; ctx.font='10px Vazirmatn,system-ui,sans-serif';
    const ftop=fhi-padf, fbot=flo+padf;
    const yTop=Math.max(L.panelTop+6, fy(ftop)), yBot=Math.min(L.panelBot-6, fy(fbot));
    ctx.fillText(nice(ftop,0), L.x1+7, yTop);
    ctx.fillText(nice(fbot,0), L.x1+7, yBot);
    if(Math.abs(zy-yTop)>11 && Math.abs(zy-yBot)>11) ctx.fillText("0", L.x1+7, zy);
    ctx.textAlign="right";
    if(W>=560) ctx.fillText("خالص ورود پول حقیقی", L.x1-6, L.panelTop+7);
    ctx.font='11px Vazirmatn,system-ui,sans-serif';
  }

  /* ---- میانگین‌های متحرک ---- */
  for(const m of mas){
    ctx.strokeStyle=m.color; ctx.lineWidth=1.5;
    ctx.lineJoin="round"; ctx.lineCap="round";
    strokeSeries(m.a, L, yAt);
  }

  /* ---- خطوط اصلی ---- */
  for(const p of plot){
    ctx.strokeStyle=p.color; ctx.lineWidth=2;
    ctx.lineJoin="round"; ctx.lineCap="round";
    strokeSeries(p.a, L, yAt);

    let last=null; for(let i=state.i1;i>=state.i0;i--){ if(p.a[i]!=null){last=i;break;} }
    if(last!=null){
      const x=xAt(last,L), y=yAt(p.a[last]);
      ctx.fillStyle=p.color; ctx.beginPath(); ctx.arc(x,y,3,0,7); ctx.fill();
      /* برچسب انتهای خط فقط وقتی جا دارد؛ وگرنه راهنمای بالای نمودار کافی است */
      if(indexed || plot.length>1){
        ctx.textAlign="right";
        const w=ctx.measureText(p.meta.n).width;
        if(x-10-w > L.x0+4) ctx.fillText(p.meta.n, x-10, y);
      }
    }
  }

  /* برچسب محور افقی */
  ctx.fillStyle=muted; ctx.textAlign="center";
  const nLab=W<560?3:(W<820?4:6);
  const span=state.i1-state.i0, step=Math.max(1,Math.round(span/nLab));
  let prev="";
  for(let i=state.i0;i<=state.i1;i+=step){
    const d=DATA.d[i], lab=`${d.slice(0,4)}/${d.slice(4,6)}`;
    if(lab===prev) continue; prev=lab;
    const x=xAt(i,L);
    if(x>L.x0+18 && x<L.x1-18) ctx.fillText(lab, x, L.panelBot+13);
  }

  /* نشانگر متقاطع */
  if(state.hover>=state.i0 && state.hover<=state.i1){
    const x=Math.round(xAt(state.hover,L))+.5;
    ctx.save(); ctx.setLineDash([3,3]); ctx.strokeStyle=css("--edge");
    ctx.beginPath(); ctx.moveTo(x,L.mainTop); ctx.lineTo(x,L.panelBot); ctx.stroke();
    ctx.restore();
    for(const p of plot){
      const v=p.a[state.hover]; if(v==null) continue;
      const y=yAt(v);
      ctx.fillStyle=surf; ctx.strokeStyle=p.color; ctx.lineWidth=2;
      ctx.beginPath(); ctx.arc(x,y,4,0,7); ctx.fill(); ctx.stroke();
    }
  }

  /* خط جداکنندهٔ پنل‌ها */
  if(L.hasPanel){
    ctx.strokeStyle=line; ctx.lineWidth=1;
    ctx.beginPath();
    ctx.moveTo(L.x0,Math.round(L.panelTop-7)+.5); ctx.lineTo(L.x1,Math.round(L.panelTop-7)+.5);
    ctx.stroke();
  }

  window.__mas = mas;      // برای راهنمای شناور
  updateQuote(indexed);
}

/* ---------- سربرگ عددی ---------- */
function updateQuote(indexed){
  const V=view(), k=state.key, a=DATA[k], m=fa(k);
  let last=null; for(let i=N-1;i>=0;i--){ if(a[i]!=null){last=i;break;} }
  document.getElementById("title").textContent =
    (V.free && state.cmpMode && state.compare.length>1) ? "مقایسه سری‌ها (پایه ۱۰۰)"
    : (V.title || m.n);
  if(last==null) return;
  let prev=null; for(let i=last-1;i>=0;i--){ if(a[i]!=null){prev=i;break;} }
  const v=a[last], p=prev!=null?a[prev]:null;
  document.getElementById("qval").textContent=niceK(v,k);
  const chg=document.getElementById("qchg");
  if(p!=null && p!==0){
    const d=v-p, pc=d/Math.abs(p)*100;
    chg.textContent=`${d>=0?"+":"−"}${niceK(Math.abs(d),k)} (${d>=0?"+":"−"}${Math.abs(pc).toFixed(2)}٪)`;
    chg.className="chg "+(d>=0?"up":"down");
  } else { chg.textContent=""; chg.className="chg"; }
  document.getElementById("qasof").textContent=`${jDate(DATA.d[last])} · ${m.u}`;
  document.getElementById("count").textContent=
    `${state.i1-state.i0+1} روز معاملاتی از ${N} · ${jDate(DATA.d[state.i0])} تا ${jDate(DATA.d[state.i1])}`;
}

/* ---------- راهنمای شناور ---------- */
function showTip(px,py){
  const i=state.hover;
  if(i<0){ tip.style.opacity=0; return; }
  const PL=plan(), S=[css("--s1"),css("--s2"),css("--s3")];
  let html=`<div class="d">${jDate(DATA.d[i])}</div>`;

  if(view().lines){
    const t=DATA.mv_tse[i], f=DATA.mv_ifb[i];
    const row=(c,n,v)=>`<div class="r"><span class="dot" style="background:${c}"></span>`+
                       `<span class="n">${n}</span><span class="v">${nice(v,0)}</span></div>`;
    html+=row(S[0],"ارزش بورس",t)+row(S[1],"ارزش فرابورس",f);
    if(t!=null && f!=null){
      html+=row(S[2],"ارزش کل بازار",t+f);
      html+=`<div class="r"><span class="dot" style="background:transparent"></span>`+
            `<span class="n">سهم فرابورس</span>`+
            `<span class="v">${(f/(t+f)*100).toFixed(1)}٪</span></div>`;
    }
    tip.innerHTML=html;
    tip.style.opacity=1;
    const r0=tip.getBoundingClientRect();
    let x0=px+14; if(x0+r0.width>W-6) x0=px-r0.width-14;
    let y0=py-r0.height/2; y0=Math.max(4,Math.min(H-r0.height-4,y0));
    tip.style.left=x0+"px"; tip.style.top=y0+"px";
    return;
  }

  PL.keys.forEach((k,idx)=>{
    const m=fa(k), v=DATA[k][i];
    html+=`<div class="r"><span class="dot" style="background:${S[idx%3]}"></span>`+
          `<span class="n">${m.n}</span><span class="v">${niceK(v,k)}</span></div>`;
  });
  for(const m of (window.__mas||[])){
    if(m.a[i]==null) continue;
    html+=`<div class="r"><span class="dot" style="background:${m.color}"></span>`+
          `<span class="n">${(PL.maKind==="ema"?"EMA ":"MA ")+pnum(m.p)}</span>`+
          `<span class="v">${niceK(m.a[i],PL.keys[0])}</span></div>`;
  }
  if(PL.panel==="flow" && !PL.keys.includes("flow_retail") && DATA.flow_retail[i]!=null){
    const f=DATA.flow_retail[i];
    html+=`<div class="r"><span class="dot" style="background:${f>=0?css("--up"):css("--down")}"></span>`+
          `<span class="n">ورود پول حقیقی</span><span class="v">${nice(f,0)}</span></div>`;
  }
  if(PL.panel==="volume" && !PL.keys.includes("value_retail") && DATA.value_retail[i]!=null)
    html+=`<div class="r"><span class="dot" style="background:${css("--edge")}"></span>`+
          `<span class="n">ارزش معاملات</span><span class="v">${nice(DATA.value_retail[i],0)}</span></div>`;
  tip.innerHTML=html;
  tip.style.opacity=1;
  const r=tip.getBoundingClientRect();
  let x=px+14; if(x+r.width>W-6) x=px-r.width-14;
  let y=py-r.height/2; y=Math.max(4,Math.min(H-r.height-4,y));
  tip.style.left=x+"px"; tip.style.top=y+"px";
}

/* ---------- تعامل ---------- */
function clampView(){
  const minSpan=12;
  if(state.i1-state.i0<minSpan){
    const c=(state.i0+state.i1)/2;
    state.i0=Math.round(c-minSpan/2); state.i1=state.i0+minSpan;
  }
  if(state.i0<0){ state.i1-=state.i0; state.i0=0; }
  if(state.i1>N-1){ state.i0-=(state.i1-(N-1)); state.i1=N-1; }
  state.i0=Math.max(0,Math.round(state.i0)); state.i1=Math.min(N-1,Math.round(state.i1));
}
let drag=null;
stage.addEventListener("pointerdown",e=>{
  stage.setPointerCapture(e.pointerId);
  drag={x:e.offsetX, i0:state.i0, i1:state.i1};
});
stage.addEventListener("pointermove",e=>{
  const L=layout();
  if(drag){
    const bars=(e.offsetX-drag.x)/(L.x1-L.x0)*(drag.i1-drag.i0);
    state.i0=drag.i0+bars; state.i1=drag.i1+bars;
    clampView(); draw(); return;
  }
  const i=Math.round(iAt(e.offsetX,L));
  state.hover=(i>=state.i0&&i<=state.i1)?i:-1;
  draw(); showTip(e.offsetX,e.offsetY);
});
const endDrag=()=>{ drag=null; };
stage.addEventListener("pointerup",endDrag);
stage.addEventListener("pointercancel",endDrag);
stage.addEventListener("pointerleave",()=>{ drag=null; state.hover=-1; tip.style.opacity=0; draw(); });
stage.addEventListener("wheel",e=>{
  e.preventDefault();
  const L=layout(), anchor=iAt(e.offsetX,L);
  const f=e.deltaY>0?1.12:1/1.12;
  state.i0=anchor-(anchor-state.i0)*f;
  state.i1=anchor+(state.i1-anchor)*f;
  clampView(); draw();
},{passive:false});
stage.addEventListener("dblclick",()=>{ state.i0=0; state.i1=N-1; draw(); });

/* ---------- کنترل‌ها ---------- */
const viewsRow=document.getElementById("views");
VIEWS.forEach(v=>{
  const b=document.createElement("button");
  b.type="button"; b.textContent=v.tab; b.dataset.v=v.id;
  b.setAttribute("aria-pressed", v.id===state.view?"true":"false");
  b.addEventListener("click",()=>setView(v.id));
  viewsRow.appendChild(b);
});

const seriesRow=document.getElementById("series");
/* سری‌هایی با hide:true چیپ نمی‌گیرند — اجزای ارزش بازار و نسبت نقدینگی
   تب اختصاصی خودشان را دارند و اینجا فقط شلوغی می‌سازند. */
SERIES.filter(s=>!s.hide).forEach(s=>{
  const b=document.createElement("button");
  b.className="chip"; b.type="button"; b.dataset.k=s.k;
  b.innerHTML=`<span class="dot" style="background:var(--s1)"></span>${s.n}`;
  b.setAttribute("aria-pressed", s.k===state.key ? "true":"false");
  b.addEventListener("click",()=>{
    if(state.cmpMode){
      const i=state.compare.indexOf(s.k);
      if(i>=0) state.compare.splice(i,1);
      else if(state.compare.length<3) state.compare.push(s.k);
      if(state.compare.length) state.key=state.compare[0];
    } else {
      state.key=s.k; state.compare=[s.k];
    }
    syncChips(); draw();
  });
  seriesRow.appendChild(b);
});

const rangeRow=document.getElementById("ranges");
RANGES.forEach((r,idx)=>{
  const b=document.createElement("button");
  b.type="button"; b.textContent=r.n; b.dataset.d=r.d;
  b.setAttribute("aria-pressed", r.d===250 ? "true":"false");
  b.addEventListener("click",()=>{ applyRange(r.d); markRange(idx); draw(); });
  rangeRow.appendChild(b);
});
function markRange(idx){
  rangeRow.querySelectorAll("button").forEach((x,j)=>x.setAttribute("aria-pressed", j===idx?"true":"false"));
}
/* بازه به آخرین روزی ختم می‌شود که سری جاری داده دارد، نه آخرین روز جدول.
   سری‌ها هم‌طول نیستند — ارزش بازار تا امروز می‌آید، شاخص‌ها چند روز عقب‌ترند —
   و بدون این، سمت راست نمودار خالی می‌ماند. */
function applyRange(d){
  const keys = (state.cmpMode && state.compare.length) ? state.compare : [state.key];
  const end = Math.max(...keys.map(lastValid));
  state.i1=end;
  state.i0 = d ? Math.max(0,end-d+1) : 0;
  clampView();
}

function setView(id){
  state.view=id;
  const V=view();
  const isSheet = !!V.sheet;
  stage.hidden = isSheet;
  sheetEl.hidden = !isSheet;
  document.getElementById("rangeRow").hidden = isSheet;
  document.querySelector(".foot").hidden = isSheet;
  document.getElementById("title").textContent = V.title || "";
  if(isSheet){
    viewsRow.querySelectorAll("button").forEach(b=>
      b.setAttribute("aria-pressed", b.dataset.v===id?"true":"false"));
    syncChips();
    renderSheet();
    return;
  }
  if(!V.free){ state.key=V.key; state.compare=[V.key]; state.cmpMode=false; }
  viewsRow.querySelectorAll("button").forEach(b=>
    b.setAttribute("aria-pressed", b.dataset.v===id?"true":"false"));
  applyRange(V.free?0:250);
  markRange(V.free?5:3);
  syncChips(); draw();
}

document.getElementById("ma").addEventListener("click",e=>{
  state.showMA=!state.showMA;
  e.currentTarget.setAttribute("aria-pressed", state.showMA?"true":"false");
  draw();
});
document.getElementById("cmp").addEventListener("click",e=>{
  state.cmpMode=!state.cmpMode;
  if(state.cmpMode && state.compare.length<2){
    state.compare=[state.key, state.key==="index_total"?"index_ew":"index_total"];
  }
  e.currentTarget.setAttribute("aria-pressed", state.cmpMode?"true":"false");
  syncChips(); draw();
});

const legendRow=document.getElementById("legend");
function syncChips(){
  const V=view(), S=[css("--s1"),css("--s2"),css("--s3")];
  if(V.sheet){
    seriesRow.hidden = legendRow.hidden = true;
    document.getElementById("cmp").hidden = document.getElementById("ma").hidden = true;
    document.querySelector(".quote").hidden = true;
    return;
  }
  document.querySelector(".quote").hidden = false;
  const free=!!V.free;

  seriesRow.hidden = !free;
  document.getElementById("cmp").hidden = !free;
  document.getElementById("ma").hidden = !free || (state.cmpMode && state.compare.length>1);

  seriesRow.querySelectorAll(".chip").forEach(b=>{
    const k=b.dataset.k;
    const on = state.cmpMode ? state.compare.includes(k) : k===state.key;
    b.setAttribute("aria-pressed", on?"true":"false");
    const idx = state.cmpMode ? state.compare.indexOf(k) : 0;
    b.querySelector(".dot").style.background = on ? S[Math.max(0,idx)%3] : "var(--edge)";
  });

  legendRow.hidden = free;
  if(free) return;
  const items=[]; const note=V.note;
  if(V.lines){
    V.lines.forEach((k,j)=>items.push([S[j%3], fa(k).n, "line"]));
  } else {
    items.push([S[0],fa(V.key).n,"line"]);
    (V.ema||[]).forEach((p,j)=>items.push([S[(j+1)%3],"EMA "+pnum(p),"line"]));
  }
  if(V.panel==="flow"){
    items.push([css("--up"),"ورود پول (مثبت)","box"]);
    items.push([css("--down"),"خروج پول (منفی)","box"]);
  }
  legendRow.innerHTML = items.map(([c,n,kind])=>
    `<span class="it"><span class="sw${kind==="box"?" box":""}" style="background:${c}"></span>${n}</span>`
  ).join("") + (note?`<span class="note">${note}</span>`:"");


}



/* ================= جدول داده‌ها =================
   ۷٬۷۲۱ ردیف در DOM مرورگر را می‌خواباند، پس فقط ردیف‌های داخل دید ساخته
   می‌شوند و بقیه با یک فاصله‌گذارِ ارتفاع‌دار شبیه‌سازی می‌شوند. */
const SHEET_COLS = SERIES.filter(s => DATA[s.k]);
const ROW_H = 27;
const sheetEl = document.getElementById("sheet");
const scrollEl = document.getElementById("sheetScroll");
const bodyEl = document.getElementById("sheetBody");
const headEl = document.getElementById("sheetHead");

/* جدیدترین روز بالا — چیزی که معمولاً دنبالش هستید */
const SHEET_ROWS = Array.from({length:N}, (_,i)=>N-1-i);

headEl.innerHTML = "<tr><th>تاریخ</th>" + SHEET_COLS.map(c =>
  `<th>${c.n}<span class="unit">${c.u||"—"}</span></th>`).join("") + "</tr>";
document.getElementById("sheetCount").textContent =
  `${N.toLocaleString("en-US")} روز · ${jDate(DATA.d[0])} تا ${jDate(DATA.d[N-1])}`;

function renderSheet(){
  const top = scrollEl.scrollTop, h = scrollEl.clientHeight;
  const first = Math.max(0, Math.floor(top/ROW_H) - 8);
  const last  = Math.min(SHEET_ROWS.length, Math.ceil((top+h)/ROW_H) + 8);
  const pad = i => `<tr style="height:${i*ROW_H}px"><td colspan="${SHEET_COLS.length+1}"></td></tr>`;
  let html = first ? pad(first) : "";
  for(let r=first;r<last;r++){
    const i = SHEET_ROWS[r];
    html += `<tr><td>${jDate(DATA.d[i])}</td>` + SHEET_COLS.map(c=>{
      const v = DATA[c.k][i];
      return v==null ? '<td class="none">—</td>' : `<td>${nice(v, c.dec)}</td>`;
    }).join("") + "</tr>";
  }
  const restRows = SHEET_ROWS.length - last;
  if(restRows>0) html += pad(restRows);
  bodyEl.innerHTML = html;
}
scrollEl.addEventListener("scroll", ()=>{ if(view().sheet) renderSheet(); });

/* پریدن به یک تاریخ */
document.getElementById("jump").addEventListener("input", e=>{
  const q = e.target.value.replace(/[^0-9]/g,"");
  if(q.length<4) return;
  /* تاریخ تایپ‌شده ممکن است اصلاً روز معاملاتی نباشد؛ پس نزدیک‌ترین روزِ
     همان تاریخ یا قبل از آن پیدا می‌شود. ردیف‌ها نزولی‌اند، پس اولین
     تاریخی که کوچک‌تر یا مساوی باشد همان است. */
  const key = (q + "00000000").slice(0,8);
  let hit = SHEET_ROWS.findIndex(i => DATA.d[i] <= (q.length>=8 ? q : key.slice(0,q.length)+"99999999".slice(q.length)));
  if(hit<0) hit = SHEET_ROWS.length-1;
  scrollEl.scrollTop = hit*ROW_H;
  renderSheet();
});

/* خروجی CSV — با BOM تا اکسل فارسی را درست بخواند */
document.getElementById("csv").addEventListener("click", ()=>{
  const head = ["تاریخ", ...SHEET_COLS.map(c=>`${c.n} (${c.u||"-"})`)].join(",");
  const lines = [head];
  for(let i=0;i<N;i++){
    lines.push([DATA.d[i], ...SHEET_COLS.map(c=>{
      const v=DATA[c.k][i]; return v==null ? "" : v;
    })].join(","));
  }
  const blob = new Blob(["\uFEFF"+lines.join("\n")], {type:"text/csv;charset=utf-8"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `bourse_${DATA.d[N-1]}.csv`;
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href), 1000);
});

/* ---------- راه‌اندازی ---------- */
new ResizeObserver(resize).observe(stage);
matchMedia("(prefers-color-scheme:dark)").addEventListener("change",()=>{syncChips();draw();});
new MutationObserver(()=>{syncChips();draw();}).observe(
  document.documentElement,{attributes:true,attributeFilter:["data-theme"]});
document.fonts?.ready?.then(draw);
state.compare=[state.key];
syncChips();
resize();
