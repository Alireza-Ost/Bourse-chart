@echo off
REM ===================================================================
REM  Starts the Telegram bot. Keep this window open - it is the bot.
REM  The token is NOT stored in this file. Set it once, permanently:
REM
REM      setx TELEGRAM_BOT_TOKEN "123456:AA..."
REM      setx TELEGRAM_OWNER_ID  "987654321"
REM
REM  then close and reopen the console (setx only affects new windows).
REM ===================================================================
setlocal
cd /d "%~dp0"

where python >nul 2>nul && (set "PY=python") || (set "PY=py")

if "%TELEGRAM_BOT_TOKEN%"=="" (
  echo.
  echo [X] TELEGRAM_BOT_TOKEN is not set.
  echo     Run these two lines once in a Command Prompt, then reopen it:
  echo.
  echo       setx TELEGRAM_BOT_TOKEN "your-token-from-BotFather"
  echo       setx TELEGRAM_OWNER_ID  "your-numeric-id-from-userinfobot"
  echo.
  pause & exit /b 1
)

echo Bot running. Forward channel posts to your channel. Ctrl+C to stop.
echo.
%PY% bot.py
pause
