# -*- coding: utf-8 -*-
"""
تریدرزآرنا — کندل روزانهٔ شاخص کل (سقف و کف درون‌روزی).

    https://tradersarena.ir/data/000/prices?timeframe=0

── چرا این فایل هست
   بقیهٔ منابع ما فقط **پایانی** می‌دهند: یک عدد برای هر روز. با یک عدد
   نمی‌شود کندل کشید. این آدرس همان چیزی است که صفحهٔ تحلیل تکنیکال خودِ
   تریدرزآرنا می‌خواند، و سقف و کف درون‌روزی را از ۱۳۹۰/۰۱/۰۶ تا امروز
   دارد — حدود ۳٬۷۰۰ روز در یک درخواست.

── شکل پاسخ
   {"candles": [[زمان, باز, سقف, کف, بسته, ۱.۰, تاریخ‌شمسی, بسته, هم‌وزن], …],
    "auth": false}

   ستون آخر شاخص هم‌وزن است و دقیقاً با `index_ew` خودمان می‌خواند، پس
   این‌جا نوشته نمی‌شود — همان سری از منبع خودش بیاید بهتر است.

── ⚠ دو نکته که باید بدانید، وگرنه نمودار دروغ می‌گوید
   ۱. «باز» قیمتِ بازگشایی نیست؛ در ۹۹.۹٪ کندل‌ها دقیقاً پایانیِ روز
      قبل است. برای شاخص این طبیعی است و خودِ سایت هم همین را می‌کشد،
      ولی یعنی بدنهٔ کندل «تغییر نسبت به دیروز» را نشان می‌دهد نه
      «تغییر از بازگشایی تا بسته‌شدن».

   ۲. در ۳۵۲ کندل از ۳٬۷۰۳ (۹.۵٪) پایانی بیرونِ بازهٔ سقف و کف می‌افتد.
      دلیلش این است که سقف و کف از شاخصِ *لحظه‌ای* می‌آیند و پایانی از
      شاخصِ *پایانی*، و این دو همیشه یکی نیستند. رسم‌کننده باید سایه را
      تا باز و بسته گسترش بدهد وگرنه بدنه از سایه می‌زند بیرون.

   دامنهٔ روزانه (سقف−کف ÷ پایانی) میانه ۰.۵۳٪ و صدک نود ۱.۶۳٪ است —
   یعنی سایه‌ها واقعاً حرفی برای گفتن دارند، خط صاف نیستند.

── اعتبارسنجی
   پایانیِ ۲٬۹۰۱ کندل از ۳٬۷۰۳ **دقیقاً** با `index_total` خودمان یکی
   درآمد و بقیه هم فقط گرد شده‌اند (بیشترین اختلاف ۰.۰۷٪، میانه زیر
   ۰.۰۰۳٪). پس همان سری است، نه تعریف دیگری.
"""
import json

from .common import get

URL = "https://tradersarena.ir/data/{inst}/prices?timeframe={tf}"
INSTRUMENT = "000"                 # شاخص کل
TF_DAILY = 0

# کمترین تعداد کندلِ قابل‌قبول؛ کمتر از این یعنی پاسخ آن چیزی نیست که
# فکر می‌کنیم (صفحهٔ خطا، تغییر ساختار، یا پاسخ خالی).
MIN_ROWS = 100

# کلید سری -> جای عدد در ردیف
COLUMNS = {"index_open": 1, "index_high": 2, "index_low": 3}

DATE_COL = 6
CLOSE_COL = 4

# بیرون از این بازه یعنی عدد آن چیزی نیست که انتظار داریم. شاخص کل از
# ۱۳۹۰ تا امروز بین حدود ۲۳ هزار و ۸ میلیون بوده؛ بازه را دست‌ودل‌بازانه
# می‌گیریم تا رشد آینده را رد نکند.
MIN_VAL, MAX_VAL = 1e3, 1e9


def sane(row):
    """چند رابطه که در کندل درست همیشه برقرارند. خطا → پیام، سالم → None."""
    try:
        o, h, l, c = row[1], row[2], row[3], row[CLOSE_COL]
    except (IndexError, TypeError):
        return "ردیف کوتاه‌تر از انتظار"
    for name, v in (("باز", o), ("سقف", h), ("کف", l), ("بسته", c)):
        if not isinstance(v, (int, float)):
            return f"{name} عدد نیست"
        if not (MIN_VAL <= v <= MAX_VAL):
            return f"{name} بیرون بازهٔ معقول: {v}"
    if h < l:
        return f"سقف کمتر از کف: {h} < {l}"
    return None


def day_of(row):
    """تاریخ شمسی هشت‌رقمی از ستون تاریخ."""
    d = str(row[DATE_COL]).strip()
    return d if len(d) == 8 and d.isdigit() else None


def parse(text, since=None):
    """خروجی: (rows, notes) — rows = [(date_j, series, value, src_ref), …]"""
    try:
        data = json.loads(text)
    except Exception:                                   # noqa: BLE001
        return [], ["کندل تریدرزآرنا: پاسخ JSON نبود."]

    candles = data.get("candles") if isinstance(data, dict) else None
    if not isinstance(candles, list):
        return [], ["کندل تریدرزآرنا: کلید candles نبود — ساختار عوض شده؟"]
    if len(candles) < MIN_ROWS:
        return [], [f"کندل تریدرزآرنا: فقط {len(candles)} کندل آمد، "
                    f"کمتر از {MIN_ROWS}."]

    rows, notes, bad = [], [], 0
    for row in candles:
        if not isinstance(row, list):
            continue
        date_j = day_of(row)
        if not date_j:
            continue
        if since and date_j <= since:
            continue
        why = sane(row)
        if why:
            bad += 1
            if bad <= 3:
                notes.append(f"کندل {date_j} رد شد — {why}")
            continue
        for series, i in COLUMNS.items():
            rows.append((date_j, series, float(row[i]),
                         f"tradersarena/data/{INSTRUMENT}/prices"))
    if bad > 3:
        notes.append(f"… و {bad - 3} کندل دیگر هم رد شد.")
    if not rows and not notes:
        notes.append("کندل تریدرزآرنا چیزی تازه‌تر از دیتابیس نداشت.")
    return rows, notes


def fetch(session=None, since=None, instrument=INSTRUMENT):
    """
    خروجی: (rows, notes)

    since: فقط روزهای بعد از این تاریخ برگردانده می‌شوند. بار شبکه را کم
    نمی‌کند (پاسخ یک‌جا می‌آید) ولی حجم نوشتن را کم می‌کند.
    """
    url = URL.format(inst=instrument, tf=TF_DAILY)
    try:
        body = get(url, session)
    except Exception as e:                              # noqa: BLE001
        return [], [f"کندل تریدرزآرنا در دسترس نبود: {type(e).__name__}"]
    return parse(body, since)
