#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تست منابع خودکار، بدون اینترنت.

    python3 tests/run.py

صفحه‌های واقعیِ ۱۴۰۵/۰۷/۱۲ در پوشهٔ fixtures ذخیره شده‌اند. اگر روزی
یکی از سایت‌ها ساختارش را عوض کرد و برداشت خراب شد، اول این را بزنید:
اگر اینجا سبز است یعنی پارسر سالم است و مشکل جای دیگری است (شبکه،
فیلترینگ، تغییر آدرس). اگر اینجا هم قرمز شد یعنی واقعاً صفحه عوض شده.
"""
import json
import os
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))

FIX = HERE / "fixtures"

ok = fail = 0


def check(label, got, want, tol=0.0):
    global ok, fail
    good = (abs(got - want) <= tol) if isinstance(want, float) else (got == want)
    show = f"{got:,}" if isinstance(got, (int, float)) and not isinstance(got, bool) else repr(got)
    extra = "" if good else f"   (انتظار {want!r})"
    print(("  ✅ " if good else "  ❌ ") + f"{label}: {show}" + extra)
    ok, fail = ok + good, fail + (not good)


def main():
    import sources.common as common
    from sources import tradersarena, chartix_live, parsis_web

    print("تریدرزآرنا — جدول سوابق")
    rows, notes = tradersarena.parse((FIX / "ta_history.html").read_text(encoding="utf-8"))
    d = {(a, b): c for a, b, c, _ in rows}
    check("ارزش معاملات خرد ۱۴۰۵/۰۷/۱۲", d[("14050712", "value_retail")], 51319.8, 0.05)
    check("ورود پول ۱۴۰۵/۰۷/۱۲", d[("14050712", "flow_retail")], -846.4, 0.05)
    check("شاخص کل ۱۴۰۵/۰۷/۱۱", d[("14050711", "index_total")], 7808068.0, 0.5)
    check("شاخص هم‌وزن ۱۴۰۵/۰۷/۱۱", d[("14050711", "index_ew")], 2068720.0, 0.5)
    check("ردیف امروز بدون شاخص رد نشده", ("14050712", "index_total") not in d, True)
    if notes:
        print("  ⚠", "؛ ".join(notes))

    print("\nچارتیکس — قیمت از خود صفحه")
    H = chartix_live.RIAL_PER_HEMAT
    v, u = chartix_live.price_of((FIX / "chartix_page.html").read_text(encoding="utf-8"))
    check("ارزش بورس (همت)", round(v / H, 1), 22536.2, 0.05)
    v, u = chartix_live.price_of((FIX / "chartix_ifb.html").read_text(encoding="utf-8"))
    check("ارزش فرابورس (همت)", round(v / H, 1), 3314.4, 0.05)
    g, _ = chartix_live.price_of((FIX / "chartix_gold.html").read_text(encoding="utf-8"))
    check("طلای ۱۸ (تومان بر گرم)", g, 26395500.0, 0.5)
    a, _ = chartix_live.price_of((FIX / "chartix_all_irr.html").read_text(encoding="utf-8"))
    b, _ = chartix_live.price_of((FIX / "chartix_all_usd.html").read_text(encoding="utf-8"))
    check("نرخ دلار (تومان)", round(a / b / 10), 267500)

    print("\nپارسیس — نسخهٔ وب کانال")
    rows, notes = parsis_web.parse((FIX / "parsis_web.html").read_text(encoding="utf-8"))
    d = {(x, y): z for x, y, z, _ in rows}
    check("ارزش معاملات خرد", d[("14050712", "value_retail")], 51314.0, 0.5)
    check("خروج پول حقیقی", d[("14050712", "flow_retail")], -1131.0, 0.5)
    check("سهم حقیقی از خرید", d[("14050712", "buy_share")], 74.0, 0.05)
    # سرانه عمداً از پارسیس نوشته نمی‌شود — تعریفش با تریدرزآرنا یکی نیست
    check("پارسیس سرانه نمی‌نویسد",
          not any(s.startswith("sarane") for _, s, _, _ in rows), True)

    print("\nصندوق درآمد ثابت — از تفاضل دو جدول تریدرزآرنا")
    import pathlib as _p
    import sources.tradersarena as _ta
    _fix = {"type=1": FIX / "ta_history.html", "type=0": FIX / "ta_history_all.html"}
    _real = _ta.get
    _ta.get = lambda u, s=None: _p.Path(
        next(v for k, v in _fix.items() if k in u)).read_text(encoding="utf-8")
    try:
        trows, _ = _ta.fetch()
    finally:
        _ta.get = _real
    td = {(a, b): c for a, b, c, _ in trows}
    check("ورود پول به درآمد ثابت", td[("14050712", "flow_fixed")], 3926.8, 0.05)
    check("معاملات درآمد ثابت", td[("14050712", "value_fixed")], 48165.3, 0.05)
    check("سرانه خرید (تریدرزآرنا)", td[("14050712", "sarane_buy")], 86.5, 0.05)
    check("سرانه فروش (تریدرزآرنا)", td[("14050712", "sarane_sell")], 117.9, 0.05)

    print("\nخروجی اکسل تریدرزآرنا — واحد و «فقط جای خالی»")
    import import_tradersarena as ita
    ex = ita.extract(FIX / "ta_export.csv", log=lambda *a: None)
    r = ex["14050722"]
    # ستون‌های فایل تومان‌اند؛ دیتابیس میلیارد تومان (ارزش/جریان) و
    # میلیون تومان (سرانه) می‌خواهد. اگر مقسوم‌علیه بیفتد، ارزش معاملات
    # می‌شود ۵۳ هزار میلیارد و نمودار به آسمان می‌رود.
    check("ارزش معاملات (میلیارد تومان)", round(r["value_retail"], 1), 53482.0, 0.05)
    check("ورود پول (میلیارد تومان)", round(r["flow_retail"], 1), -402.6, 0.05)
    check("سرانه خرید (میلیون تومان)", round(r["sarane_buy"], 2), 89.07, 0.005)
    check("شاخص کل بدون تقسیم", r["index_total"], 8425725.0, 0.5)
    check("شاخص هم‌وزن (عنوان با فاصلهٔ آخر)", r["index_ew"], 2225797.0, 0.5)
    # ستون «میانگین ارزش معاملات ۵ روزه» نباید به ارزش معاملات بخورد
    check("ستون‌های ۵ روزه نادیده گرفته شدند",
          abs(r["value_retail"] - 54327.9) > 1, True)

    import sqlite3
    from store import SCHEMA, upsert
    con = sqlite3.connect(":memory:")
    con.executescript(SCHEMA)
    con.execute("INSERT INTO observations VALUES "
                "('14050722','value_retail',99999,'xlsx_seed','','')")
    con.commit()
    have = {d for d, in con.execute(
        "SELECT date_j FROM observations WHERE series='value_retail'")}
    for d in sorted(ex):
        if d in have:                      # همان قاعدهٔ migrate: جای پر دست نمی‌خورد
            continue
        upsert(con, d, "value_retail", ex[d]["value_retail"], "tradersarena", "")
    got = dict(con.execute("SELECT date_j, value FROM observations WHERE series='value_retail'"))
    check("روز موجود دست‌نخورده ماند", got["14050722"], 99999.0)
    check("روز خالی پر شد", round(got["14050721"], 1), 48882.1, 0.05)

    # خروجی اختصاصی صندوق‌ها ستون‌هایش هم‌نام جدول اصلی است ولی معنایش
    # صندوق است. اگر نگاشت عوض نشود، ارزش معاملات صندوق روی ارزش معاملات
    # خرد می‌نشیند و سرانهٔ صندوق جای سرانهٔ حقیقیِ کل بازار را می‌گیرد.
    fx = {d: {ita.AS_FIXED[k]: v for k, v in vals.items() if k in ita.AS_FIXED}
          for d, vals in ex.items()}
    check("ارزش معاملات → ارزش صندوق", round(fx["14050722"]["value_fixed"], 1), 53482.0, 0.05)
    check("ورود پول → ورود پول صندوق", round(fx["14050722"]["flow_fixed"], 1), -402.6, 0.05)
    check("سرانهٔ صندوق سری نمی‌سازد",
          [k for k in fx["14050722"] if k.startswith("sarane")], [])
    check("شاخص از فایل صندوق نوشته نمی‌شود", "index_total" in fx["14050722"], False)

    print("\nAPI صفحهٔ اول تریدرزآرنا — صندوق اهرمی و طلا")
    from sources import ta_home
    th_rows, th_notes = ta_home.parse(
        (FIX / "ta_home_market0.json").read_text(encoding="utf-8"))
    th = {(a, b): c for a, b, c, _ in th_rows}
    check("تاریخ از خودِ پاسخ خوانده شد", {a for a, _ in th}, {"14050722"})
    # ارقام ریالی‌اند: ÷۱۰^۱۰ می‌شود میلیارد تومان. اگر مقسوم‌علیه بیفتد،
    # ارزش معاملات اهرمی می‌شود ۴۸ هزار میلیارد و نمودار به آسمان می‌رود.
    check("ارزش معاملات اهرمی (میلیارد تومان)",
          round(th[("14050722", "value_lev")], 2), 4873.23, 0.005)
    check("ورود پول اهرمی", round(th[("14050722", "flow_lev")], 2), 117.66, 0.005)
    check("ارزش معاملات صندوق طلا",
          round(th[("14050722", "value_goldfund")], 1), 18073.0, 0.05)
    check("ورود پول صندوق طلا",
          round(th[("14050722", "flow_goldfund")], 1), 2145.9, 0.05)
    # سبدهای دیگر در همان پاسخ هستند (afl، nsf) ولی نوشته نمی‌شوند: منبع
    # دقیق‌تری دارند. شاخص هم عمداً نه — عددش «آخرین» است نه پایانی.
    check("سبدهای دیگر نوشته نمی‌شوند",
          sorted({b for _, b in th}),
          ["flow_goldfund", "flow_lev", "value_goldfund", "value_lev"])
    if th_notes:
        print("  ⚠", "؛ ".join(th_notes))

    print("\nدیده‌بان صنایع — API روزانه")
    from sources import ta_industries as tind
    ir, inotes = tind.parse((FIX / "ta_industries.json").read_text(encoding="utf-8"),
                            "14050722", keep={"44", "27", "57", "01"})
    ind = {}
    for d, c, m, v, _ in ir:
        ind.setdefault(c, {})[m] = v
    check("تعداد صنعت خوانده‌شده", sorted(ind), ["01", "27", "44", "57"])
    check("ارزش معاملات بانک‌ها (میلیارد تومان)",
          round(ind["57"]["value"], 1), 5248.4, 0.05)
    check("ورود پول بانک‌ها", round(ind["57"]["flow"], 1), 204.4, 0.05)
    check("سرانه خرید بانک‌ها (میلیون تومان)",
          round(ind["57"]["sarane_buy"], 1), 167.0, 0.05)
    check("قدرت خرید فلزات اساسی", round(ind["27"]["power"], 2), -2.05, 0.005)
    # API هفت ستون از ده ستونِ جدول را دارد؛ حقوقی‌ها و شاخص گروه در آن
    # نیستند و از اکسل و جدول سوابق می‌آیند.
    check("API هفت سری می‌دهد", {len(v) for v in ind.values()}, {7})
    check("حقوقی از API نمی‌آید",
          any(k.endswith("_inst") for v in ind.values() for k in v), False)
    check("هشدار نداشت", inotes, [])

    # ردیفی که یک ستون جابه‌جا شده باید رد شود، نه اینکه عدد غلط بنویسد
    import json as _json
    raw = _json.loads((FIX / "ta_industries.json").read_text(encoding="utf-8"))
    shifted = [r[:3] + r[4:] for r in raw]          # یک ستون به چپ
    sr, snotes = tind.parse(_json.dumps(shifted), "14050722")
    check("ردیف جابه‌جاشده رد شد", sr, [])
    check("و دلیلش گزارش شد", len(snotes) > 0, True)

    # سبدهای صندوق کدشان نامکی است («gold-funds») و پذیرفته می‌شوند —
    # زیرتب خودشان را دارند. ولی فقط اگر در keep باشند: کدِ ناشناخته
    # بی‌سر‌و‌صدا وارد دیتابیس نمی‌شود.
    with_funds = raw + [["gold-funds", "صندوق های طلا"] + [1.0] * 29]
    fr, _ = tind.parse(_json.dumps(with_funds), "14050722",
                       keep={"44", "27", "57", "01", "gold-funds"})
    check("سبد صندوق هم برداشته می‌شود",
          sorted({c for _, c, _, _, _ in fr}),
          ["01", "27", "44", "57", "gold-funds"])
    fr2, _ = tind.parse(_json.dumps(with_funds), "14050722",
                        keep={"44", "27", "57", "01"})
    check("کد بیرون از keep رد می‌شود",
          sorted({c for _, c, _, _, _ in fr2}), ["01", "27", "44", "57"])

    print("\nصنایع — واحدِ سرستون و جدول سوابق")
    import import_industries as ii
    check("واحد داخل پرانتز", ii.split_unit("ارزش معاملات (تومان)"),
          ("ارزش معاملات", "تومان"))
    # تلهٔ هزاربرابر: اگر «میلیارد تومان» به «تومان» بخورد، عدد ۱۰^۹ برابر
    # غلط می‌شود. ترتیب بلند-به-کوتاه در UNITS همین را می‌گیرد.
    check("واحد بی‌پرانتز", ii.split_unit("ارزش معاملاتمیلیارد تومان"),
          ("ارزش معاملات", "میلیارد تومان"))
    check("بی‌واحد", ii.split_unit("قدرت خرید"), ("قدرت خرید", ""))
    check("تومان ÷ ۱۰^۹", ii.divisor("value", "تومان"), 1e9)
    check("میلیارد تومان همان‌طور", ii.divisor("value", "میلیارد تومان"), 1.0)
    check("سرانه تومان ÷ ۱۰^۶", ii.divisor("sarane_buy", "تومان"), 1e6)
    check("قدرت خرید بی‌واحد", ii.divisor("power", ""), 1.0)

    import backfill_industries as bi
    hdata, hnotes = bi.parse(
        (FIX / "ta_industry_history.html").read_text(encoding="utf-8"))
    check("دو روز از جدول سوابق", sorted(hdata), ["14050721", "14050722"])
    check("ارزش معاملات از سوابق", round(hdata["14050722"]["value"], 1), 5248.4, 0.05)
    check("ورود پول از سوابق", round(hdata["14050722"]["flow"], 1), 204.4, 0.05)
    check("شاخص گروه از جدول سوابق آمد",
          round(hdata["14050722"]["gindex"], 1), 31452.7, 0.05)
    check("ستون‌های ۵ و ۲۰ روزه کنار گذاشته شدند",
          sorted(hdata["14050722"]),
          ["buy_real", "flow", "gindex", "power", "sarane_buy",
           "sarane_sell", "sell_real", "value"])
    check("سوابق هشدار نداشت", hnotes, [])

    print("\nصنایع — فایل تُنُک هر صنعت")
    import make_chart
    import sqlite3 as _sq3
    import tempfile as _tmp
    from store import SCHEMA as _SC3
    c3 = _sq3.connect(":memory:")
    c3.executescript(_SC3)
    for d, v in (("14050301", 10.0), ("14050304", 12.0)):
        c3.execute("INSERT INTO industry_obs VALUES (?,?,?,?,'t','',' ')",
                   (d, "44", "value", v))
    c3.execute("INSERT INTO industry_obs VALUES "
               "('14050304','44','flow',-5.5,'t','',' ')")
    c3.commit()
    # ⚠ این تست یک بار `web/` واقعی را خراب کرد: `write_industries` روی
    #   WEB_DIR می‌نویسد، و وقتی فایل «ورود پول همهٔ صنایع» هم به آن
    #   اضافه شد، همین دیتابیسِ ساختگیِ تک‌صنعته آن را با `{}` بازنویسی
    #   کرد. سایت ساخته می‌شد، تب جمع باز می‌شد و می‌گفت «داده‌ای نیست».
    #   پس این‌جا WEB_DIR موقتاً جای دیگری می‌رود.
    _old_web = make_chart.WEB_DIR
    _tdir = _tmp.TemporaryDirectory()
    make_chart.WEB_DIR = pathlib.Path(_tdir.name)
    try:
        idx = make_chart.write_industries(c3, ["14050301", "14050302", "14050304"])
        check("فهرست یک صنعت دارد", [(x["c"], x["d"]) for x in idx], [("44", 2)])
        import json as _j3
        f3 = make_chart.WEB_DIR / make_chart.IND_DIR / "44.json"
        j3 = _j3.loads(f3.read_text(encoding="utf-8"))
        # ۰ و ۲ یعنی ردیف اول و سومِ محور — ردیف دوم داده ندارد و جا نمی‌گیرد
        check("شمارهٔ ردیف‌ها روی محور", j3["i"], [0, 2])
        check("مقدارها به ترتیب", j3["value"], [10.0, 12.0])
        check("سری بی‌داده ذخیره نشد", "sarane_buy" in j3, False)
        # فایل مشترکِ ورود پول: فقط روزهایی که عدد دارند، نه کل محور
        j4 = _j3.loads((make_chart.WEB_DIR / make_chart.FLOW_FILE)
                       .read_text(encoding="utf-8"))
        check("فایل ورود پول همان صنعت را دارد", sorted(j4), ["44"])
        # مخرجِ RMF هم کنارش می‌آید؛ هم‌طولِ همان روزها
        check("فقط روزِ دارای ورود پول، با مخرج",
              j4["44"], {"i": [2], "f": [-5.5], "v": [12.0]})
    finally:
        make_chart.WEB_DIR = _old_web
        _tdir.cleanup()
    check("web/ واقعی دست‌نخورده ماند",
          (_old_web / make_chart.FLOW_FILE).exists() is False
          or (_old_web / make_chart.FLOW_FILE).stat().st_size > 2, True)

    print("\nمحور نمودار — تقویم بازار از روی شاخص کل")
    import sqlite3 as _sq
    from store import SCHEMA as _SC
    c2 = _sq.connect(":memory:")
    c2.executescript(_SC)
    rows = [
        ("14050301", "index_total", 100.0),
        ("14050302", "index_total", 101.0),
        ("14050304", "index_total", 102.0),   # ۰۳ تعطیل رسمی بوده
        ("14050303", "mv_usd",       50.0),   # تعطیل، ولی بازار ارز باز
        ("14050302", "mv",          900.0),
        ("14050305", "mv",          910.0),   # فردای آخرین شاخص — باید بماند
        ("14041210", "mv",          800.0),   # درون تعطیلی طولانی بازار
        ("13990101", "gold18",   500000.0),   # طلا ردیف نمی‌سازد
    ]
    for d, s, v in rows:
        c2.execute("INSERT INTO observations VALUES (?,?,?,'test','','')", (d, s, v))
    c2.commit()
    p = make_chart.build_payload(c2)
    check("روز تعطیل رسمی حذف شد", "14050303" in p["d"], False)
    check("روزهای معاملاتی ماندند",
          [d for d in p["d"] if d.startswith("140503")],
          ["14050301", "14050302", "14050304", "14050305"])
    check("روز بعد از آخرین شاخص نمی‌افتد", "14050305" in p["d"], True)
    check("تعطیلی طولانی بازار حذف شد", "14041210" in p["d"], False)
    check("طلا ردیف نساخت", "13990101" in p["d"], False)

    print("\nنقدینگی — مدل ماهانه و اصلاح بازگشتی")
    import m2
    import sqlite3
    con = sqlite3.connect(":memory:")
    from store import SCHEMA
    con.executescript(SCHEMA)
    m2.ensure(con)
    con.execute("INSERT INTO observations VALUES ('14041206','m2',14834.48,'xlsx_seed','','')")
    # روز میانی و روز پایانی هر ماه، تا هم پخش روزانه و هم سطح ماه تست شود
    for day in ("14050115", "14050131", "14050215", "14050231", "14050315",
                "14050331", "14050431", "14050531", "14050615", "14050631"):
        con.execute("INSERT INTO observations VALUES (?,'index_total',1,'test','','')", (day,))
    con.commit()

    def val(d):
        return con.execute("SELECT value FROM observations WHERE series='m2' AND date_j=?",
                           (d,)).fetchone()[0]

    for mo in ("140501", "140502", "140503", "140504", "140505", "140506"):
        m2.set_month(con, mo, "rate", 3.54)
    m2.rebuild(con)

    # پایان شهریور باید دقیقاً ۱۴۸۳۴.۴۸ × ۱.۰۳۵۴^۶ باشد
    check("پایان شهریور با نرخ ۳.۵۴٪ (همت)", round(val("14050631"), 1),
          round(14834.48 * 1.0354 ** 6, 1), 1.0)
    check("پانزدهم شهریور وسط مرداد و شهریور است",
          val("14050531") < val("14050615") < val("14050631"), True)
    before = val("14050631")

    m2.set_month(con, "140502", "level", 16200)      # رقم واقعی بانک مرکزی رسید
    m2.rebuild(con)
    # اردیبهشت قفل می‌شود، چهار ماه بعدش با همان ۳.۵۴٪ از روی آن ادامه می‌یابند
    check("اردیبهشت دقیقاً روی رقم واقعی نشست", round(val("14050231"), 1), 16200.0, 1.0)
    check("پایان شهریور بعد از اصلاح", round(val("14050631"), 1),
          round(16200 * 1.0354 ** 4, 1), 1.0)
    check("اصلاح واقعاً ماه‌های بعدی را جابه‌جا کرد", val("14050631") > before * 1.01, True)
    check("فروردین (قبل از ماهِ اصلاح‌شده) دست‌نخورده ماند",
          round(val("14050131"), 1), round(14834.48 * 1.0354, 1), 1.0)
    src = con.execute("SELECT source FROM observations WHERE series='m2' AND date_j='14050231'"
                      ).fetchone()[0]
    check("منبع اردیبهشت رقم واقعی شد", src, "m2_level")

    # ------------------------------------------------------------------
    # این بخش بعد از یک اشتباه واقعی اضافه شد: چهار سری تازه (اهرمی و طلا)
    # به app.js و به دیتابیس اضافه شدند، data.json هم داشتشان، ولی قالب
    # صفحه از app.js *ساخته* می‌شود و ساختنش یادم رفت. نتیجه: نه چیپ
    # گرفتند و نه ستون جدول، و هیچ خطایی هم نداد. این تست همان را می‌گیرد.
    print("\nقالب صفحه — همگام با app.js")
    import re as _re
    from config import CHART_DIR
    appjs = (CHART_DIR / "app.js").read_text(encoding="utf-8")
    body = appjs.split("const SERIES = [", 1)[1].split("\n];", 1)[0]
    app_keys = _re.findall(r'\{k:"([^"]+)"', body)
    check("app.js فهرست سری دارد", len(app_keys) > 10, True)

    payload_keys = {make_chart.ALIAS.get(k, k) for k in make_chart.KEYS}
    missing = [k for k in app_keys if k not in payload_keys]
    check("هر سری صفحه در داده هم هست", missing, [])

    for name in ("template.html", "template_web.html"):
        tpl = (CHART_DIR / name)
        stale = [k for k in app_keys if f'k:"{k}"' not in tpl.read_text(encoding="utf-8")]
        check(f"{name} کهنه نیست", stale, [])

    # ------------------------------------------------------------------
    # این بخش هم بعد از یک اشتباه واقعی اضافه شد: اکسل‌ها در گفت‌وگو وارد
    # دیتابیسِ من می‌شدند، ولی هیچ فایلی همراه کد نمی‌رفت — پس روی
    # کامپیوتر کاربر هیچ‌کدامشان نبودند و سایت خالی می‌ماند. حالا
    # export_bundle.py فایلشان را می‌سازد و migrate واردشان می‌کند.
    # ------------------------------------------------------------------
    # علامت ورود پول — یک بار خواستم از کلاس `minus` بخوانمش و داده را
    # وارونه کرد. این تست همان قاعده را قفل می‌کند: علامت فقط از متن.
    # ------------------------------------------------------------------
    # چارتیکس آبان ۱۴۰۵ قالب صفحه را عوض کرد و هر پنج نماد ساکت از کار
    # افتادند. این تست هر دو قالب را نگه می‌دارد، و مهم‌تر: مطمئن می‌شود
    # عددِ «نمادهای مرتبط» پایین صفحه با تیتر قیمت اشتباه گرفته نشود.
    print("\nچارتیکس — قالب تازهٔ صفحه")
    from sources import chartix_live as _cx
    _new = (FIX / "chartix_new_layout.html").read_text(encoding="utf-8")
    _v, _u = _cx.price_of(_new)
    check("قیمت از قالب تازه خوانده شد", _v, 274303193274824160.0)
    check("واحد هم خوانده شد", _u, "IRR")
    _old = (FIX / "chartix_page.html").read_text(encoding="utf-8")
    check("قالب قدیمی هنوز کار می‌کند", _cx.price_of(_old)[0] is not None, True)
    check("صفحهٔ بی‌قیمت ساکت نمی‌ماند", _cx.price_of("<html>هیچ</html>"), (None, None))

    print("\nعلامت ورود پول — فقط از متن، نه از کلاس قرمز")
    from sources import tradersarena as _ta
    _rows, _ = _ta.parse((FIX / "ta_history_all.html").read_text(encoding="utf-8"))
    _flow = {d: v for d, s, v, _ in _rows if s == "flow_retail"}
    check("خانهٔ کلاس‌minus با متن مثبت، مثبت ماند",
          round(_flow.get("14050712", 0), 1), 3080.4, 0.05)
    check("خانه‌ای که علامتش در متن است منفی خوانده شد",
          round(_flow.get("14050711", 0), 1), -7140.8, 0.05)
    _val = {d: v for d, s, v, _ in _rows if s == "value_retail"}
    check("ارزش معاملات هیچ‌وقت منفی نشد",
          [d for d, v in _val.items() if v < 0], [])

    # ------------------------------------------------------------------
    # و همین‌جا بود که باز خورد زمین، از یک جای دیگر: علامت *در متن* بود
    # ولی خط‌تیرهٔ اَسکی نبود. تریدرزآرنا ستون فارسی‌رقم «ورود پول» را با
    # U+2212 و یک U+200E می‌نویسد، و الگوی `-?\d+` آن را بی‌صدا می‌انداخت.
    # ۱۴۰۵/۰۷/۲۹ و ۰۸/۰۲ و ۰۸/۰۳ خروج پول داشتند، در دیتابیس ورود شدند.
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # تاریخچهٔ چارتیکس — تنها راه جبران سوراخ در ارزش بازار و دلار و طلا.
    # روی روزهای مشترک با دیتابیس عیناً یکی درآمد، پس اگر روزی ضریب یا
    # تبدیل تاریخ به‌هم بخورد، همین دو عدد لو می‌دهند.
    # ------------------------------------------------------------------
    print("\nتاریخچهٔ چارتیکس — کندل روزانه")
    import json as _js
    from sources import chartix_history as _chh
    _hist = _js.loads((FIX / "chartix_history.json").read_text(encoding="utf-8"))
    check("یونیکس → شمسی", _chh.day_of(1793059200), "14050805")
    _tse = _chh.parse(_js.dumps(_hist["BRS00IRMCAP"]))
    check("ارزش بورس ۱۴۰۵/۰۸/۰۵ (همت)",
          round(_tse["14050805"] / _chh.RIAL_PER_HEMAT, 4), 22930.3041, 0.0005)
    check("پاسخ نامفهوم خالی برمی‌گردد", _chh.parse('{"message":"bad"}'), {})

    class _FakeSession:                      # بدون شبکه
        def get(self, url, **kw):
            t = url.split("ticker=")[1].split("&")[0]
            body = _js.dumps(_hist[t])

            class R:
                text = body

                def raise_for_status(self):
                    pass
            return R()

    _rows, _ns = _chh.fetch(session=_FakeSession())
    check("هشداری نداد", _ns, [])
    _by = {(d, s): v for d, s, v, _ in _rows}
    check("ارزش بورس به همت", round(_by[("14050805", "mv_tse")], 4), 22930.3041, 0.0005)
    check("ارزش فرابورس به همت", round(_by[("14050805", "mv_ifb")], 4), 3616.9566, 0.0005)
    check("طلای ۱۸ عیار دست‌نخورده", _by[("14050805", "gold18")], 25977700.0)
    check("نرخ دلار از تقسیم دو نماد",
          round(_by[("14050805", "usd_rate")]), 270500.0, 2)
    check("ارزش دلاری از این‌جا نوشته نمی‌شود",
          any(s == "mv_usd" for _, s, _, _ in _rows), False)
    check("since روزهای قدیمی را می‌اندازد",
          any(d <= "14050804" for d, _, _, _ in
              _chh.fetch(session=_FakeSession(), since="14050804")[0]), False)

    # ------------------------------------------------------------------
    # نرخ بدون ریسک از بازده اسناد خزانه. دو چیز می‌تواند بی‌صدا خراب شود
    # و هر دو این‌جا قفل‌اند: قالب نامِ نماد (که تاریخ سررسید از آن
    # درمی‌آید) و ارزش اسمی. اگر یکی عوض شود، عدد همچنان «یک عدد» است،
    # فقط غلط — پس روی مقدار واقعی تست می‌شود نه روی اجرا شدن.
    # ------------------------------------------------------------------
    print("\nنرخ بدون ریسک — بازده تا سررسید اسناد خزانه")
    import json as _ja
    import datetime as _dt
    from sources import akhza as _ak
    _fx = _ja.loads((FIX / "akhza.json").read_text(encoding="utf-8"))

    check("سررسید از نام نماد",
          _ak.maturity("اسنادخزانه-م1بودجه05-080225"), _dt.date(2029, 5, 14))
    check("نام بدون تاریخ → None", _ak.maturity("اسنادخزانه-م1بودجه05"), None)
    check("تاریخ نامعتبر → None", _ak.maturity("چیزی-059999"), None)
    # ورقهٔ یک‌ساله که نصف قیمت می‌خورد، یعنی صد درصد بازده
    check("بازده یک‌ساله", round(_ak.ytm(500_000, 365), 6), 1.0)
    check("ورقهٔ خیلی نزدیک به سررسید رد می‌شود", _ak.ytm(990_000, 5), None)
    check("قیمت صفر رد می‌شود", _ak.ytm(0, 300), None)

    _bonds = [(_ak.maturity(_fx["syms"][t]["desc"]), _fx["hist"][t])
              for t in _fx["syms"]]
    _rates = _ak.daily_rates(_bonds)
    check("روزهای دارای نرخ", len(_rates) > 0, True)
    _last = max(_rates)
    check("نرخ روز آخر در بازهٔ باورپذیر",
          0.30 < _rates[_last] < 0.60, True)
    # ورقهٔ سررسیدشده (اخزا۰۰۶، سررسید ۱۴۰۳/۰۷) نباید در نرخِ امروز بیاید
    _expired = _ak.maturity(_fx["syms"]["BRS001583"]["desc"])
    check("ورقهٔ سررسیدشده کنار گذاشته شد",
          _ak.ytm(900_000, (_expired - _last).days), None)
    _m = _ak.monthly(_rates)
    check("کلید، ماه شمسی است", all(len(k) == 6 for k in _m), True)
    check("هر ماه فقط یک مقدار", len(_m) == len({k for k in _m}), True)

    # ⚠ همان جایی که یک بار بی‌صدا افتاد: مقدار ماه باید روی یک روزِ
    #   *معاملاتی* بنشیند، وگرنه روی محور نمودار جا ندارد و ناپدید می‌شود.
    _td = ["14050401", "14050402", "14050501", "14050801", "14050805"]
    _pl = _ak.place({"140504": 0.4, "140508": 0.42, "140512": 0.5}, _td)
    check("روی اولین روز معاملاتیِ ماه نشست",
          _pl, [("14050401", 0.4), ("14050801", 0.42)])
    check("ماهی که روز معاملاتی ندارد جا می‌ماند",
          any(d.startswith("140512") for d, _ in _pl), False)
    check("بدون فهرست روزها چیزی برنمی‌گردد", _ak.place({"140508": 0.4}, []), [])

    import migrate as _mg
    check("فایل تاریخچهٔ نرخ همراه کد هست", _mg.RFR_CSV.exists(), True)
    if _mg.RFR_CSV.exists():
        import csv as _c7
        with open(_mg.RFR_CSV, encoding="utf-8", newline="") as _f7:
            _rr = list(_c7.DictReader(_f7))
        check("تاریخچه خالی نیست", len(_rr) > 50, True)
        check("همهٔ ماه‌ها یکتا",
              len(_rr) == len({r["date_j"][:6] for r in _rr}), True)
        _vals = [float(r["rfr"]) for r in _rr]
        check("همه در بازهٔ باورپذیر درصد",
              all(5 < v < 150 for v in _vals), True)
        check("ترتیب تاریخی", [r["date_j"] for r in _rr] ==
              sorted(r["date_j"] for r in _rr), True)

    print("\nعلامت منفی یونیکدی (U+2212) — نه فقط خط‌تیرهٔ اَسکی")
    check("U+2212 با رقم لاتین", common.num("‎−2,194.4"), -2194.4, 0.001)
    check("U+2212 با رقم فارسی", common.num("‎−۲,۱۹۴.۴"), -2194.4, 0.001)
    check("خط‌تیرهٔ اَسکی مثل قبل", common.num("-846.4"), -846.4, 0.001)
    check("منفیِ جدا‌افتاده با مرز تگ", common.num("- 4,108.0"), -4108.0, 0.001)
    check("«۱۲۳ - ۴۵۶» اشتباهی منفی نشد", common.num("۱۲۳ - ۴۵۶"), 123.0, 0.001)
    check("پسوند K سر جایش", common.num("418.87 K"), 418870.0, 0.5)
    check("خانهٔ خالی/خط‌تیره تنها → None", common.num("—"), None)

    _rows, _ = _ta.parse((FIX / "tradersarena_u2212.html").read_text(encoding="utf-8"))
    _flow = {d: v for d, s, v, _ in _rows if s == "flow_retail"}
    check("خروج پول ۱۴۰۵/۰۸/۰۳ منفی خوانده شد",
          round(_flow.get("14050803", 0), 1), -2194.4, 0.05)
    check("ورود پول ۱۴۰۵/۰۷/۲۷ مثبت ماند",
          round(_flow.get("14050727", 0), 1), 3309.8, 0.05)
    _v2 = {d: v for d, s, v, _ in _rows if s == "value_retail"}
    check("ارزش معاملات همان قالب سالم ماند",
          round(_v2.get("14050803", 0), 1), 46780.5, 0.05)
    _i2 = {d: v for d, s, v, _ in _rows if s == "index_total"}
    check("شاخص کل همان قالب سالم ماند", _i2.get("14050803"), 8015546.0)

    print("\nفایل‌های همراه — داده‌هایی که فقط از اکسل می‌آیند")
    import gzip as _gz
    import csv as _csv
    import sqlite3 as _sq4
    import migrate as _mig
    from store import SCHEMA as _SC4, upsert_ind as _ui

    check("فایل صنایع همراه کد هست", _mig.IND_BUNDLE.exists(), True)
    check("فایل سری‌های بی‌فایل همراه کد هست", _mig.EXTRA_BUNDLE.exists(), True)

    if _mig.IND_BUNDLE.exists():
        with _gz.open(_mig.IND_BUNDLE, "rt", encoding="utf-8", newline="") as _fh:
            _rows = list(_csv.DictReader(_fh))
        check("فایل صنایع خالی نیست", len(_rows) > 1000, True)
        check("درآمد ثابت داخلش هست",
              any(r["ind"] == "fixed-income-funds" for r in _rows), True)
        check("مسیر کامپیوترِ من داخلش نیست",
              any("/" in (r.get("source") or "") for r in _rows), False)

        # قاعدهٔ طلایی: مهاجرت فقط جای خالی را پر می‌کند. یک ردیف دستی با
        # عدد عمداً غلط می‌گذاریم و می‌بینیم دست‌نخورده می‌ماند.
        c4 = _sq4.connect(":memory:")
        c4.executescript(_SC4)
        r0 = _rows[0]
        _ui(c4, r0["date_j"], r0["ind"], "value", -12345.0, "tsetmc", "قبلی")
        c4.commit()
        _mig.ensure_industry_bundle(c4, log=lambda *a: None)
        kept = c4.execute("SELECT value, source FROM industry_obs WHERE date_j=? "
                          "AND ind=? AND metric='value'",
                          (r0["date_j"], r0["ind"])).fetchone()
        check("ردیف موجود دست‌نخورده ماند", kept, (-12345.0, "tsetmc"))
        n_new = c4.execute("SELECT COUNT(*) FROM industry_obs").fetchone()[0]
        check("بقیه وارد شدند", n_new > 1000, True)
        c4.close()

    if _mig.EXTRA_BUNDLE.exists():
        with open(_mig.EXTRA_BUNDLE, encoding="utf-8", newline="") as _fh:
            _ex = list(_csv.DictReader(_fh))
        check("نقدینگی اکسلی داخلش هست",
              sum(1 for r in _ex if r["source"] == "m2_file") > 1000, True)
        check("مسیر آپلود داخلش نیست",
              any("uploads" in (r.get("src_ref") or "") for r in _ex), False)

    # ------------------------------------------------------------------
    # تصحیح ردیف‌هایی که باگ علامت خراب کرده بود. تنها بازنویسیِ برنامه
    # است، پس قیدهایش باید قفل باشند: فقط منبع tradersarena، فقط همان
    # روزها، و بار دوم هیچ کاری نکند.
    # ------------------------------------------------------------------
    print("\nتصحیح علامتِ ردیف‌های ثبت‌شده")
    c5 = _sq4.connect(":memory:")
    c5.executescript(_SC4)
    _u5 = __import__("store").upsert
    # وضعیت دیتابیس کاربر: ۰۸/۰۳ غلط از تریدرزآرنا، ۰۸/۰۴ درست از پارسیس
    for _d, _s, _v, _src in [("14050803", "flow_retail", 2194.4, "tradersarena"),
                             ("14050803", "flow_fixed", -1745.0, "tradersarena"),
                             ("14050802", "flow_retail", 8121.7, "parsistahlil"),
                             ("14050727", "flow_retail", 3309.8, "tradersarena")]:
        _u5(c5, _d, _s, _v, _src, "تست")
    _ui(c5, "14050803", "fixed-income-funds", "flow", -1745.0, "tradersarena", "تست")
    c5.commit()
    check("بار اول کار کرد", _mig.ensure_flow_sign_fix(c5, log=lambda *a: None), True)
    _g5 = lambda d, s: c5.execute(                                    # noqa: E731
        "SELECT value FROM observations WHERE date_j=? AND series=?",
        (d, s)).fetchone()[0]
    check("ردیف غلط تریدرزآرنا منفی شد", _g5("14050803", "flow_retail"), -2194.4)
    check("درآمد ثابتِ همان روز بازحساب شد", _g5("14050803", "flow_fixed"), 2643.8)
    check("ردیف پارسیس دست‌نخورده ماند", _g5("14050802", "flow_retail"), 8121.7)
    check("روزی که از اول درست بود دست‌نخورده ماند",
          _g5("14050727", "flow_retail"), 3309.8)
    check("آینهٔ صنایع هم تصحیح شد",
          c5.execute("SELECT value FROM industry_obs WHERE date_j='14050803' "
                     "AND ind='fixed-income-funds' AND metric='flow'").fetchone()[0],
          2643.8)
    check("بار دوم ساکت", _mig.ensure_flow_sign_fix(c5, log=lambda *a: None), False)
    c5.close()

    # همتای صنعتی‌اش: فقط ردیفی که *وارونهٔ* مقدار درست است عوض می‌شود
    print("\nتصحیح علامتِ ورود پول صنایع")
    check("جدول تصحیح همراه کد هست", _mig.FLOW_FIX.exists(), True)
    if _mig.FLOW_FIX.exists():
        import csv as _c6
        with open(_mig.FLOW_FIX, encoding="utf-8", newline="") as _f6:
            _fix = list(_c6.DictReader(_f6))
        check("جدول تصحیح خالی نیست", len(_fix) > 100, True)
        _r6 = _fix[0]
        _good = float(_r6["flow"])
        c6 = _sq4.connect(":memory:")
        c6.executescript(_SC4)
        # وارونه، از همان منبع → باید برگردد
        _ui(c6, _r6["date_j"], _r6["ind"], "flow", -_good, "tradersarena", "ت")
        # همان روز، صنعت دیگر، عددی کاملاً متفاوت → باید بماند
        _ui(c6, _r6["date_j"], "zz-other", "flow", 9999.0, "tradersarena", "ت")
        # وارونه ولی از منبع دیگر → دست نمی‌خورد
        _ui(c6, _r6["date_j"], _fix[1]["ind"], "flow",
            -float(_fix[1]["flow"]), "parsistahlil", "ت")
        c6.commit()
        check("بار اول کار کرد",
              _mig.ensure_industry_flow_sign(c6, log=lambda *a: None), True)
        _g6 = lambda i: c6.execute(                                  # noqa: E731
            "SELECT value FROM industry_obs WHERE date_j=? AND ind=? "
            "AND metric='flow'", (_r6["date_j"], i)).fetchone()[0]
        check("ردیف وارونه برگشت", round(_g6(_r6["ind"]), 4), round(_good, 4))
        check("عدد نامربوط دست‌نخورده ماند", _g6("zz-other"), 9999.0)
        check("منبع دیگر دست‌نخورده ماند",
              round(_g6(_fix[1]["ind"]), 4), round(-float(_fix[1]["flow"]), 4))
        check("بار دوم ساکت",
              _mig.ensure_industry_flow_sign(c6, log=lambda *a: None), False)
        c6.close()

    # ------------------------------------------------------------------
    # صفحه از دو فایل ساخته می‌شود و هیچ‌چیز به هم وصلشان نمی‌کند جز
    # رشتهٔ شناسه. یک غلط تایپی در `getElementById` خطای زمان اجراست که
    # فقط وقتی معلوم می‌شود کسی آن تب را باز کند. این‌جا همهٔ شناسه‌هایی
    # که app.js می‌خواهد با چیزی که head.html دارد سنجیده می‌شود.
    # ------------------------------------------------------------------
    print("\nصفحهٔ نمودار — شناسه‌های HTML و JS")
    import re as _re
    _chd = HERE.parent / "charts"
    _js = (_chd / "app.js").read_text(encoding="utf-8")
    _html = (_chd / "head.html").read_text(encoding="utf-8")
    _have = set(_re.findall(r'id="([^"]+)"', _html))
    _want = set(_re.findall(r'getElementById\("([^"]+)"\)', _js))
    check("شناسه‌ای که JS می‌خواهد و در HTML نیست", sorted(_want - _have), [])
    check("تب جمع ورود پول در هر دو هست",
          "flowCards" in _have and "flowCards" in _want, True)

    # فایل ورود پول صنایع: اسمش در make_chart و خواندنش در app.js باید یکی باشد
    import make_chart as _mc
    check("نام فایل ورود پول یکی است",
          f'IND.flow' in _js and _mc.FLOW_FILE == "flow.json", True)

    # ⚠ دو مسیر صفحه را می‌سازند: make_chart --web و publish.build. یک بار
    #   سرِ قالب از هم در رفتند و چهار سری بی‌صدا از سایت افتادند. این دو
    #   تست همان را قفل می‌کنند: هر دو از ind_block بگیرند، و فایل تازه
    #   هم واقعاً روی ریپو کپی شود.
    _pub = (HERE.parent / "publish.py").read_text(encoding="utf-8")
    check("هر دو مسیر از ind_block می‌گیرند",
          "ind_block(" in _pub and "ind_block(" in
          (HERE.parent / "make_chart.py").read_text(encoding="utf-8"), True)
    check("فایل ورود پول هم منتشر می‌شود", "FLOW_FILE" in _pub, True)
    _blk = _mc.ind_block(None, [], web=False)
    check("حالت محلی فایل نمی‌خواهد", [_blk["dir"], _blk["flow"]], [None, None])

    # ------------------------------------------------------------------
    # سیگنال روزانه. روی یک دیتابیس ساختگیِ کوچک، تا عددها را خودمان
    # بدانیم: شاخصی که بالا می‌رود و بعد ۲۰٪ می‌ریزد باید کلید روند را
    # بچرخاند، و روزی با جریان قوی و ارزش بالا باید «انباشت» شود.
    # ------------------------------------------------------------------
    print("\nسیگنال روزانه")
    import signals as _sg
    c8 = _sq4.connect(":memory:")
    c8.executescript(_SC4)

    def _put(d, s, v):
        c8.execute("INSERT OR REPLACE INTO observations VALUES (?,?,?,?,?,?)",
                   (d, s, float(v), "t", "", ""))

    # ۳۰۰ روز: صعود تا ردیف ۲۰۰، بعد ریزش ۲۵٪
    _days = []
    for i in range(300):
        d = f"1404{(i // 30) + 1:02d}{(i % 30) + 1:02d}"
        _days.append(d)
        px = 1000 + i * 10 if i <= 200 else 3000 * (1 - 0.25 * (i - 200) / 99)
        _put(d, "index_total", px)
        _put(d, "value_retail", 100.0)
        _put(d, "flow_retail", 0.0)
    c8.commit()
    _t8 = _sg.trend(c8)
    check("کلید روند بعد از ریزش ۲۵٪ منفی شد", _t8["state"], "منفی")
    check("روز چرخش درست پیدا شد", _t8["since"] > _days[200], True)

    # پنج روز آخر: جریان قوی و ارزش دوبرابر
    for d in _days[-5:]:
        _put(d, "flow_retail", 20.0)       # ۲۰ از ۲۰۰ = ۱۰٪ > ۴٪
        _put(d, "value_retail", 200.0)
    c8.commit()
    _a8 = _sg.accumulation(c8)
    check("سهم جریان درست حساب شد", round(_a8["share"], 3), 0.1)
    # میانگین ۲۰ روزه = (۵×۲۰۰ + ۱۵×۱۰۰) ÷ ۲۰ = ۱۲۵، پس ۲۰۰ ÷ ۱۲۵ = ۱.۶
    check("انبساط ارزش درست حساب شد", round(_a8["expansion"], 2), 1.6)
    check("امروز انباشت شناخته شد", _a8["is_accum"], True)

    # جریان مثبت ولی کم‌تر از آستانه → انباشت نیست
    for d in _days[-5:]:
        _put(d, "flow_retail", 2.0)        # ۱٪
    c8.commit()
    check("جریان زیر آستانه انباشت نیست", _sg.accumulation(c8)["is_accum"], False)

    check("گزارش بدون خطا ساخته شد", isinstance(_sg.report(c8), str), True)
    check("گزارش قید «توصیه نیست» را دارد", "توصیهٔ خرید" in _sg.report(c8), True)
    c8.close()

    _bot = (HERE.parent / "bot.py").read_text(encoding="utf-8")
    check("دستور /signal در ربات هست", '"/signal"' in _bot, True)
    check("سیگنال در گزارش روزانه هست", "signals.report(con)" in _bot, True)

    # ---- RMF در تب «جمع ورود پول» ---------------------------------------
    print("\nRMF در تب جمع ورود پول")
    import re as _tre, subprocess as _tsp, tempfile as _ttf
    _tgrab = lambda nm: _tre.search(
        r"^function %s\([^)]*\)\{.*?^\}" % nm,
        (CHART_DIR / "app.js").read_text(encoding="utf-8"),
        _tre.S | _tre.M).group(0)
    _fjs = (CHART_DIR / "app.js").read_text(encoding="utf-8")
    _fmc = (HERE.parent / "make_chart.py").read_text(encoding="utf-8")
    # ⚠ RMF مخرج می‌خواهد؛ flow.json قبلاً فقط صورت را داشت.
    check("flow.json ستون ارزش معاملات هم دارد", '"v": [None if x is None' in _fmc, True)
    check("RMF سه روز آخر حساب می‌شود",
          "function indRmfAt(" in _fjs and "FLOW_RMF_BACK = 3" in _fjs, True)
    check("سه ستون در سرستون جدول هست", _fjs.count('<th class="rmf">RMF-۵'), 3)
    check("RMF در CSV تب جمع هم می‌آید",
          "RMF-5 روز آخر,تاریخ" in _fjs, True)

    # همان حساب، با node روی دادهٔ ساختگیِ تُنُک
    _har = ("const FLOW_RMF_BACK = 3;\n" + _tgrab("indRmfAt")
            + "\nconst DATA={d:['a','b','c','d','e','f','g']};\n"
            + "const FLOW={x:{i:[0,1,2,3,4,5,6],"
            + "f:[10,-10,10,-10,10,-10,10],"
            + "v:[100,100,100,100,100,100,100]}};\n"
            + "console.log(JSON.stringify(indRmfAt('x',6,5).map(o=>o.v)));\n")
    with _ttf.NamedTemporaryFile("w", suffix=".js", delete=False,
                                 encoding="utf-8") as _f:
        _f.write(_har); _pf = _f.name
    try:
        _of = _tsp.run(["node", _pf], capture_output=True, text=True, timeout=30)
        _gf = json.loads(_of.stdout.strip() or "null")
    finally:
        os.unlink(_pf)
    # روز آخر (ردیف ۶): ‎+۱۰−۱۰+۱۰−۱۰+۱۰ = ‎+۱۰ از ۵۰۰ → ‎+۲
    # یک روز قبل (۵):   ‎−۱۰+۱۰−۱۰+۱۰−۱۰ = ‎−۱۰ از ۵۰۰ → ‎−۲
    check("سه مقدار RMF از تازه به قدیم",
          [round(x, 3) for x in _gf], [2.0, -2.0, 2.0])
    # پنجرهٔ ناقص باید null بدهد نه عدد نیم‌بند
    _har2 = _har.replace("indRmfAt('x',6,5)", "indRmfAt('x',4,5)")
    with _ttf.NamedTemporaryFile("w", suffix=".js", delete=False,
                                 encoding="utf-8") as _f:
        _f.write(_har2); _pf2 = _f.name
    try:
        _of2 = _tsp.run(["node", _pf2], capture_output=True, text=True,
                        timeout=30)
        _gf2 = json.loads(_of2.stdout.strip() or "null")
    finally:
        os.unlink(_pf2)
    check("پنجرهٔ ناقص تهی می‌ماند", _gf2, [2.0, None, None])

    # ---- ستون‌های RMF در جدول‌ها ---------------------------------------
    print("\nستون‌های RMF در جدول و صنایع")
    import re as _tre, subprocess as _tsp, tempfile as _ttf
    from store import SCHEMA as _TSC
    _tjs = (CHART_DIR / "app.js").read_text(encoding="utf-8")
    _tgrab = lambda nm: _tre.search(
        r"^function %s\([^)]*\)\{.*?^\}" % nm, _tjs,
        _tre.S | _tre.M).group(0)
    check("سه افق RMF تعریف شده",
          "const RMF_SPANS = [5, 22, 66]" in _tjs, True)
    check("جدول بازار ستون RMF می‌گیرد",
          'SHEET_COLS.concat(rmfCols(marketPair(), "mkt"))' in _tjs, True)
    # ⚠ در تب صنایع باید جفتِ خودِ صنعت برود، نه جریان کل بازار.
    check("جدول صنایع جفتِ خودِ صنعت را می‌گیرد",
          'rmfCols(indPair(state.ind)' in _tjs, True)
    check("ستون محاسباتی در رسم جدول خوانده می‌شود",
          "c.calc ? c.calc() : DATA[c.k]" in _tjs, True)
    check("ستون محاسباتی در CSV هم می‌آید",
          "c.calc?c.calc():DATA[c.k]" in _tjs, True)

    # همان حساب در پایتون، تا اگر فرمولِ جدول عوض شد معلوم شود
    _c9 = sqlite3.connect(":memory:")
    _c9.executescript(_TSC)
    _d9 = [f"140501{i:02d}" for i in range(1, 11)]
    for _i, _d in enumerate(_d9):
        _c9.execute("INSERT INTO observations VALUES (?,?,?,?,?,?)",
                    (_d, "flow_retail", 10.0 * (1 if _i % 2 == 0 else -1),
                     "t", "", ""))
        _c9.execute("INSERT INTO observations VALUES (?,?,?,?,?,?)",
                    (_d, "value_retail", 100.0, "t", "", ""))
    _c9.commit()
    _f9 = [v for _, v in _c9.execute(
        "SELECT date_j,value FROM observations WHERE series='flow_retail' "
        "ORDER BY date_j")]
    _v9 = [v for _, v in _c9.execute(
        "SELECT date_j,value FROM observations WHERE series='value_retail' "
        "ORDER BY date_j")]
    # روزهای فرد ‎+۱۰ و زوج ‎−۱۰؛ پنج روز آخر (۶ تا ۱۰) سه تا منفی و دو
    # تا مثبت‌اند، پس ‎−۱۰ ÷ ۵۰۰ × ۱۰۰ = ‎−۲.۰
    _want = sum(_f9[-5:]) / sum(_v9[-5:]) * 100
    check("RMF-۵ مرجع پایتون", round(_want, 3), -2.0)
    with _ttf.NamedTemporaryFile("w", suffix=".js", delete=False,
                                 encoding="utf-8") as _f:
        _f.write(_tgrab("rmfOf") + "\n"
                 + "const N = %d;\n" % len(_d9)
                 + "const pair = {f:%s, v:%s, id:'t'};\n" % (_f9, _v9)
                 + "console.log(JSON.stringify(rmfOf(5, pair)[%d]));\n"
                 % (len(_d9) - 1))
        _p9 = _f.name
    try:
        _o9 = _tsp.run(["node", _p9], capture_output=True, text=True,
                       timeout=30)
        _got = json.loads(_o9.stdout.strip() or "null")
    finally:
        os.unlink(_p9)
    check("ستون RMF جدول با پایتون یکی است",
          round(_got, 3) if _got is not None else None, round(_want, 3))
    _c9.close()

    # ---- کلید خاموش/روشن میانگین متحرک ---------------------------------
    print("\nکلید میانگین متحرک")
    _mjs = (CHART_DIR / "app.js").read_text(encoding="utf-8")
    _mhd = (CHART_DIR / "head.html").read_text(encoding="utf-8")
    check("کلید در صفحه هست", 'id="maBtn"' in _mhd, True)
    check("حالت خاموشی ذخیره می‌شود", "maOff:{}" in _mjs, True)
    # ⚠ maList از maPeriods جداست: کادر دوره‌ها عددهایش را نگه می‌دارد
    #   حتی وقتی میانگین خاموش است.
    check("فهرست رسم از فهرست ذخیره جداست",
          "const maList = () => maOn() ? maPeriods() : []" in _mjs, True)
    check("هیچ شاخه‌ای از plan مستقیم maPeriods نمی‌گیرد",
          "ma:maPeriods()" not in _mjs
          and "ma: indexed ? null : maPeriods()" not in _mjs, True)
    check("راهنمای بالای نمودار هم خاموشی را می‌بیند",
          "maList().forEach" in _mjs, True)
    # پاک‌کردن کادر همچنان یعنی «برگرد به پیش‌فرض»، نه «خاموش»
    check("کادر خالی به پیش‌فرض برمی‌گردد",
          "txt ? readPeriods(txt) : maDefaults()" in _mjs, True)

    # ---- نشانگر متقاطع ------------------------------------------------
    print("\nنشانگر متقاطع")
    _xjs = (CHART_DIR / "app.js").read_text(encoding="utf-8")
    check("جای عمودی نشانگر نگه داشته می‌شود", "hoverY" in _xjs, True)
    check("خط افقی خط‌چین است",
          'ctx.setLineDash([3,3])' in _xjs and "state.hoverY" in _xjs, True)
    check("ناحیه‌های مقیاس‌دار ثبت می‌شوند",
          "function region(" in _xjs and "function regionAt(" in _xjs, True)
    # ⚠ متغیر پس‌زمینه «--ground» است نه «--bg»؛ css() برای نام ناموجود
    #   رشتهٔ خالی می‌دهد و نتیجه متنِ سیاه روی زمینهٔ سیاه می‌شود.
    check("برچسب نشانگر رنگ پس‌زمینهٔ درست را می‌گیرد",
          'css("--ground")' in _xjs, True)
    _hd2 = (CHART_DIR / "head.html").read_text(encoding="utf-8")
    import re as _re2
    _vars = set(_re2.findall(r"--([a-z0-9-]+)\s*:", _hd2))
    _used = set(_re2.findall(r'css\("--([a-z0-9-]+)"\)', _xjs))
    check("هر متغیر رنگی که js می‌خواهد در css هست",
          sorted(_used - _vars), [])
    check("کشیدن نمودار خط افقی را پاک می‌کند",
          "state.hoverY=null;              // در حال جابه‌جایی" in _xjs, True)

    # ---- کندل شاخص کل ------------------------------------------------
    print("\nکندل شاخص کل — تریدرزآرنا")
    _ojs = (CHART_DIR / "app.js").read_text(encoding="utf-8")
    from sources import ta_candles as _tc
    _cjs = (FIX / "ta_candles.json").read_text(encoding="utf-8")
    _crows, _cnotes = _tc.parse(_cjs)
    check("کندل‌ها خوانده شدند", len(_crows), 450)      # ۱۵۰ کندل × ۳ سری
    check("کندل بدون هشدار خوانده شد", _cnotes, [])
    _by = {}
    for d, sname, v, _ in _crows:
        _by.setdefault(d, {})[sname] = v
    _last = _by["14050813"]
    check("باز درست خوانده شد", round(_last["index_open"], 1), 7824603.4)
    check("سقف درست خوانده شد", round(_last["index_high"], 1), 7922830.0)
    check("کف درست خوانده شد", round(_last["index_low"], 1), 7869310.0)
    check("سقف کمتر از کف نیست",
          all(x["index_high"] >= x["index_low"] for x in _by.values()), True)
    check("since روزهای قدیمی را رد می‌کند",
          len(_tc.parse(_cjs, since="14050810")[0]), 9)   # ۳ روز × ۳ سری
    # ⚠ «باز» قیمت بازگشایی نیست؛ پایانیِ روز قبل است. اگر روزی منبع
    #   این را عوض کند، شکلِ شمع‌ها بی‌صدا معنی دیگری پیدا می‌کند.
    import json as _json
    _raw = _json.loads(_cjs)["candles"]
    _eq = sum(1 for i in range(1, len(_raw))
              if abs(_raw[i][1] - _raw[i-1][4]) < 0.05)
    check("«باز» همان پایانیِ روز قبل است", _eq, len(_raw) - 1)
    # پاسخ خراب نباید چیزی بنویسد
    check("پاسخ غیر JSON رد می‌شود", _tc.parse("<html>")[0], [])
    check("پاسخ بدون candles رد می‌شود", _tc.parse('{"x":1}')[0], [])
    check("پاسخ کوتاه رد می‌شود",
          _tc.parse('{"candles":[[1,2,3,4,5,1,"14050101",5,6]]}')[0], [])
    # سری‌ها در config و در خروجی نمودار هست
    from config import SERIES as _SER, MAX_DAILY_MOVE as _MDM
    for k in ("index_open", "index_high", "index_low"):
        check(f"{k} در config.SERIES هست", k in _SER, True)
        check(f"{k} گارد جهش دارد", k in _MDM, True)
    _mc = (HERE.parent / "make_chart.py").read_text(encoding="utf-8")
    check("سری‌های کندل در خروجی نمودار می‌آیند",
          '"index_open", "index_high", "index_low"' in _mc, True)
    check("کندل در جمع‌آوری روزانه هست",
          "ta_candles" in (HERE.parent / "collect.py").read_text(encoding="utf-8"),
          True)
    # ⚠ در ~۹.۵٪ روزها پایانی بیرون بازهٔ سقف-کف است؛ رسم‌کننده باید
    #   سایه را گسترش بدهد وگرنه بدنه از سایه می‌زند بیرون.
    check("رسم‌کننده سایه را تا باز و بسته گسترش می‌دهد",
          "Math.max(h[i], o[i], c[i])" in _ojs
          and "Math.min(l[i], o[i], c[i])" in _ojs, True)
    check("کلید خطی/شمعی در صفحه هست",
          'id="candleBtn"' in (CHART_DIR / "head.html").read_text(encoding="utf-8"),
          True)

    # ---- اسیلاتورها -------------------------------------------------
    # RMF و دو خطِ ویلیامز با node سنجیده می‌شوند، نه با چشم: خودِ
    # تابع‌ها از app.js کنده می‌شوند، پس اگر فرمول عوض شد این‌جا قرمز
    # می‌شود — نه این‌که تست یک کپی کهنه را درست اعلام کند.
    print("\nاسیلاتورها — RMF و ویلیامز ٪R")
    _ojs = (CHART_DIR / "app.js").read_text(encoding="utf-8")
    check("RMF در فهرست اسیلاتورها هست", '{id:"rmf"' in _ojs, True)
    # ویلیامز تک‌خطی است؛ خط «٪R جریان پول» به درخواست کاربر برداشته شد
    check("ویلیامز تک‌خط است", "cumFlow" not in _ojs, True)
    check("MFI برداشته شد", "mfiOf" not in _ojs, True)
    check("دورهٔ هر اسیلاتور جدا نگه داشته می‌شود",
          "state.oscP[state.osc]" in _ojs, True)

    import re as _re
    import subprocess as _sp
    import tempfile as _tf

    def _grab(name):
        m = _re.search(r"^function %s\([^)]*\)\{.*?^\}" % name,
                       _ojs, _re.S | _re.M)
        return m.group(0) if m else ""

    _stub = (
        "const N = 8;\n"
        "const DATA = {flow_retail:[10,-5,20,-30,40,-10,5,0],\n"
        "              value_retail:[100,100,100,100,100,100,100,100]};\n"
    )
    _drive = (
        "const pair = {f:DATA.flow_retail, v:DATA.value_retail, id:'t'};\n"
        "const r = rmfOf(4, pair);\n"                 # چهار روز آخر
        "const w = willrOf([1,2,3,4,5,6], 3);\n"      # بالارونده
        "const d = willrOf([6,5,4,3,2,1], 3);\n"      # پایین‌رونده
        "let s=0; const cum = DATA.flow_retail.map(v => (s+=v));\n"
        "console.log(JSON.stringify({rmf:r[7], rmf4:r[4], wr:w[5], dn:d[5],\n"
        "  cum:cum[7], wcum:willrOf(cum,3)[7], none:rmfOf(4,null)[7]}));\n"
    )
    check("تابع‌های اسیلاتور در app.js پیدا شدند",
          bool(_grab("willrOf")) and bool(_grab("rmfOf")), True)
    with _tf.NamedTemporaryFile("w", suffix=".js", delete=False,
                                encoding="utf-8") as _f:
        _f.write(_grab("willrOf") + "\n" + _stub + _grab("rmfOf")
                 + "\n" + _drive)
        _opath = _f.name
    try:
        _out = _sp.run(["node", _opath], capture_output=True, text=True,
                       timeout=30)
        _r = json.loads(_out.stdout.strip() or "{}")
    finally:
        os.unlink(_opath)
    # (۴۰ ‎−۱۰ ‎+۵ ‎+۰) ÷ ۴۰۰ × ۱۰۰ = ۸.۷۵
    check("RMF-۴ روزهای آخر درست حساب شد", round(_r.get("rmf", 0), 3), 8.75)
    # (۱۰ ‎−۵ ‎+۲۰ ‎−۳۰ ... ) روی چهار روز اولِ کامل: (−۵+۲۰−۳۰+۴۰) ÷ ۴۰۰
    check("RMF-۴ در میانهٔ سری هم درست است",
          round(_r.get("rmf4", 0), 3), 6.25)
    check("ویلیامز روی سقف پنجره صفر است", _r.get("wr"), 0)
    check("ویلیامز روی کف پنجره منفی صد است", _r.get("dn"), -100)
    check("مجموع تجمعی ورود پول درست جمع شد", _r.get("cum"), 30)
    check("ویلیامزِ جریان پول عدد می‌دهد",
          isinstance(_r.get("wcum"), (int, float)), True)
    check("بی‌جریانِ پول، RMF عدد نمی‌دهد", _r.get("none"), None)
    # ⚠ در تب صنایع باید جریانِ خودِ صنعت بیاید نه جریان کل بازار
    # ---- نمای چنداسیلاتوره -------------------------------------------
    check("نمای اسیلاتورها در فهرست نماهاست",
          'id:"total"' in _ojs and 'tab:"اسیلاتورهای شاخص"' in _ojs, True)
    # ⚠ سریِ رسم‌شدهٔ این نما ارزش معاملات است ولی اسیلاتورها باید روی
    #   شاخص کل حساب شوند. اگر این بشکند، نمودار درست می‌ماند و
    #   عددها بی‌صدا غلط می‌شوند — پس قفلش این‌جاست.
    check("اسیلاتورهای این نما روی شاخص کل حساب می‌شوند",
          'FS("index_total") || plot[0].a' in _ojs, True)
    check("سری رسم‌شدهٔ این نما ارزش معاملات است",
          'key:"value_retail"' in _ojs, True)
    check("هر سه اسیلاتور در آن نما قابل خاموش‌کردن‌اند",
          "state.oscOn" in _ojs and "oscLinesOf" in _ojs, True)
    check("ترتیب پنجره‌ها شمع، RSI، RMF، ویلیامز است",
          'MULTI_ORDER = ["cnd", "rsi", "rmf", "wr"]' in _ojs, True)
    check("پنجرهٔ شمع در نمای اسیلاتورها هست",
          "function candlePanel(" in _ojs and 'id="mCndBtn"' in
          (CHART_DIR / "head.html").read_text(encoding="utf-8"), True)
    # در تمام‌صفحه حاشیه‌ها تنگ‌تر می‌شوند تا نمودار پهن‌تر شود
    check("تمام‌صفحه حاشیه را کم می‌کند",
          ":fullscreen .app{padding-inline:4px" in
          (CHART_DIR / "head.html").read_text(encoding="utf-8")
          and "const isFS = ()" in _ojs, True)
    # ⚠ نسخهٔ اول همه را به مقیاس مشترک ۰ تا ۱۰۰ می‌برد و عددِ محور
    #   دیگر عددِ اندیکاتور نبود. این تست جلوی برگشتنش را می‌گیرد.
    check("هیچ اسیلاتوری روی محور منتقل نمی‌شود",
          "v+100" not in _ojs and "50+v*RMF_K" not in _ojs, True)
    check("هر پنجره محور خودش را دارد",
          "function oscPanel(" in _ojs and "L.oscPanels" in _ojs, True)
    # ⚠ خط روی محور با مقدار خودش یکی نیست؛ پس مقدار واقعی باید
    #   کنار نام هر خط بیاید، وگرنه محور دروغ می‌گوید.
    check("مقدار واقعی هر خط در سرنویس پنل می‌آید",
          "const tag = ln =>" in _ojs and "lastOf(ln.a)" in _ojs, True)
    check("سطوح انباشت در مرورگر حساب می‌شوند",
          "function accumLevels" in _ojs, True)
    # آستانه‌های JS باید با signals.py یکی باشند، وگرنه سایت و ربات
    # دو حرف مختلف می‌زنند و معلوم نیست کدام درست است.
    import signals as _sg2
    for name, js, py in (("سهم ورود پول", "ACC_SHARE = 0.04", _sg2.ACC_SHARE),
                         ("پنجرهٔ جریان", "ACC_WIN = 5", _sg2.ACC_WINDOW),
                         ("میانگین ارزش", "ACC_MA = 20", _sg2.VALUE_MA),
                         ("فاصلهٔ خوشه", "ACC_GAP = 10", _sg2.CLUSTER_GAP)):
        check(f"آستانهٔ «{name}» در app.js و signals.py یکی است",
              js.split(" = ")[1] == str(py) and js in _ojs, True)
    # رنگ RMF نباید همان رنگ میانگین ۵۰ روزه باشد
    _hd = (CHART_DIR / "head.html").read_text(encoding="utf-8")
    check("رنگ هفتم برای RMF تعریف شده", _hd.count("--s7:") >= 3, True)
    check("RMF رنگ میانگین را قرض نمی‌گیرد",
          'c:"--s2"' not in _ojs, True)

    check("تب صنایع جفتِ خودش را برمی‌دارد",
          'V.indBars' in _ojs and 'indKey(c,"flow")' in _ojs, True)

    print(f"\n{ok} تست سبز، {fail} قرمز")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
