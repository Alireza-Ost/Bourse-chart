# -*- coding: utf-8 -*-
"""
تصحیح «شاخص گروه»ی که منبع یک رقم کم نوشته است.

    python fix_gindex_scale.py            فقط گزارش، چیزی نوشته نمی‌شود
    python fix_gindex_scale.py --write    اعمال کن

── مسئله
   تریدرزآرنا برای بعضی صنایع، روز در میان، شاخص گروه را با یک رقم کمتر
   می‌دهد. در دیتابیس این‌طور دیده می‌شود:

       ۱۴۰۵/۰۸/۰۳   ۵۸٬۱۳۸٬۹۲۳
       ۱۴۰۵/۰۸/۰۴    ۵٬۸۶۷٬۷۷۰   ← یک رقم کم
       ۱۴۰۵/۰۸/۰۵    ۵٬۷۵۲٬۳۶۰   ← یک رقم کم
       ۱۴۰۵/۰۸/۰۹   ۵۵٬۸۴۹٬۲۹۷

   اشکالِ منبع است نه برداشت ما؛ همان صفحه گاهی درست و گاهی غلط می‌دهد.
   اثرش روی نمودار یک گودال ده‌برابری است و روی هر حسابی که از شاخص
   گروه بازده می‌گیرد (مثل مقایسهٔ صنایع) عدد را بی‌معنی می‌کند.

── قاعده
   گذر رو به جلو: هر مقدار با میانهٔ ده مقدارِ *اصلاح‌شدهٔ* قبلی سنجیده
   می‌شود. اگر ×۱۰ یا ÷۱۰ کردنش آن را دست‌کم دو برابر نزدیک‌تر کند،
   همان درست است. چون سطحِ مرجع خودش اصلاح‌شده است، رشته‌های پشت سر هم
   هم گرفته می‌شوند، نه فقط روزهای تک‌افتاده.

⚠ این تنها جای این پروژه است که مقدارِ موجود را **بازنویسی** می‌کند.
  بقیهٔ مهاجرت‌ها فقط جای خالی را پر می‌کنند. پس پیش‌فرضش گزارش است و
  نوشتن باید صریح خواسته شود. قبلش از دیتابیس نسخه بگیرید.
"""
import statistics
import sys

from config import INDUSTRIES
from store import connect

MIN_HIST = 5          # کمتر از این تعداد مقدار قبلی، قضاوت نمی‌کنیم
WINDOW = 10           # سطح مرجع: میانهٔ این تعداد مقدار اخیر
BETTER = 2.0          # ضریب باید دست‌کم این‌قدر نزدیک‌تر کند


def scan(con, code):
    rows = con.execute(
        "SELECT date_j, value FROM industry_obs "
        "WHERE ind=? AND metric='gindex' ORDER BY date_j", (code,)).fetchall()
    out, hist = [], []
    for d, v in rows:
        if not v:
            continue
        if len(hist) >= MIN_HIST:
            lvl = statistics.median(hist[-WINDOW:])
            cand = [(abs(v / lvl - 1), 1.0),
                    (abs(v * 10 / lvl - 1), 10.0),
                    (abs(v / 10 / lvl - 1), 0.1)]
            err, k = min(cand)
            if k != 1.0 and err * BETTER < cand[0][0]:
                out.append((d, v, v * k, lvl))
                v = v * k
        hist.append(v)
    return out


def main(argv):
    write = "--write" in argv
    con = connect()
    total = 0
    for code in INDUSTRIES:
        bad = scan(con, code)
        if not bad:
            continue
        total += len(bad)
        print(f"\n{INDUSTRIES.get(code, code)} (کد {code}) — {len(bad)} ردیف")
        for d, old, new, lvl in bad[:6]:
            print(f"   {d}  {old:>14,.0f} → {new:>14,.0f}   (سطح {lvl:,.0f})")
        if len(bad) > 6:
            print(f"   … و {len(bad)-6} ردیف دیگر")
        if write:
            for d, _old, new, _lvl in bad:
                con.execute(
                    "UPDATE industry_obs SET value=?, "
                    "src_ref=COALESCE(src_ref,'')||' +scale10' "
                    "WHERE date_j=? AND ind=? AND metric='gindex'",
                    (new, d, code))
    if write:
        con.commit()
    print(f"\nجمع: {total} ردیف"
          + (" اصلاح شد." if write else " — برای اعمال: --write"))
    con.close()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
