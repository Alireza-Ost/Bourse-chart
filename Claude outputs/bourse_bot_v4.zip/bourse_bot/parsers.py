# -*- coding: utf-8 -*-
"""
پارسرهای متن کانال‌ها.

هر پارسر یک متن فارسی می‌گیرد و فهرستی از (تاریخ شمسی، سری، مقدار) برمی‌گرداند.
تاریخ همیشه از *متن خود پست* خوانده می‌شود، نه از زمان انتشار — چون بعضی کانال‌ها
گزارش را روز بعد منتشر می‌کنند. اگر متن تاریخ نداشت، تاریخ پیام fallback است.
"""
import re
import datetime
import jdatetime

FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
AR_DIGITS = "٠١٢٣٤٥٦٧٨٩"
MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
          "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
# jdatetime.weekday(): 0 = شنبه
WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه شنبه", "چهارشنبه", "پنجشنبه", "جمعه"]


def norm(s: str) -> str:
    """ارقام فارسی/عربی → انگلیسی، حذف نیم‌فاصله، یکدست‌کردن فاصله‌ها."""
    if not s:
        return ""
    out = []
    for ch in s:
        if ch in FA_DIGITS:
            out.append(str(FA_DIGITS.index(ch)))
        elif ch in AR_DIGITS:
            out.append(str(AR_DIGITS.index(ch)))
        elif ch == "٬":
            out.append(",")
        elif ch == "‌":
            out.append(" ")
        else:
            out.append(ch)
    return re.sub(r"\s+", " ", "".join(out)).strip()


def to_number(raw: str, unit: str = "") -> float:
    """
    «1,200» → 1200 ، «10.443» → 10443 (نقطه به‌عنوان جداکنندهٔ هزارگان) ،
    «2.5 همت» → 2500 ، «0.6» → 0.6
    قاعده: نقطه‌ای که دقیقاً ۳ رقم بعدش باشد، جداکنندهٔ هزارگان است.
    """
    s = raw.replace(",", "").strip()
    if re.fullmatch(r"\d{1,3}(\.\d{3})+", s):      # 10.443 / 1.234.567
        s = s.replace(".", "")
    v = float(s)
    if "همت" in unit:                               # هزار میلیارد تومان
        v *= 1000
    return v


def jalali_from_text(text: str, msg_date: datetime.date):
    """
    تاریخ شمسی را از متن بیرون می‌کشد. دو قالب پشتیبانی می‌شود:
      ۱) عددی:  1405/06/23
      ۲) حروفی: «چهارشنبه، 25 شهریور 1405»  یا  «شنبه 12 مرداد» (بدون سال)
    اگر سال نبود، سالی انتخاب می‌شود که تاریخ حاصل به تاریخ پیام نزدیک‌تر باشد.
    خروجی: (YYYYMMDD, weekday_ok)  — weekday_ok=None یعنی متن روز هفته نداشت.
    """
    t = norm(text)

    m = re.search(r"\b(1[34]\d{2})/(\d{1,2})/(\d{1,2})\b", t)
    if m:
        try:
            jd = jdatetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            return jd.strftime("%Y%m%d"), None
        except ValueError:
            pass

    m = re.search(
        r"(?:(" + "|".join(WEEKDAYS + ["یک شنبه", "سه‌شنبه"]) + r")\s*[،,]?\s*)?"
        r"\b(\d{1,2})\s*(" + "|".join(MONTHS) + r")\s*(?:ماه\s*)?(1[34]\d{2})?", t)
    if not m:
        return None, None

    wd_txt, day, mon_name, year = m.group(1), int(m.group(2)), m.group(3), m.group(4)
    mon = MONTHS.index(mon_name) + 1
    base = jdatetime.date.fromgregorian(date=msg_date).year
    years = [int(year)] if year else [base - 1, base, base + 1]

    best = None
    for y in years:
        try:
            jd = jdatetime.date(y, mon, day)
        except ValueError:
            continue
        lag = abs((jd.togregorian() - msg_date).days)
        if best is None or lag < best[0]:
            best = (lag, jd)
    if best is None:
        return None, None

    jd = best[1]
    wd_ok = None
    if wd_txt:
        wd_ok = (WEEKDAYS[jd.weekday()] == wd_txt.replace("یک شنبه", "یکشنبه")
                                                 .replace("سه‌شنبه", "سه شنبه"))
    return jd.strftime("%Y%m%d"), wd_ok


LEVEL = (r"(?:به\s*سطح|در\s*سطح|در\s*محدوده|در\s*تراز|به\s*تراز|به\s*عدد|به\s*رقم|به\s*کانال|به)"
         r"\s*([\d,]{5,12})(?:\s*واحد)?")


def parse_parsis(text: str, msg_date: datetime.date):
    """کانال «پارسیس تحلیل» — ارزش معاملات خرد، جریان پول حقیقی، سرانه‌ها."""
    t = norm(text)
    jd, wd_ok = jalali_from_text(t, msg_date)
    if not jd:
        return []
    out = []

    m = re.search(r"مجموعا\s*مبلغ\s*([\d,\.]+)\s*میلیارد\s*تومان\s*(خروج|ورود)\s*حقیقی", t)
    if m:
        v = to_number(m.group(1))
        out.append((jd, "flow_retail", v if m.group(2) == "ورود" else -v))
        b = re.search(r"([\d\.]+)\s*درصد\s*خریدها\s*توسط\s*حقیقی", t)
        s = re.search(r"([\d\.]+)\s*درصد\s*فروش\s*ها\s*توسط\s*حقیقی", t)
        if b: out.append((jd, "buy_share", float(b.group(1))))
        if s: out.append((jd, "sell_share", float(s.group(1))))

    m = (re.search(r"ارزش\s*معاملات\s*#?خرد[^.]{0,160}?مبلغ\s*([\d,\.]+)\s*میلیارد\s*تومان\s*بود", t)
         or re.search(r"ارزش\s*معاملات\s*خرد\s*(?:امروز\s*)?بازار\s*(?:حدود\s*)?([\d,\.]+)\s*میلیارد\s*تومان\s*بود", t))
    if m:
        out.append((jd, "value_retail", to_number(m.group(1))))

    m = re.search(r"سرانه\s*خرید\s*حقیقی\s*در\s*حدود\s*([\d\.]+)\s*میلیون\s*تومان\s*و\s*"
                  r"سرانه\s*فروش\s*در\s*حدود\s*([\d\.]+)", t)
    if m:
        out.append((jd, "sarane_buy", float(m.group(1))))
        out.append((jd, "sarane_sell", float(m.group(2))))

    return [(d, k, v, wd_ok) for d, k, v in out]


def parse_bourseiness(text: str, msg_date: datetime.date):
    """کانال «بورسینس» — خلاصه بازار: شاخص کل و هم‌وزن، ارزش معاملات، جریان پول."""
    t = norm(text)
    if "خلاصه بازار" not in t:
        return []
    jd, wd_ok = jalali_from_text(t, msg_date)
    if not jd:
        return []
    out = []

    i = t.find("هم وزن")
    head, tail = (t[:i], t[i:]) if i > 0 else (t, "")
    a = re.search(LEVEL, head)
    b = re.search(LEVEL, tail) if tail else None
    if a: out.append((jd, "index_total", to_number(a.group(1))))
    if b: out.append((jd, "index_ew",    to_number(b.group(1))))

    m = re.search(r"ارزش\s*معاملات\s*خرد\s*:?\s*([\d.,]+)\s*(همت|میلیارد)", t)
    if m:
        out.append((jd, "value_retail", to_number(m.group(1), m.group(2))))

    m = re.search(r"(ورود|خروج)\s*نقدینگی\s*حقیقی\s*:?\s*([\d,]+)\s*میلیارد", t)
    if m:
        v = to_number(m.group(2))
        out.append((jd, "flow_retail", v if m.group(1) == "ورود" else -v))

    return [(d, k, v, wd_ok) for d, k, v in out]


PARSERS = {"parsis": parse_parsis, "bourseiness": parse_bourseiness}


def parse(channel: str, text: str, msg_date: datetime.date):
    """بر اساس کانال مبدأ، پارسر مناسب را صدا می‌زند. اگر کانال ناشناس بود، هر دو را امتحان می‌کند."""
    from config import CHANNEL_PARSERS
    name = CHANNEL_PARSERS.get(channel)
    if name:
        return PARSERS[name](text, msg_date)
    for fn in PARSERS.values():                     # کانال ناشناس: بهترین تلاش
        rows = fn(text, msg_date)
        if rows:
            return rows
    return []
